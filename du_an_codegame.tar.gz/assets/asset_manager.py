"""asset_manager.py - loads, resizes and caches PNGs/spritesheets from assets/."""
import os
import re

import pygame

from config import KURAMA_AURA_ALPHA

DEFAULT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", "characters")

KURAMA_NARUTO_NAME = "nine-tails chakra naruto"      # Naruto Evolution Tier 2 (lower-case lookup key)
# Old name kept ONLY so stale references still resolve to the same sprite sheet.
LEGACY_KURAMA_NAMES = ("kurama link naruto",)
KURAMA_NARUTO_NAMES = (KURAMA_NARUTO_NAME,) + LEGACY_KURAMA_NAMES

# Exact number of animation frames in assets/characters/naruto_evo2.png (single horizontal row).
# If the portrait ever shows two sprites / a cut-off sprite again, this is the ONE number to adjust.
KURAMA_CHARACTER_FRAMES = 8

ANIMATED_CHARACTERS = (
    "naruto", "sage naruto", *KURAMA_NARUTO_NAMES,
    "sasuke", "curse mark sasuke", "taka sasuke",
    "sakura", "medic sakura", "chakra surge sakura", "inner sakura", "medical ninja sakura"
)


def _smooth(surf, size):
    """smoothscale that never raises: falls back to plain scale for unusual pixel formats
    and clamps the target size to at least 1x1."""
    size = (max(1, int(size[0])), max(1, int(size[1])))
    try:
        return pygame.transform.smoothscale(surf, size)
    except (pygame.error, ValueError):
        return pygame.transform.scale(surf, size)


def _load_surface(path):
    """Loads an image file; returns None if it is missing, unreadable or empty. Never raises."""
    if not os.path.isfile(path):
        return None
    try:
        img = pygame.image.load(path)
        if pygame.display.get_surface():
            img = img.convert_alpha()
    except (pygame.error, OSError):
        return None
    if img.get_width() < 1 or img.get_height() < 1:
        return None
    return img


class AssetManager:
    def __init__(self, assets_dir=DEFAULT_DIR):
        self.assets_dir = assets_dir
        self.base_dir = os.path.dirname(assets_dir)
        self._originals = {}         # filename -> Surface | None
        self._scaled = {}            # (key, w, h) -> Surface
        self._kunai_img = None
        self._skill_imgs = {}        # filename -> Surface | None
        self._enemy_imgs = {}        # filename -> Surface | None
        self._enemy_skill_imgs = {}  # filename -> Surface | None
        self._attack_imgs = {}       # filename -> Surface | None  (assets/attacks/)
        self._item_imgs = {}         # item_key -> Surface | None  (assets/item/)
        self._anim_imgs = {}         # (folder, filename) -> Surface | None  (Roushi FX sheets)

    @staticmethod
    def filename_for(name, evo_stage=0):
        name_l = name.strip().lower()
        if name_l in ("chakra surge sakura", "medic sakura", "inner sakura", "medical ninja sakura"):
            return "sakura_evo.png"
        if name_l == "sage naruto":
            return "naruto_evo.png"
        if name_l in KURAMA_NARUTO_NAMES or (name_l == "naruto" and evo_stage == 2):
            return "naruto_evo2.png"      # Nine-Tails Chakra Naruto (Evolution Tier 2)
        if name_l == "curse mark sasuke":
            return "sasuke_evo.png"
        if name_l == "taka sasuke":
            return "sasuke_evo_v2.png"
        slug = re.sub(r"[^a-z0-9]+", "_", name_l).strip("_")
        if evo_stage == 2:
            return f"{slug}_evo_v2.png"
        return f"{slug}{'_evo' if evo_stage == 1 else ''}.png"

    def get_kunai_image(self, size=30):
        if self._kunai_img is None:
            path = os.path.join(self.base_dir, "attacks", "kunai.png")
            if os.path.isfile(path):
                try:
                    img = pygame.image.load(path)
                    self._kunai_img = img.convert_alpha() if pygame.display.get_surface() else img
                except (pygame.error, OSError):
                    self._kunai_img = None
            else:
                alt_path = os.path.join(self.base_dir, "kunai.png")
                if os.path.isfile(alt_path):
                    try:
                        img = pygame.image.load(alt_path)
                        self._kunai_img = img.convert_alpha() if pygame.display.get_surface() else img
                    except (pygame.error, OSError):
                        self._kunai_img = None

        if self._kunai_img:
            ow, oh = self._kunai_img.get_size()
            w = int(ow * size / oh) if oh else size
            key = ("kunai", max(1, w), size)
            if key not in self._scaled:
                self._scaled[key] = _smooth(self._kunai_img, (max(1, w), size))
            return self._scaled[key]
        return None

    def get_skill_image_single(self, filename, size=75):
        if filename not in self._skill_imgs:
            path = os.path.join(self.base_dir, "skills", filename)
            self._skill_imgs[filename] = _load_surface(path)
        img = self._skill_imgs[filename]
        if not img:
            return None

        ow, oh = img.get_size()
        h = int(size)
        w = int(ow * h / oh) if oh else h
        key = (filename, max(1, w), h)
        if key not in self._scaled:
            self._scaled[key] = _smooth(img, (max(1, w), h))
        return self._scaled[key]

    def get_skill_sheet_frame(self, filename, num_frames=5, time_sec=0.0, size=75):
        if filename not in self._skill_imgs:
            path = os.path.join(self.base_dir, "skills", filename)
            self._skill_imgs[filename] = _load_surface(path)
        sheet = self._skill_imgs[filename]
        if not sheet:
            return None

        ow = sheet.get_width() // num_frames
        oh = sheet.get_height()
        frame_idx = int(time_sec * 10) % num_frames
        key = (filename, frame_idx, size)

        if key not in self._scaled:
            frame_surf = pygame.Surface((ow, oh), pygame.SRCALPHA)
            frame_surf.blit(sheet, (0, 0), (frame_idx * ow, 0, ow, oh))
            h = int(size)
            w = int(ow * h / oh) if oh else h
            self._scaled[key] = _smooth(frame_surf, (max(1, w), max(1, h)))
        return self._scaled[key]

    def get_rasen_shuriken_frame(self, time_sec=0.0, size=75):
        return self.get_skill_sheet_frame("rasen_shuriken.png", 5, time_sec, size)

    def get_fire_ball_frame(self, time_sec=0.0, size=70):
        return self.get_skill_sheet_frame("fire_ball.png", 2, time_sec, size)

    def get_amaterasu_frame(self, time_sec=0.0, size=60):
        return self.get_skill_sheet_frame("amateratsu.png", 3, time_sec, size)

    def get_chidori_image(self, size=80):
        return self.get_skill_image_single("chidori.png", size)

    # --- Enemy Skills (assets/enemy_skills/) -------------------------------------
    def get_enemy_skill_image(self, filename, size=40):
        if filename not in self._enemy_skill_imgs:
            path = os.path.join(self.base_dir, "enemy_skills", filename)
            self._enemy_skill_imgs[filename] = _load_surface(path)
        img = self._enemy_skill_imgs[filename]
        if img is None:
            return None

        ow, oh = img.get_size()
        w = int(ow * size / oh) if oh else size
        key = ("enemy_skill_single", filename, max(1, w), size)
        if key not in self._scaled:
            self._scaled[key] = _smooth(img, (max(1, w), max(1, size)))
        return self._scaled[key]

    def get_enemy_skill_sheet_frame(self, filename, num_frames=5, time_sec=0.0, size=110):
        """Loads and slices a horizontal spritesheet from assets/enemy_skills/.
        Automatically checks alias filenames for Gaara's shield and Sand Hand."""
        if filename not in self._enemy_skill_imgs:
            candidates = [filename]
            if filename in ("gaara_shied.png", "gaara_shield.png"):
                candidates = ["gaara_shied.png", "gaara_shield.png"]
            elif filename in ("sand_hand.png", "sand_claw.png"):
                candidates = ["sand_hand.png", "sand_claw.png"]

            img = None
            for cand in candidates:
                path = os.path.join(self.base_dir, "enemy_skills", cand)
                img = _load_surface(path)
                if img is not None:
                    break
            self._enemy_skill_imgs[filename] = img

        sheet = self._enemy_skill_imgs[filename]
        if sheet is None:
            return None

        ow = max(1, sheet.get_width() // num_frames)
        oh = max(1, sheet.get_height())
        frame_idx = int(time_sec * 10) % num_frames
        key = ("enemy_skill_sheet", filename, num_frames, frame_idx, int(size))

        if key not in self._scaled:
            frame_surf = pygame.Surface((ow, oh), pygame.SRCALPHA)
            frame_surf.blit(sheet, (0, 0), (frame_idx * ow, 0, ow, oh))
            h = max(1, int(size))
            w = max(1, int(ow * h / oh))
            self._scaled[key] = _smooth(frame_surf, (w, h))
        return self._scaled[key]

    def get_sand_hand_frame(self, time_sec=0.0, size=90):
        return self.get_enemy_skill_sheet_frame("sand_hand.png", num_frames=2, time_sec=time_sec, size=size)

    # --- Melee attack sheets (assets/attacks/) ----------------------------------
    PUNCH_FRAMES = 3

    def get_attack_sheet_frame(self, filename, num_frames, frame_idx, size=80):
        if filename not in self._attack_imgs:
            self._attack_imgs[filename] = _load_surface(os.path.join(self.base_dir, "attacks", filename))
        sheet = self._attack_imgs[filename]
        if sheet is None:
            return None

        num_frames = max(1, int(num_frames))
        frame_idx = max(0, min(int(frame_idx), num_frames - 1))
        ow = max(1, sheet.get_width() // num_frames)
        oh = max(1, sheet.get_height())
        h = max(1, int(size))
        key = ("attack_sheet", filename, num_frames, frame_idx, h)
        if key not in self._scaled:
            frame_surf = pygame.Surface((ow, oh), pygame.SRCALPHA)
            frame_surf.blit(sheet, (0, 0), (frame_idx * ow, 0, ow, oh))
            self._scaled[key] = _smooth(frame_surf, (max(1, int(ow * h / oh)), h))
        return self._scaled[key]

    def get_sakura_punch_frame(self, frame_idx=0, size=80):
        """Sakura's punch: assets/attacks/sakura_punch.png, 3 frames laid out horizontally."""
        return self.get_attack_sheet_frame("sakura_punch.png", self.PUNCH_FRAMES, frame_idx, size)

    # --- Item Icons (assets/item/) ----------------------------------------------
    def get_item_image(self, item_key, size=32):
        """Icon for an ITEMS key, e.g. "son_goku" -> assets/item/son_goku.png, "kokuo" ->
        assets/item/kokuo.png (assets/items/ is also
        searched). The source image is loaded once and cached (a missing/corrupt file is cached as
        None, so it is not re-read every frame); scaled copies are cached per size. Never raises -
        returns None when there is no usable file, and the UI then draws its fallback shape."""
        if not item_key:
            return None
        key_l = str(item_key).strip().lower()
        if not key_l:
            return None
        if key_l not in self._item_imgs:
            item_dirs = (os.path.join(self.base_dir, "item"), os.path.join(self.base_dir, "items"))
            # de-duplicated, order preserved: exact lowercase key first, then case variants for
            # case-sensitive file systems
            candidates = list(dict.fromkeys([
                f"{key_l}.png",
                f"{key_l.capitalize()}.png",
                f"{key_l.title()}.png",
                f"{key_l.upper()}.png",
                f"{item_key}.png",
            ]))
            img = None
            for item_dir in item_dirs:
                for cand in candidates:
                    img = _load_surface(os.path.join(item_dir, cand))
                    if img is not None:
                        break
                if img is not None:
                    break
            self._item_imgs[key_l] = img

        img = self._item_imgs[key_l]
        if img is None:
            return None

        ow, oh = img.get_size()
        h = max(1, int(size))
        w = max(1, int(ow * h / oh)) if oh else h
        key = ("item_icon", key_l, w, h)
        if key not in self._scaled:
            self._scaled[key] = _smooth(img, (max(1, w), h))
        return self._scaled[key]

    # --- Nii Yugito attack & skill animations -----------------------------------
    NII_ATTACK_SLICES = [(6, 218), (227, 94), (329, 222), (558, 114)]

    def get_nii_attack_frame(self, frame_idx=0, size=90):
        """Basic attack frames for Nii Yugito (blue flames/claws). 4 distinct frame poses."""
        filename = "nii_attack.png"
        if filename not in self._attack_imgs:
            candidates = [
                os.path.join(self.base_dir, "attacks", "nii_attack.png"),
                os.path.join(self.base_dir, "attacks", "Nii_attack.png")
            ]
            img = None
            for p in candidates:
                img = _load_surface(p)
                if img is not None:
                    break
            self._attack_imgs[filename] = img

        sheet = self._attack_imgs[filename]
        if sheet is None:
            return None

        idx = max(0, min(int(frame_idx), len(self.NII_ATTACK_SLICES) - 1))
        sx, sw = self.NII_ATTACK_SLICES[idx]
        oh = sheet.get_height()
        key = ("nii_attack_frame", idx, int(size))
        if key not in self._scaled:
            frame_surf = pygame.Surface((sw, oh), pygame.SRCALPHA)
            frame_surf.blit(sheet, (0, 0), (sx, 0, sw, oh))
            h = max(1, int(size))
            w = max(1, int(sw * h / oh))
            self._scaled[key] = _smooth(frame_surf, (w, h))
        return self._scaled[key]

    def get_blue_slash_animation_frame(self, time_sec=0.0, frame_idx=None, size=115):
        """Skill animation for Nii Yugito: assets/enemy_skills/blue_slash_animation.png (4 frames)."""
        filename = "blue_slash_animation.png"
        if filename not in self._enemy_skill_imgs:
            self._enemy_skill_imgs[filename] = _load_surface(os.path.join(self.base_dir, "enemy_skills", filename))
        sheet = self._enemy_skill_imgs[filename]
        if sheet is None:
            return None

        num_frames = 4
        if frame_idx is None:
            frame_idx = int(time_sec * 8) % num_frames
        else:
            frame_idx = max(0, min(int(frame_idx), num_frames - 1))

        ow = sheet.get_width()
        oh = sheet.get_height()
        x = int(frame_idx * ow / num_frames)
        x_next = int((frame_idx + 1) * ow / num_frames)
        fw = max(1, x_next - x)
        key = ("blue_slash_anim", frame_idx, int(size))
        if key not in self._scaled:
            frame_surf = pygame.Surface((fw, oh), pygame.SRCALPHA)
            frame_surf.blit(sheet, (0, 0), (x, 0, fw, oh))
            h = max(1, int(size))
            w = max(1, int(fw * h / oh))
            self._scaled[key] = _smooth(frame_surf, (w, h))
        return self._scaled[key]

    def get_blue_slash_projectile_frame(self, time_sec=0.0, frame_idx=None, size=75):
        """Slash projectile FX for Nii Yugito: assets/attacks/blue_slash.png (2 frames)."""
        filename = "blue_slash.png"
        if filename not in self._attack_imgs:
            self._attack_imgs[filename] = _load_surface(os.path.join(self.base_dir, "attacks", filename))
        sheet = self._attack_imgs[filename]
        if sheet is None:
            return None

        num_frames = 2
        if frame_idx is None:
            frame_idx = int(time_sec * 8) % num_frames
        else:
            frame_idx = max(0, min(int(frame_idx), num_frames - 1))

        ow = sheet.get_width()
        oh = sheet.get_height()
        x = int(frame_idx * ow / num_frames)
        x_next = int((frame_idx + 1) * ow / num_frames)
        fw = max(1, x_next - x)
        key = ("blue_slash_proj", frame_idx, int(size))
        if key not in self._scaled:
            frame_surf = pygame.Surface((fw, oh), pygame.SRCALPHA)
            frame_surf.blit(sheet, (0, 0), (x, 0, fw, oh))
            h = max(1, int(size))
            w = max(1, int(fw * h / oh))
            self._scaled[key] = _smooth(frame_surf, (w, h))
        return self._scaled[key]

    # --- Roushi (Stage 40 World Boss): Magma Shot, Super Magma Shot, skill cast sheet -----------
    # All are horizontal sheets. None = auto-detect the frame count from the aspect ratio
    # (width / height); set the real frame count here if a sheet animates wrongly.
    # Nine-Tails Chakra Naruto sheets are listed too: put the real frame count here if one animates wrongly
    # (naruto_attack / skill_naruto_rasengan / naruto_kurama_model_animation / aura_kurama).
    ATTACK_FRAME_COUNTS = {"magma_shot": None, "super_magma_shot": None, "roushi_skill": None,
                           "naruto_attack": None, "skill_naruto_rasengan": None,
                           "naruto_kurama_model_animation": None, "aura_kurama": None,
                           # Han (Stage 50 World Boss): set the real frame count if a sheet animates wrongly
                           "han_skill_animation": None, "bullet_han": None}

    def get_anim_frame(self, folder, names, size=80, time_sec=0.0, frame_idx=None, progress=None,
                       frames=None, fps=10):
        """Frame of a horizontal sheet in assets/<folder>/ (first existing name in `names` wins),
        scaled to `size` px tall and cached. Frame choice: `frame_idx`, else `progress` (0..1 across the
        whole sheet), else looping `time_sec * fps`. Returns None if no file exists."""
        names = (names,) if isinstance(names, str) else tuple(names)
        ck = (folder, names[0])
        if ck not in self._anim_imgs:
            img = None
            for n in names:
                stem, ext = os.path.splitext(n)
                for v in dict.fromkeys((n, stem.lower() + ext, stem.title() + ext, stem.capitalize() + ext)):
                    img = _load_surface(os.path.join(self.base_dir, folder, v))
                    if img is not None:
                        break
                if img is not None:
                    break
            self._anim_imgs[ck] = img
        sheet = self._anim_imgs[ck]
        if sheet is None:
            return None

        total_w, oh = sheet.get_size()
        if not frames:
            frames = self.ATTACK_FRAME_COUNTS.get(os.path.splitext(names[0])[0])
        if not frames:
            ratio = total_w / oh if oh else 1.0
            frames = 1 if ratio < 1.6 else min(16, int(round(ratio)))
        frames = max(1, int(frames))
        if frame_idx is not None:
            idx = max(0, min(int(frame_idx), frames - 1))
        elif progress is not None:
            idx = max(0, min(frames - 1, int(progress * frames)))
        else:
            idx = int(time_sec * fps) % frames
        h = max(1, int(size))
        key = ("anim_sheet", folder, names[0], frames, idx, h)
        if key not in self._scaled:
            x = int(idx * total_w / frames)
            x_next = int((idx + 1) * total_w / frames)
            fw = max(1, x_next - x)
            frame_surf = pygame.Surface((fw, oh), pygame.SRCALPHA)
            frame_surf.blit(sheet, (0, 0), (x, 0, fw, oh))
            w = max(1, int(fw * h / oh)) if oh else h
            self._scaled[key] = _smooth(frame_surf, (w, h))
        return self._scaled[key]

    def get_magma_shot_frame(self, time_sec=0.0, progress=None, size=46):
        """Roushi's basic attack projectile: assets/attacks/magma_shot.png (alias magmo_shot.png)."""
        return self.get_anim_frame("attacks", ("magma_shot.png", "magmo_shot.png"), size, time_sec,
                                   progress=progress, fps=12)

    def get_super_magma_shot_frame(self, time_sec=0.0, progress=None, size=96):
        """Roushi's skill projectile: assets/attacks/super_magma_shot.png."""
        return self.get_anim_frame("attacks", ("super_magma_shot.png",), size, time_sec,
                                   progress=progress, fps=12)

    def get_roushi_skill_frame(self, progress=0.0, size=150):
        """Roushi's casting animation: assets/enemy_skills/roushi_skill.png (progress 0 -> 1)."""
        return self.get_anim_frame("enemy_skills", ("roushi_skill.png",), size, progress=progress)

    # --- Han (Stage 50 World Boss): steam cannon cast sheet + projectile --------------------
    def get_han_skill_frame(self, progress=0.0, size=150):
        """Han's casting animation: assets/enemy_skills/han_skill_animation.png, progress 0 -> 1
        plays the whole sheet once. None if the file is missing (the caller draws a fallback)."""
        return self.get_anim_frame("enemy_skills", ("han_skill_animation.png",), size, progress=progress)

    def get_han_bullet_frame(self, time_sec=0.0, size=64):
        """Han's steam cannon projectile: assets/attacks/bullet_han.png. A single image is drawn as is;
        a horizontal sheet loops. None if the file is missing (the caller draws a fallback)."""
        return self.get_anim_frame("attacks", ("bullet_han.png",), size, time_sec, fps=12)

    # --- Nine-Tails Chakra Naruto (Naruto Evolution Tier 2) ----------------------------------
    def get_naruto_attack_frame(self, progress=0.0, size=100):
        """Melee dash/punch sheet assets/attacks/naruto_attack.png. progress 0 -> 1 spans the whole
        dash-strike-return, so the sheet plays once per basic attack. None if the file is missing."""
        return self.get_anim_frame("attacks", ("naruto_attack.png",), size, progress=progress)

    def get_naruto_rasengan_frame(self, time_sec=0.0, size=90):
        """Rasengan projectile ball assets/attacks/skill_naruto_rasengan.png (looping animation)."""
        return self.get_anim_frame("attacks", ("skill_naruto_rasengan.png",), size, time_sec, fps=14)

    def get_kurama_cast_frame(self, progress=0.0, size=150):
        """Casting animation assets/skills/naruto_kurama_model_animation.png, progress 0 -> 1."""
        return self.get_anim_frame("skills", ("naruto_kurama_model_animation.png",), size, progress=progress)

    def get_kurama_aura_frame(self, time_sec=0.0, size=140, alpha=KURAMA_AURA_ALPHA):
        """Kurama chakra cloak assets/skills/aura_kurama.png, looping, drawn translucent (alpha 0-255).
        The faded copy is cached per alpha bucket (steps of 8) so fading in/out stays cheap."""
        base = self.get_anim_frame("skills", ("aura_kurama.png",), size, time_sec, fps=8)
        if base is None:
            return None
        a = max(0, min(255, int(alpha))) // 8 * 8
        if a <= 0:
            return None
        key = ("kurama_aura_faded", id(base), a)
        if key not in self._scaled:
            faded = base.copy()
            faded.fill((255, 255, 255, a), special_flags=pygame.BLEND_RGBA_MULT)
            self._scaled[key] = faded
        return self._scaled[key]

    # --- Enemy & Mini-boss sprites (assets/enemies/ and assets/boss/) ------------
    ENEMY_FRAME_COUNTS = {
        "white_zetsu": 8,
        "zabuza_momochi": 8,
        "sasori_puppet": 8,
        "summon_snake": 8,
        "rogue_ninja": 4,
        "nii_yugito": 8,
        "yagura_karatachi": 8,
        "roushi": 8,
        "han": 8,
    }
    MINIBOSS_FPS = 8

    def get_enemy_image(self, name, size=70, time_sec=0.0, is_boss=False, is_miniboss=False, frames=None, flip=False):
        if not name:
            return None

        clean_name = name.strip()
        if clean_name.lower().endswith(" clone"):
            clean_name = clean_name[:-6].strip()
        if clean_name.lower().endswith(".png"):
            clean_name = clean_name[:-4].strip()

        slug = re.sub(r"[^a-z0-9]+", "_", clean_name.lower()).strip("_")
        filename = f"{slug}.png"

        if filename not in self._enemy_imgs:
            folders = ("boss", "enemies") if is_boss and not is_miniboss else ("enemies", "boss")
            candidates = []
            for folder in folders:
                candidates.extend([
                    os.path.join(self.base_dir, folder, filename),
                    os.path.join(self.base_dir, folder, f"{clean_name}.png"),
                    os.path.join(self.base_dir, folder, f"{slug.title()}.png"),
                    os.path.join(self.base_dir, folder, f"{slug.capitalize()}.png"),
                ])
                if "yugito" in slug:
                    candidates.append(os.path.join(self.base_dir, folder, "Nii_Yugito.png"))
                if "yagura" in slug:
                    candidates.extend([
                        os.path.join(self.base_dir, folder, "yagura_karatachi.png"),
                        os.path.join(self.base_dir, folder, "Yagura_Karatachi.png"),
                    ])

            img = None
            for p in candidates:
                img = _load_surface(p)
                if img is not None:
                    break
            self._enemy_imgs[filename] = img

        original = self._enemy_imgs[filename]
        if original is None:
            return None

        ow, oh = original.get_size()

        if frames is not None and frames > 0:
            num_frames = int(frames)
        elif slug in self.ENEMY_FRAME_COUNTS:
            num_frames = self.ENEMY_FRAME_COUNTS[slug]
        else:
            ratio = ow / oh if oh else 1.0
            if ratio >= 5.5:
                num_frames = 8
            elif ratio >= 2.2:
                num_frames = 4
            elif ratio >= 1.6:
                num_frames = max(2, int(round(ratio)))
            else:
                num_frames = 1

        h = max(1, int(size))
        if num_frames > 1:
            fps = 8 if (slug in self.ENEMY_FRAME_COUNTS or is_miniboss) else 6
            frame_idx = int(time_sec * fps) % num_frames
            x = int(frame_idx * ow / num_frames)
            x_next = int((frame_idx + 1) * ow / num_frames)
            fw = max(1, x_next - x)
            key = ("enemy_anim", filename, num_frames, frame_idx, h, bool(flip))
            if key not in self._scaled:
                frame_surf = pygame.Surface((fw, oh), pygame.SRCALPHA)
                frame_surf.blit(original, (0, 0), (x, 0, fw, oh))
                w = max(1, int(fw * h / oh)) if oh else h
                out = _smooth(frame_surf, (w, h))
                if flip:
                    out = pygame.transform.flip(out, True, False)
                self._scaled[key] = out
            return self._scaled[key]

        w = max(1, int(ow * h / oh)) if oh else h
        key = ("enemy_static", filename, w, h, bool(flip))
        if key not in self._scaled:
            out = _smooth(original, (w, h))
            if flip:
                out = pygame.transform.flip(out, True, False)
            self._scaled[key] = out
        return self._scaled[key]

    def get_miniboss_image(self, filename, size=110, time_sec=0.0, frames=None, flip=False):
        """Loads a mini-boss spritesheet from assets/enemies/ and returns the current animation frame,
        scaled to `size` px tall (cached). Delegates to `get_enemy_image` with explicit frame counts."""
        return self.get_enemy_image(
            filename,
            size=size,
            time_sec=time_sec,
            is_boss=False,
            is_miniboss=True,
            frames=frames,
            flip=flip,
        )

    def _load_original(self, filename):
        if filename in self._originals:
            return self._originals[filename]
        self._originals[filename] = _load_surface(os.path.join(self.assets_dir, filename))
        return self._originals[filename]

    def _sheet_frame(self, filename, sheet, num_frames, time_sec, size, fps=8):
        """One clean, non-overlapping frame of a horizontal character sheet, scaled to `size` px tall.
        Frame width is exactly sheet_width // num_frames; any leftover pixels are split evenly
        between the left and right edge so every frame stays centred on its cell."""
        total_w, oh = sheet.get_size()
        num_frames = max(1, int(num_frames))
        ow = max(1, total_w // num_frames)
        margin = max(0, (total_w - ow * num_frames) // 2)
        frame_idx = int(time_sec * fps) % num_frames
        h = max(1, int(size))
        key = (filename, "sheet_fixed", num_frames, frame_idx, h)
        if key not in self._scaled:
            frame_surf = pygame.Surface((ow, oh), pygame.SRCALPHA)
            frame_surf.blit(sheet, (0, 0), (margin + frame_idx * ow, 0, ow, oh))
            w = max(1, int(ow * h / oh)) if oh else h
            self._scaled[key] = _smooth(frame_surf, (w, h))
        return self._scaled[key]

    def get_character_image(self, name, evo_stage=0, size=64, time_sec=0.0):
        filename = self.filename_for(name, evo_stage)
        original = self._load_original(filename)
        if original is None and evo_stage > 0 and name.lower() not in ANIMATED_CHARACTERS:
            filename = self.filename_for(name, 0)
            original = self._load_original(filename)
        if original is None:
            return None

        name_l = name.strip().lower()
        # Nine-Tails Chakra Naruto (Evolution Tier 2): naruto_evo2.png, FIXED frame count.
        # (The old aspect-ratio auto-detect mis-counted frames, so the slice was too wide and
        # showed two Narutos side by side.)
        if name_l in KURAMA_NARUTO_NAMES or (name_l == "naruto" and evo_stage == 2):
            return self._sheet_frame(filename, original, KURAMA_CHARACTER_FRAMES, time_sec, size)

        # Naruto và Sage Naruto: 8 frames
        if name_l in ("naruto", "sage naruto"):
            num_frames = 8
            ow = original.get_width() // num_frames
            oh = original.get_height()
            frame_idx = int(time_sec * 8) % num_frames
            key_frame = (filename, frame_idx, size)

            if key_frame not in self._scaled:
                frame_surf = pygame.Surface((ow, oh), pygame.SRCALPHA)
                frame_surf.blit(original, (0, 0), (frame_idx * ow, 0, ow, oh))
                h = int(size)
                w = int(ow * h / oh) if oh else h
                self._scaled[key_frame] = _smooth(frame_surf, (max(1, w), max(1, h)))
            return self._scaled[key_frame]

        # Sasuke: 5 frames thường, 8 frames khi thức tỉnh
        if name_l in ("sasuke", "curse mark sasuke", "taka sasuke"):
            num_frames = 8 if evo_stage >= 1 else 5
            ow = original.get_width() // num_frames
            oh = original.get_height()
            frame_idx = int(time_sec * 8) % num_frames
            key_frame = (filename, frame_idx, size)

            if key_frame not in self._scaled:
                frame_surf = pygame.Surface((ow, oh), pygame.SRCALPHA)
                frame_surf.blit(original, (0, 0), (frame_idx * ow, 0, ow, oh))
                h = int(size)
                w = int(ow * h / oh) if oh else h
                self._scaled[key_frame] = _smooth(frame_surf, (max(1, w), max(1, h)))
            return self._scaled[key_frame]

        # Sakura & Chakra Surge Sakura: cố định chính xác 8 frames theo file spritesheet
        if name_l in ("sakura", "medic sakura", "chakra surge sakura", "inner sakura", "medical ninja sakura"):
            num_frames = 8
            total_w = original.get_width()
            oh = original.get_height()
            frame_idx = int(time_sec * 8) % num_frames
            x = int(frame_idx * total_w / num_frames)
            x_next = int((frame_idx + 1) * total_w / num_frames)
            ow = max(1, x_next - x)
            key_frame = (filename, "sakura_fixed", frame_idx, int(size))

            if key_frame not in self._scaled:
                frame_surf = pygame.Surface((ow, oh), pygame.SRCALPHA)
                frame_surf.blit(original, (0, 0), (x, 0, ow, oh))
                h = int(size)
                w = int(ow * h / oh) if oh else h
                self._scaled[key_frame] = _smooth(frame_surf, (max(1, w), max(1, h)))
            return self._scaled[key_frame]

        ow, oh = original.get_size()
        h = int(size)
        w = int(ow * h / oh) if oh else h
        key = (filename, max(1, w), max(1, h))
        if key not in self._scaled:
            self._scaled[key] = _smooth(original, (max(1, w), max(1, h)))
        return self._scaled[key]

    def get_shadow_clone_image(self, size=64, time_sec=0.0):
        base = self.get_character_image("Naruto", 0, size, time_sec)
        if base is None:
            return None
        key = ("clone_tint", id(base))
        if key not in self._scaled:
            tinted = base.copy()
            tinted.fill((150, 190, 255, 215), special_flags=pygame.BLEND_RGBA_MULT)
            self._scaled[key] = tinted
        return self._scaled[key]

    def clear_cache(self):
        self._attack_imgs.clear()
        self._originals.clear()
        self._scaled.clear()
        self._skill_imgs.clear()
        self._enemy_imgs.clear()
        self._enemy_skill_imgs.clear()
        self._item_imgs.clear()
        self._anim_imgs.clear()