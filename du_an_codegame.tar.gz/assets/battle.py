"""battle.py - real-time PvE battle simulation (units, waves, skills, effects)."""
import math
import random

from config import *


def slot_ys(n):
    n = max(1, min(3, int(n)))
    return {1: [262], 2: [207, 317], 3: [152, 262, 372]}[n]


ENEMY_POOL = [("Slime", (90, 200, 120), "Physical"), ("Goblin", (120, 170, 70), "Physical"),
              ("Skeleton", (210, 210, 200), "Physical"), ("Wraith", (150, 120, 220), "Magic"),
              ("Orc", (170, 115, 80), "Physical")]
BOSSES = [("Goblin King", (80, 150, 60), "Physical"), ("Bone Lich", (180, 180, 230), "Magic"),
          ("Ember Drake", (220, 90, 50), "Magic")]

CLONE_NAME = "Shadow Clone"
CLONE_DURATION = 15.0
CLONE_OFFSET_X = 40
CLONE_RATIO = {"hp": 0.4, "atk": 0.6, "df": 0.5}
ATK_SPEED_STEP = 0.85
CLONE_SMOKE = (200, 205, 220)

SAND_SHIELD_CHANCE = 0.05
SAND_SHIELD_DURATION = 5.0
SAND_SHIELD_MULT = 0.75
SAND_COLOR = (235, 195, 95)

SAND_HAND_CHANCE = 0.10
SAND_HAND_MULT = 2.0
SAND_HAND_DUR = 0.45

# Melee punch (Sakura & Yagura Karatachi): dash in -> strike -> return.
# PUNCH_HIT_AT = fraction of the animation when damage lands.
PUNCH_DUR = 0.60
PUNCH_HIT_AT = 0.42
PUNCH_STAND_OFF = 70

YAGURA_PETRIFY_HITS = 5
YAGURA_STUN_DURATION = 3.0
PETRIFY_COLOR = (180, 180, 190)

# Roushi (Stage 40 World Boss): Magma Shot basic attack + 15s Super Magma Shot skill that burns.
ROUSHI_SKILL_INTERVAL = 15.0
ROUSHI_SHOT_TRAVEL = 0.38       # flight time of a Magma Shot
ROUSHI_CAST_TIME = 0.60         # roushi_skill.png casting animation before the super shot is fired
ROUSHI_SUPER_TRAVEL = 0.55      # flight time of the Super Magma Shot
ROUSHI_SKILL_MULT = 2.8         # skill damage multiplier (x boss ATK, Magic)
ROUSHI_BURN_TICKS = 5
ROUSHI_BURN_INTERVAL = 1.0      # seconds between burn ticks
ROUSHI_BURN_MAX_HP_PCT = 0.015  # each tick: 1.5% of the target's Max HP ...
ROUSHI_BURN_ATK_PCT = 0.15      # ... or 15% of the boss's ATK, whichever is larger

# Han (Stage 50 World Boss): Steam Armor passive (+15% DEF every 10s) + 10s Steam Cannon skill.
HAN_PASSIVE_INTERVAL = 10.0     # seconds between defense boosts (first one 10s after combat starts)
HAN_DEF_GROWTH = 0.15           # each boost: DEF +15% (compounding, permanent for the battle)
HAN_DEF_MAX_STACKS = 10         # safety cap on boosts (1.15^10 = ~4x DEF); None = unlimited
HAN_SKILL_INTERVAL = 10.0       # seconds between Steam Cannon casts
HAN_CAST_TIME = 0.60            # han_skill_animation.png plays this long before the cannon is fired
HAN_SHOT_TRAVEL = 0.50          # flight time of the steam blast (bullet_han.png)
HAN_SKILL_MULT = 1.5            # skill damage = 1.5 x Han's CURRENT ATK

HEAL_COLOR = (120, 255, 170)
HEAL_AUTO_THRESHOLD = 0.80   # AUTO mode only casts a heal when an ally is at/below 80% HP

MINIBOSS_CLONE_Y_RANGE = (110, 420)   # clones are clamped to this vertical band of the arena


def stage_drop_table(map_def, stage):
    boss = is_boss_stage(stage)
    rows = []
    map_bosses = map_def.get("bosses")
    num_bosses = len(map_bosses) if map_bosses else 2
    cycle = max(10, num_bosses * BOSS_STAGE_INTERVAL)
    for d in map_def.get("drops", []):
        tgt = d.get("target_stage")
        if tgt is not None:
            if not boss:
                continue
            if stage != tgt and not (isinstance(tgt, int) and stage % cycle == tgt % cycle):
                continue

        boosted = boss and ("boss_chance" in d or "boss_qty_mult" in d)
        if boss and "boss_chance" in d:
            chance = min(d.get("boss_cap", 1.0), d["boss_chance"] + d.get("bonus", 0.0) * (stage - 1))
        else:
            chance = min(d.get("cap", 1.0), d["chance"] + d.get("bonus", 0.0) * (stage - 1))
        if chance <= 0:
            continue
        mult = d.get("boss_qty_mult", 1) if boss else 1
        extra = int((stage - 1) * d.get("qty_per_stage", 0))
        rows.append({"item": d["item"], "chance": chance, "note": d.get("note"), "boosted": boosted,
                     "lo": d["min"] * mult + extra, "hi": d["max"] * mult + extra})
    return rows


def roll_drops(map_def, stage):
    drops = {}
    for r in stage_drop_table(map_def, stage):
        if random.random() < r["chance"]:
            drops[r["item"]] = drops.get(r["item"], 0) + random.randint(r["lo"], r["hi"])
    return drops


class Unit:
    poison_pct = 0.0     # fraction of damage output lost to poison/venom (capped in config)
    poison_timer = 0.0
    stun_timer = 0.0     # petrify / stun timer in seconds (Yagura Karatachi 5-hit passive)
    ward_timer = 0.0     # Kurama's Cloak: seconds of damage reduction left
    ward_pct = 0.0       # Kurama's Cloak: fraction of incoming damage ignored while ward_timer > 0
    skill_charge = 0     # landed basic attacks towards a charge skill (Kurama Rasengan)
    def_stacks = 0       # Han's Steam Armor: number of +15% DEF boosts gained so far

    @property
    def atk(self):
        """Effective ATK: base ATK reduced by active poison. Every damage formula reads this."""
        return max(1, int(self.base_atk * (1.0 - self.poison_pct)))

    @atk.setter
    def atk(self, value):
        self.base_atk = value

    def __init__(self, name, hp, atk, df, dmg_type, color, is_player, x, y, char=None, boss=False,
                 world_boss=False, miniboss=None):
        self.name, self.max_hp, self.hp = name, hp, hp
        self.miniboss = miniboss        # config.MINIBOSSES entry, or None
        self.is_clone = False           # True for White Zetsu's clones
        self.bleeds = []                # active bleed stacks on this unit
        self.bleed_hits = {}            # target -> consecutive basic hits (Zabuza)
        self.burn = None                # {'dmg','ticks','next'} while burning (Roushi's skill)
        self.world_boss = world_boss
        self.atk, self.df, self.dmg_type, self.color = atk, df, dmg_type, color
        self.is_player, self.x, self.y, self.boss = is_player, x, y, boss
        self.char = char
        self.tpl = char.tpl if char else None
        self.evo_stage = char.evo_stage if char else 0
        self.passive = char.passive if char else None
        self.passive_timer = 0.0
        self.owner, self.life = None, 0.0
        self.skill = char.skill if char else None
        # charge skills (Kurama Rasengan) have no cooldown: they are gated by landed basic hits instead
        self.cd = 0.0 if (self.skill and self.skill.charge_hits) else (2.0 if self.skill else 0.0)
        self.kurama = bool(self.passive and self.passive.key == "kurama_cloak")
        self.timer = random.uniform(0, 0.7)
        self.interval = 1.2 if is_player else 2.0
        self.lunge = self.flash = 0.0
        self.shield_timer = 0.0
        self.stun_timer = 0.0
        self.alive = True
        self.target_hits = {}
        self.sand_user = bool(world_boss and name == "Gaara")
        self.yugito_user = bool(world_boss and name == "Nii Yugito")
        self.yagura_user = bool(name == "Yagura Karatachi")
        self.yagura_hit_count = 0
        self.roushi_user = bool(world_boss and name == "Roushi")
        self.han_user = bool(world_boss and name == "Han")
        self.def_stacks = 0
        if self.roushi_user:
            self.skill_timer = ROUSHI_SKILL_INTERVAL
        elif self.han_user:
            self.skill_timer = HAN_SKILL_INTERVAL
        else:
            self.skill_timer = 15.0 if self.yugito_user else 0.0
        self.melee = bool((is_player and char is not None and getattr(char, "melee", False))
                          or self.yagura_user)
        self.punch_t, self.punch_tgt = 0.0, None
        self.punch_dmg, self.punch_crit, self.punch_hit = 0, False, True


class BattleManager:
    def __init__(self, chars, stage, map_id=DEFAULT_MAP_ID):
        self.map = MAP_BY_ID.get(map_id, MAPS[0])
        self.map_id = self.map["id"]
        self.stage, self.time, self.speed, self.auto = stage, 0.0, 1, True
        self.boss_stage = is_boss_stage(stage)
        self.max_waves = 1 if self.boss_stage else MAX_WAVES
        self.state = "fighting"
        self.players = []
        chars = list(chars)[:TEAM_SIZE]
        for c, y in zip(chars, slot_ys(len(chars))):
            hp, atk, df = c.stats()
            self.players.append(Unit(c.name, hp, atk, df, c.tpl.dmg_type, c.color, True, 230, y, c))
        self.enemies, self.wave, self.wave_delay = [], 0, 0.0
        self.clones = []
        self.popups, self.fx, self.log = [], [], []
        self.shake = 0.0
        self.rewards = None
        self.add_log(f"{self.map['name']} - Stage {stage} begins!", (255, 230, 150))
        self.spawn_wave()

    def add_log(self, s, color=TEXT):
        self.log.append((s, color))
        self.log = self.log[-9:]

    def alive(self, units):
        return [u for u in units if u.alive]

    def spawn_wave(self):
        self.wave += 1
        f = 1 + 0.4 * (self.stage - 1)
        map_enemies = self.map.get("enemies") or ENEMY_POOL
        map_bosses = self.map.get("bosses") or BOSSES

        if self.boss_stage:
            name, col, dmg_type = map_bosses[(self.stage // BOSS_STAGE_INTERVAL - 1) % len(map_bosses)]
            hp = int(80 * f * BOSS_HP_PER_STAGE * self.stage)
            atk = int(11 * f * (1 + BOSS_ATK_PER_STAGE * self.stage))
            df = int(3 * f * 1.8)
            self.enemies = [Unit(name, hp, atk, df, dmg_type, col, False, 830, slot_ys(1)[0],
                                 boss=True, world_boss=True)]
            self.add_log(f"SOLO BOSS: {name} appears!", (255, 120, 90))
            return

        final = self.wave == self.max_waves
        mini = None
        if random.random() < (MINIBOSS_CHANCE_FINAL if final else MINIBOSS_CHANCE_EARLY):
            mini = self._pick_miniboss()

        # spec = (enemy tuple or None, is_boss, miniboss def or None)
        if final:
            specs = [(map_bosses[(self.stage - 1) % len(map_bosses)], True, None),
                     (random.choice(map_enemies), False, None)]
        else:
            count = min(3, 1 + self.wave)
            specs = [(random.choice(map_enemies), False, None) for _ in range(count)]

        if mini is not None and specs:            # the mini-boss takes the first slot of the wave
            specs[0] = (None, True, mini)

        self.enemies = []
        ys = slot_ys(len(specs))
        for (base, boss, mb), y in zip(specs, ys):
            if mb is not None:
                self.enemies.append(self._make_miniboss(mb, f, y))
                continue
            if base is None:
                base = random.choice(map_enemies)
                boss = False
            name, col, dmg_type = base
            m = 3.0 if boss else 1.0
            self.enemies.append(Unit(name, int(80 * f * m), int((8 if not boss else 11) * f),
                                     int(3 * f * (1.8 if boss else 1)), dmg_type, col,
                                     False, 830, y, boss=boss))

        self.add_log(f"Wave {self.wave}/{self.max_waves}" + ("  - BOSS!" if final else ""), (255, 200, 120))
        for u in list(self.enemies):
            if u.miniboss:
                self.add_log(f"MINI-BOSS: {u.name}! {u.miniboss.get('tip', '')}", (255, 150, 110))
                if u.miniboss.get("clones"):
                    self._spawn_clones(u, u.miniboss["clones"])

    # --- Mini-boss spawning & mechanics --------------------------------------------------
    def _pick_miniboss(self):
        allowed = self.map.get("minibosses")      # optional per-map whitelist of mini-boss ids
        pool = [m for m in MINIBOSSES if m and (allowed is None or m.get("id") in allowed)]
        if not pool:
            return None
        weights = [max(1, m.get("weight", 1)) for m in pool]
        return random.choices(pool, weights=weights)[0]

    def _make_miniboss(self, mb, f, y):
        hp = int(80 * f * mb.get("hp_mult", 2.8))
        atk = int(11 * f * mb.get("atk_mult", 1.0))
        df = int(3 * f * mb.get("df_mult", 1.5))
        return Unit(mb["name"], hp, atk, df, mb["dmg_type"], mb["color"], False, 830, y,
                    boss=True, miniboss=mb)

    def _spawn_clones(self, boss, cfg):
        """White Zetsu: on entering battle, split off clones with a % of his HP and damage."""
        lo, hi = MINIBOSS_CLONE_Y_RANGE
        offsets = (-70, 70, -140, 140)
        for i in range(cfg["count"]):
            y = max(lo, min(hi, boss.y + offsets[i % len(offsets)]))
            x = MINIBOSS_CLONE_X + 14 * (i % 2)
            c = Unit(boss.name + MINIBOSS_CLONE_SUFFIX, max(1, int(boss.max_hp * cfg["hp_pct"])),
                     max(1, int(boss.base_atk * cfg["dmg_pct"])), boss.df, boss.dmg_type, boss.color,
                     False, x, y, miniboss=boss.miniboss)
            c.is_clone = True
            self.enemies.append(c)
            self.add_sparks(c.x, c.y, (235, 240, 235), 12)
            self.fx.append({"t": "ring", "x": c.x, "y": c.y, "life": 0.4, "dur": 0.4,
                            "c": (235, 240, 235), "r": 60, "w": 5})
        self.popups.append({"text": "CLONES!", "x": boss.x, "y": boss.y - 85, "life": 1.2,
                            "color": (235, 240, 235), "size": 22})
        self.add_log(f"{boss.name} splits into {cfg['count']} clones!", (235, 240, 235))

    def _miniboss_on_hit(self, att, tgt):
        """Runs after a mini-boss basic attack lands: Zabuza's bleed counter, Sasori/Snake poison."""
        mb = att.miniboss
        if not mb or att.is_clone or not tgt.alive:
            return
        if mb.get("bleed"):
            self._bleed_counter(att, tgt, mb["bleed"])
        if mb.get("poison"):
            self._apply_poison(tgt, mb["poison"])

    def _bleed_counter(self, att, tgt, cfg):
        n = att.bleed_hits.get(tgt, 0) + 1
        if n < cfg["hits"]:
            att.bleed_hits[tgt] = n
            return
        att.bleed_hits[tgt] = 0
        if len(tgt.bleeds) >= cfg["max_stacks"]:
            tgt.bleeds.pop(0)                     # replace the oldest stack
        tgt.bleeds.append({"dmg": max(1, int(att.atk * cfg["atk_pct"])), "ticks": cfg["ticks"],
                           "interval": cfg["interval"], "next": cfg["interval"]})
        self.popups.append({"text": "BLEEDING!", "x": tgt.x, "y": tgt.y - 85, "life": 1.0,
                            "color": BLEED_COLOR, "size": 20})
        self.add_sparks(tgt.x, tgt.y, BLEED_COLOR, 10)
        self.add_log(f"{att.name}'s blade makes {tgt.name} bleed! ({len(tgt.bleeds)} stack"
                     f"{'s' if len(tgt.bleeds) > 1 else ''})", BLEED_COLOR)

    def _apply_poison(self, tgt, cfg):
        first = tgt.poison_pct <= 0
        tgt.poison_pct = min(cfg["cap"], tgt.poison_pct + random.uniform(cfg["min"], cfg["max"]))
        tgt.poison_timer = cfg["duration"]
        self.popups.append({"text": f"{cfg['label']} -{tgt.poison_pct * 100:.1f}% DMG", "x": tgt.x,
                            "y": tgt.y - 85, "life": 1.0, "color": cfg["color"], "size": 16})
        if first:
            self.add_log(f"{tgt.name} is afflicted by {cfg['label'].lower()}! Damage output reduced.",
                         cfg["color"])

    def _apply_yagura_hit(self, att, tgt):
        """Yagura Karatachi 5-hit Petrify / Stun mechanic: every 5th basic attack turns target into stone for 3s."""
        if not tgt.alive:
            return
        att.yagura_hit_count = getattr(att, "yagura_hit_count", 0) + 1
        att.target_hits[tgt] = att.target_hits.get(tgt, 0) + 1
        if att.yagura_hit_count >= YAGURA_PETRIFY_HITS or att.target_hits[tgt] >= YAGURA_PETRIFY_HITS:
            att.yagura_hit_count = 0
            att.target_hits[tgt] = 0
            tgt.stun_timer = YAGURA_STUN_DURATION
            if tgt.punch_t > 0:
                tgt.punch_t, tgt.punch_hit = 0.0, True
            self.popups.append({
                "text": "PETRIFIED! (STUN 3s)",
                "x": tgt.x,
                "y": tgt.y - 85,
                "life": 1.4,
                "color": PETRIFY_COLOR,
                "size": 21
            })
            self.add_sparks(tgt.x, tgt.y, PETRIFY_COLOR, 16)
            self.fx.append({"t": "ring", "x": tgt.x, "y": tgt.y, "life": 0.45, "dur": 0.45,
                            "c": PETRIFY_COLOR, "r": 70, "w": 6})
            self.add_log(f"{att.name}'s Coral Strike turns {tgt.name} into stone for 3s!", PETRIFY_COLOR)

    def _update_statuses(self, dt):
        for u in self.alive(self.players) + self.alive(self.clones):
            if u.stun_timer > 0:
                u.stun_timer = max(0.0, u.stun_timer - dt)
            if u.poison_timer > 0:
                u.poison_timer = max(0.0, u.poison_timer - dt)
                if u.poison_timer <= 0 and u.poison_pct > 0:
                    u.poison_pct = 0.0
                    self.popups.append({"text": "Poison wore off", "x": u.x, "y": u.y - 60, "life": 0.8,
                                        "color": (170, 230, 170), "size": 14})
            for bl in list(u.bleeds):
                bl["next"] -= dt
                while bl["next"] <= 0 and bl["ticks"] > 0 and u.alive:
                    bl["ticks"] -= 1
                    bl["next"] += bl["interval"]
                    self.hit(u, bl["dmg"], False, BLEED_COLOR)
                if bl["ticks"] <= 0 or not u.alive:
                    u.bleeds.remove(bl)
            self._tick_burn(u, dt)

    def _clear_statuses(self):
        for u in self.players + self.clones:
            u.bleeds.clear()
            u.burn = None
            u.poison_pct, u.poison_timer = 0.0, 0.0
            u.stun_timer = 0.0

    @staticmethod
    def calc(atk, mult, df, dmg_type):
        eff = df if dmg_type == "Physical" else df * 0.5
        d = atk * mult * random.uniform(0.9, 1.1) - eff * 0.6
        crit = random.random() < 0.1
        if crit:
            d *= 1.5
        return max(1, int(d)), crit

    def add_sparks(self, x, y, color, n):
        for _ in range(n):
            a = random.uniform(0, math.tau)
            sp = random.uniform(60, 220)
            self.fx.append({"t": "spark", "x": x, "y": y, "vx": math.cos(a) * sp, "vy": math.sin(a) * sp,
                            "life": 0.5, "dur": 0.5, "c": color})

    def hit(self, target, dmg, crit, color):
        if target.ward_timer > 0:                      # Kurama's Cloak: -15% incoming damage
            dmg = max(1, int(dmg * (1.0 - target.ward_pct)))

        if target.shield_timer > 0:
            dmg = max(1, int(dmg * SAND_SHIELD_MULT))

        if target.sand_user and target.shield_timer <= 0:
            if random.random() < SAND_SHIELD_CHANCE:
                target.shield_timer = SAND_SHIELD_DURATION
                dmg = max(1, int(dmg * SAND_SHIELD_MULT))
                self.popups.append({
                    "text": "SAND SHIELD! (-25% DMG)",
                    "x": target.x,
                    "y": target.y - 92,
                    "life": 1.3,
                    "color": SAND_COLOR,
                    "size": 21
                })
                self.add_log("Boss activated Sand Shield! Damage reduced by 25% for 5s.", SAND_COLOR)

        target.hp -= dmg
        target.flash = 0.15
        self.popups.append({"text": str(dmg) + ("!" if crit else ""), "x": target.x + random.randint(-15, 15),
                            "y": target.y - 60, "life": 0.9,
                            "color": (255, 240, 90) if crit else color, "size": 26 if crit else 20})
        if target.hp <= 0 and target.alive:
            target.hp, target.alive = 0, False
            target.shield_timer = 0.0
            target.stun_timer = 0.0
            self.add_log(f"{target.name} was defeated.", (200, 200, 210) if not target.is_player else BAD)
            self.add_sparks(target.x, target.y, target.color, 18)

    def trigger_amaterasu(self, att, tgt):
        self.add_log(f"{att.name} triggers Amaterasu!", (200, 50, 220))
        burn_dmg = max(1, int(att.atk * 0.4))
        for i in range(5):
            self.fx.append({"t": "amaterasu_burn", "x": tgt.x, "y": tgt.y, "delay": i * 0.25,
                            "life": 0.3, "dur": 0.3, "tgt": tgt, "dmg": burn_dmg})

    def basic_attack(self, att, tgt):
        if getattr(att, "stun_timer", 0.0) > 0:
            return
        if att.melee and att.punch_t > 0:
            return
        att.timer, att.lunge = 0.0, 0.25

        if att.sand_user and random.random() < SAND_HAND_CHANCE:
            att.lunge = 0.35
            dmg, crit = self.calc(att.atk, SAND_HAND_MULT, tgt.df, att.dmg_type)
            self.shake = 0.25
            self.popups.append({
                "text": "SAND HAND!",
                "x": att.x,
                "y": att.y - 85,
                "life": 1.2,
                "color": SAND_COLOR,
                "size": 22
            })
            self.add_log(f"{att.name} unleashes Sand Hand!", SAND_COLOR)
            self.fx.append({
                "t": "sand_hand",
                "x": tgt.x,
                "y": tgt.y,
                "life": SAND_HAND_DUR,
                "dur": SAND_HAND_DUR,
                "tgt": tgt,
                "dmg": dmg,
                "crit": crit
            })
            return

        if getattr(att, "yugito_user", False):
            att.timer = 0.0
            att.lunge = 0.35
            dmg, crit = self.calc(att.atk, 1.0, tgt.df, att.dmg_type)
            self.fx.append({
                "t": "nii_basic_attack",
                "x": tgt.x,
                "y": tgt.y,
                "life": 0.35,
                "dur": 0.35,
                "tgt": tgt,
                "dmg": dmg,
                "crit": crit
            })
            self.add_sparks(tgt.x, tgt.y, (80, 160, 255), 10)
            return

        if getattr(att, "roushi_user", False):          # Magma Shot: a projectile that lands after a short flight
            att.timer = 0.0
            att.lunge = 0.3
            dmg, crit = self.calc(att.atk, 1.0, tgt.df, att.dmg_type)
            self.fx.append({"t": "magma_shot", "x": att.x - 45, "y": att.y - 10, "tx": tgt.x, "ty": tgt.y,
                            "life": ROUSHI_SHOT_TRAVEL, "dur": ROUSHI_SHOT_TRAVEL,
                            "tgt": tgt, "dmg": dmg, "crit": crit})
            self.add_sparks(att.x - 45, att.y - 10, MAGMA_COLOR, 6)
            return

        dmg, crit = self.calc(att.atk, 1.0, tgt.df, att.dmg_type)

        p = att.passive
        if p and p.key == "atk_speed" and random.random() < p.chance:
            att.interval = max(0.6, att.interval * ATK_SPEED_STEP)
            self.popups.append({"text": "+15% ATK SPD", "x": att.x, "y": att.y - 40,
                                "life": 0.8, "color": (100, 255, 180), "size": 16})

        if p and p.key == "amaterasu":
            att.target_hits[tgt] = att.target_hits.get(tgt, 0) + 1
            if att.target_hits[tgt] >= 3:
                att.target_hits[tgt] = 0
                self.trigger_amaterasu(att, tgt)

        self.try_shadow_clone(att)

        if att.melee:
            att.lunge = 0.0
            att.punch_t, att.punch_tgt = PUNCH_DUR, tgt
            att.punch_dmg, att.punch_crit, att.punch_hit = dmg, crit, False
            return

        if att.name in ("Naruto", "Sage Naruto", "Sasuke", "Curse Mark Sasuke", "Taka Sasuke", CLONE_NAME):
            self.fx.append({"t": "kunai", "x": att.x, "y": att.y, "tx": tgt.x, "ty": tgt.y,
                            "life": 0.22, "dur": 0.22, "tgt": tgt, "dmg": dmg, "crit": crit})
            return

        if att.dmg_type == "Magic":
            self.fx.append({"t": "beam", "a": (att.x, att.y), "b": (tgt.x, tgt.y), "life": 0.2, "dur": 0.2,
                            "c": (150, 190, 255), "w": 4})
        else:
            self.fx.append({"t": "beam", "a": (tgt.x - 30, tgt.y - 30), "b": (tgt.x + 30, tgt.y + 30),
                            "life": 0.18, "dur": 0.18, "c": (255, 255, 255), "w": 5})
        self.hit(tgt, dmg, crit, (255, 255, 255) if att.is_player else (255, 120, 120))
        self._miniboss_on_hit(att, tgt)
        self._register_basic_hit(att)

    # --- Kurama Link Naruto: 5-hit charge skill + Kurama's Cloak ------------------------------
    def skill_ready(self, u):
        """True when u's active skill is castable right now ignoring targets (cooldown / charge / stun)."""
        sk = u.skill
        if sk is None or not u.alive or u.cd > 0 or getattr(u, "stun_timer", 0.0) > 0:
            return False
        return not sk.charge_hits or u.skill_charge >= sk.charge_hits

    def _register_basic_hit(self, att):
        """A basic attack of a player unit has LANDED: charge its skill (Kurama Rasengan: 5 hits)."""
        sk = att.skill
        if not att.is_player or not att.alive or sk is None or not sk.charge_hits:
            return
        if att.skill_charge >= sk.charge_hits:
            return
        att.skill_charge += 1
        if att.skill_charge >= sk.charge_hits:
            self.popups.append({"text": f"{sk.name.upper()} READY!", "x": att.x, "y": att.y - 70,
                                "life": 1.2, "color": KURAMA_COLOR, "size": 20})
            self.add_log(f"{att.name} has charged {sk.name}!", KURAMA_COLOR)
            self.add_sparks(att.x, att.y, KURAMA_COLOR, 12)
        else:
            self.popups.append({"text": f"{att.skill_charge}/{sk.charge_hits}", "x": att.x, "y": att.y - 55,
                                "life": 0.7, "color": KURAMA_COLOR, "size": 14})

    def _wants_auto_cast(self, u):
        """AUTO mode casts every ready skill. A charged skill also fires by itself when KURAMA_AUTO_FIRE
        is on, but only once the dash-punch that charged it has finished (Naruto is back in his slot)."""
        sk = u.skill
        if sk is not None and sk.charge_hits:
            return (self.auto or KURAMA_AUTO_FIRE) and u.punch_t <= 0
        return self.auto

    def trigger_kurama_ward(self, u):
        """Kurama's Cloak: every living ally takes KURAMA_WARD_REDUCTION less damage for KURAMA_WARD_DURATION s."""
        allies = self.alive(self.players) + self.alive(self.clones)
        pct = int(round(KURAMA_WARD_REDUCTION * 100))
        self.popups.append({"text": f"KURAMA WARD! (-{pct}% DMG)", "x": u.x, "y": u.y - 95, "life": 1.8,
                            "color": KURAMA_COLOR, "size": 22})
        self.add_log(f"{u.name} wraps the team in Kurama's Cloak! -{pct}% damage for "
                     f"{int(KURAMA_WARD_DURATION)}s.", KURAMA_COLOR)
        self.fx.append({"t": "ring", "x": u.x, "y": u.y, "life": 0.6, "dur": 0.6, "c": KURAMA_COLOR,
                        "r": 260, "w": 8})
        for ally in allies:
            ally.ward_timer = KURAMA_WARD_DURATION
            ally.ward_pct = KURAMA_WARD_REDUCTION
            self.add_sparks(ally.x, ally.y, KURAMA_COLOR, 10)
            self.fx.append({"t": "ring", "x": ally.x, "y": ally.y, "life": 0.45, "dur": 0.45,
                            "c": (255, 190, 90), "r": 90, "w": 5})
            if ally is not u:
                self.popups.append({"text": f"-{pct}% DMG", "x": ally.x, "y": ally.y - 62, "life": 1.2,
                                    "color": KURAMA_COLOR, "size": 16})

    def trigger_kurama_rasengan(self, u, sk, tgt):
        """Cast animation (naruto_kurama_model_animation.png), then the Rasengan ball flies out."""
        self.popups.append({"text": "KURAMA RASENGAN!", "x": u.x, "y": u.y - 90, "life": 1.5,
                            "color": KURAMA_COLOR, "size": 24})
        self.fx.append({"t": "kurama_cast", "x": u.x, "y": u.y - 5, "life": KURAMA_CAST_TIME,
                        "dur": KURAMA_CAST_TIME})
        self.fx.append({"t": "naruto_rasengan", "x": u.x + 55, "y": u.y - 5, "tx": tgt.x, "ty": tgt.y,
                        "delay": KURAMA_CAST_TIME, "life": KURAMA_RASENGAN_TRAVEL,
                        "dur": KURAMA_RASENGAN_TRAVEL, "tgt": tgt, "u": u, "sk": sk})
        self.add_sparks(u.x, u.y, KURAMA_COLOR, 18)

    def _land_kurama_rasengan(self, e):
        """Rasengan impact: big hit on the target (re-targets if it died in flight) + splash on the rest."""
        sk, u = e["sk"], e["u"]
        tgt = e["tgt"] if e["tgt"].alive else next(iter(self.alive(self.enemies)), None)
        if tgt is None:
            return
        dmg, crit = self.calc(u.atk, sk.mult, tgt.df, sk.dmg_type)
        self.hit(tgt, dmg, crit, KURAMA_COLOR)
        self.popups[-1]["size"] = 36
        self.shake = max(self.shake, 0.45)
        self.add_sparks(tgt.x, tgt.y, KURAMA_COLOR, 28)
        self.fx.append({"t": "ring", "x": tgt.x, "y": tgt.y, "life": 0.5, "dur": 0.5, "c": KURAMA_COLOR,
                        "r": 140, "w": 8})
        if KURAMA_RASENGAN_SPLASH > 0:
            for other in self.alive(self.enemies):
                if other is tgt:
                    continue
                self.hit(other, max(1, int(dmg * KURAMA_RASENGAN_SPLASH)), False, KURAMA_COLOR)
                self.add_sparks(other.x, other.y, KURAMA_COLOR, 10)

    def try_shadow_clone(self, owner):
        p = owner.passive
        if (not p or p.key != "shadow_clone" or not owner.alive or self.state != "fighting"
                or random.random() >= p.chance):
            return
        old = next((c for c in self.clones if c.owner is owner and c.alive), None)
        if old:
            old.life = CLONE_DURATION
            self.popups.append({"text": "Clone refreshed", "x": old.x, "y": old.y - 40, "life": 0.8,
                                "color": (150, 200, 255), "size": 16})
            return
        c = Unit(CLONE_NAME, max(1, int(owner.max_hp * CLONE_RATIO["hp"])),
                 max(1, int(owner.atk * CLONE_RATIO["atk"])), int(owner.df * CLONE_RATIO["df"]),
                 owner.dmg_type, owner.color, True, owner.x + CLONE_OFFSET_X, owner.y)
        c.tpl, c.evo_stage, c.owner, c.life = owner.tpl, 0, owner, CLONE_DURATION
        self.clones.append(c)
        self.add_sparks(c.x, c.y, CLONE_SMOKE, 14)
        self.fx.append({"t": "ring", "x": c.x, "y": c.y, "life": 0.4, "dur": 0.4, "c": CLONE_SMOKE, "r": 70, "w": 5})
        self.popups.append({"text": "Shadow Clone!", "x": c.x, "y": c.y - 60, "life": 0.9,
                            "color": (150, 200, 255), "size": 20})
        self.add_log(f"{owner.name} summons a Shadow Clone!", (150, 200, 255))

    def dismiss_clone(self, c):
        if c in self.clones:
            self.clones.remove(c)
        c.alive = False
        self.add_sparks(c.x, c.y, CLONE_SMOKE, 16)
        self.fx.append({"t": "ring", "x": c.x, "y": c.y, "life": 0.45, "dur": 0.45, "c": CLONE_SMOKE, "r": 60, "w": 6})
        self.add_log("Shadow Clone vanished.", DIM)

    def dismiss_all_clones(self):
        for c in list(self.clones):
            self.dismiss_clone(c)

    def update_clones(self, dt):
        for c in list(self.clones):
            if not c.alive:
                self.clones.remove(c)
                continue
            c.life -= dt
            if c.life <= 0 or self.state != "fighting":
                self.dismiss_clone(c)
                continue
            if self.wave_delay > 0 or c.stun_timer > 0:
                continue
            c.timer += dt
            alive_e = self.alive(self.enemies)
            if alive_e and c.timer >= c.interval:
                self.basic_attack(c, alive_e[0])

    def _win(self, admin=False):
        self.state = "victory"
        self.dismiss_all_clones()
        s = self.stage
        self.rewards = {"gold": 150 + 60 * s, "gems": 40 + 10 * s, "exp": 60 + 25 * s,
                        "drops": roll_drops(self.map, s)}
        self.add_log("VICTORY!" + (" (Admin)" if admin else ""), GOOD)

    def force_victory(self):
        if self.state != "fighting":
            return False
        for e in self.enemies:
            e.hp, e.alive = 0, False
        self.wave, self.wave_delay = self.max_waves, 0.0
        self._win(admin=True)
        return True

    def can_cast(self, u):
        if not (self.state == "fighting" and u.alive and u.skill is not None and u.cd <= 0
                and self.wave_delay <= 0 and getattr(u, "stun_timer", 0.0) <= 0):
            return False
        if u.skill.charge_hits and u.skill_charge < u.skill.charge_hits:
            return False                # charge skill: needs its landed basic hits first
        if u.skill.heal:
            return True                 # a heal needs no enemy target
        return bool(self.alive(self.enemies))

    def auto_wants(self, u):
        sk = u.skill
        if sk is None or not sk.heal:
            return True
        return any(p.hp <= p.max_hp * HEAL_AUTO_THRESHOLD for p in self.alive(self.players))

    def _cast_heal(self, u, sk):
        allies = self.alive(self.players)
        total = 0
        ring_c = (255, 175, 215) if u.evo_stage > 0 else HEAL_COLOR
        self.fx.append({"t": "ring", "x": u.x, "y": u.y, "life": 0.6, "dur": 0.6, "c": ring_c,
                        "r": 290 if u.evo_stage > 0 else 260, "w": 8})
        if u.evo_stage > 0:
            self.fx.append({"t": "ring", "x": u.x, "y": u.y, "life": 0.45, "dur": 0.45, "c": HEAL_COLOR,
                            "r": 180, "w": 5})
        for tg in allies:
            amount = max(1, int(tg.max_hp * sk.mult))
            healed = max(0, min(amount, tg.max_hp - tg.hp))
            tg.hp = min(tg.max_hp, tg.hp + healed)
            total += healed
            self.fx.append({"t": "heal_pulse", "x": tg.x, "y": tg.y, "life": 0.9, "dur": 0.9})
            self.add_sparks(tg.x, tg.y, ring_c, 14 if u.evo_stage > 0 else 10)
            self.popups.append({"text": f"+{healed}" if healed else "FULL", "x": tg.x, "y": tg.y - 60,
                                "life": 1.1, "color": HEAL_COLOR, "size": 24 if healed else 16})
        self.add_log(f"{u.name} casts {sk.name}! Team healed +{total}", HEAL_COLOR)
        return True

    def trigger_chakra_catalyst(self, u):
        col = (255, 175, 215)  # soft pink/green healing color
        self.popups.append({
            "text": "CHAKRA CATALYST! (-10% CD)",
            "x": u.x,
            "y": u.y - 65,
            "life": 1.5,
            "color": col,
            "size": 20
        })
        self.add_log(f"{u.name} activates Chakra Catalyst! (-10% Ally CD)", col)
        self.fx.append({"t": "ring", "x": u.x, "y": u.y, "life": 0.5, "dur": 0.5, "c": col, "r": 180, "w": 6})
        self.add_sparks(u.x, u.y, col, 14)

        for ally in self.alive(self.players):
            if ally.skill and ally.cd > 0:
                reduction = max(0.5, ally.skill.cooldown * 0.10)
                ally.cd = max(0.0, ally.cd - reduction)
                self.add_sparks(ally.x, ally.y, (160, 245, 200), 8)
                if ally is not u:
                    self.popups.append({
                        "text": "-10% CD",
                        "x": ally.x,
                        "y": ally.y - 45,
                        "life": 1.0,
                        "color": (160, 245, 200),
                        "size": 16
                    })

    def trigger_yugito_skill(self, att, tgt):
        dmg, crit = self.calc(att.atk, 2.5, tgt.df, att.dmg_type)
        self.shake = max(self.shake, 0.35)
        self.popups.append({
            "text": "BLUE FIRE SLASH!",
            "x": att.x,
            "y": att.y - 85,
            "life": 1.4,
            "color": (80, 190, 255),
            "size": 22
        })
        self.add_log(f"{att.name} unleashes Blue Slash!", (80, 190, 255))
        self.fx.append({
            "t": "nii_slash_animation",
            "x": att.x - 35,
            "y": att.y,
            "life": 0.45,
            "dur": 0.45
        })
        self.fx.append({
            "t": "blue_slash",
            "x": att.x - 40,
            "y": att.y,
            "tx": tgt.x,
            "ty": tgt.y,
            "life": 0.35,
            "dur": 0.35,
            "tgt": tgt,
            "dmg": dmg,
            "crit": crit
        })
        self.add_sparks(att.x, att.y, (80, 190, 255), 18)

    # --- Roushi: Super Magma Shot + 5-tick burn ---------------------------------------
    def trigger_roushi_skill(self, att, tgt):
        """Cast animation (roushi_skill.png), then the super projectile flies out and burns the target."""
        dmg, crit = self.calc(att.atk, ROUSHI_SKILL_MULT, tgt.df, att.dmg_type)
        att.lunge = 0.4
        self.popups.append({"text": "SUPER MAGMA SHOT!", "x": att.x, "y": att.y - 90, "life": 1.5,
                            "color": MAGMA_COLOR, "size": 22})
        self.add_log(f"{att.name} unleashes Super Magma Shot!", MAGMA_COLOR)
        self.fx.append({"t": "roushi_cast", "x": att.x - 20, "y": att.y, "life": ROUSHI_CAST_TIME,
                        "dur": ROUSHI_CAST_TIME})
        self.fx.append({"t": "super_magma_shot", "x": att.x - 60, "y": att.y - 10, "tx": tgt.x, "ty": tgt.y,
                        "delay": ROUSHI_CAST_TIME, "life": ROUSHI_SUPER_TRAVEL, "dur": ROUSHI_SUPER_TRAVEL,
                        "tgt": tgt, "dmg": dmg, "crit": crit, "att": att})
        self.add_sparks(att.x, att.y, MAGMA_COLOR, 18)

    def _apply_burn(self, att, tgt):
        """5 ticks of burn: each tick = max(1.5% of target Max HP, 15% of boss ATK). Re-burn refreshes."""
        dmg = max(1, int(tgt.max_hp * ROUSHI_BURN_MAX_HP_PCT), int(att.atk * ROUSHI_BURN_ATK_PCT))
        if tgt.burn:
            dmg = max(dmg, tgt.burn["dmg"])
        tgt.burn = {"dmg": dmg, "ticks": ROUSHI_BURN_TICKS, "next": ROUSHI_BURN_INTERVAL}
        self.popups.append({"text": f"BURNING! x{ROUSHI_BURN_TICKS}", "x": tgt.x, "y": tgt.y - 85,
                            "life": 1.2, "color": BURN_COLOR, "size": 20})
        self.add_sparks(tgt.x, tgt.y, BURN_COLOR, 14)
        self.add_log(f"{tgt.name} is burning! ({dmg} dmg x {ROUSHI_BURN_TICKS} ticks)", BURN_COLOR)

    def _tick_burn(self, u, dt):
        bn = u.burn
        if not bn:
            return
        if not u.alive:
            u.burn = None
            return
        bn["next"] -= dt
        while bn["next"] <= 0 and bn["ticks"] > 0 and u.alive:
            bn["ticks"] -= 1
            bn["next"] += ROUSHI_BURN_INTERVAL
            self.hit(u, bn["dmg"], False, BURN_COLOR)
            self.popups.append({"text": "BURN", "x": u.x, "y": u.y - 84, "life": 0.7,
                                "color": BURN_COLOR, "size": 13})
            self.add_sparks(u.x, u.y - 15, BURN_COLOR, 7)
        if bn["ticks"] <= 0 or not u.alive:
            u.burn = None

    # --- Han: Steam Armor (+15% DEF every 10s) and Steam Cannon (1.5x ATK, every 10s) ----------
    def trigger_han_defense(self, han):
        """Steam Armor: DEF +15% (compounding). Capped at HAN_DEF_MAX_STACKS boosts when a cap is set."""
        if HAN_DEF_MAX_STACKS is not None and han.def_stacks >= HAN_DEF_MAX_STACKS:
            return
        old = han.df
        han.df = max(old + 1, int(round(old * (1.0 + HAN_DEF_GROWTH))))
        han.def_stacks += 1
        self.popups.append({"text": "DEF +15%!", "x": han.x, "y": han.y - 95, "life": 1.4,
                            "color": HAN_DEF_COLOR, "size": 22})
        self.add_log(f"{han.name}'s Steam Armor hardens! DEF {old} -> {han.df} (x{han.def_stacks})",
                     HAN_DEF_COLOR)
        self.fx.append({"t": "ring", "x": han.x, "y": han.y, "life": 0.5, "dur": 0.5,
                        "c": HAN_DEF_COLOR, "r": 120, "w": 7})
        self.add_sparks(han.x, han.y, HAN_DEF_COLOR, 14)

    def trigger_han_skill(self, att, tgt):
        """Cast animation (han_skill_animation.png), then the steam blast (bullet_han.png) flies out.
        Damage = HAN_SKILL_MULT x Han's current ATK (poison-reduced ATK included), applied on impact."""
        dmg, crit = self.calc(att.atk, HAN_SKILL_MULT, tgt.df, att.dmg_type)
        att.lunge = 0.4
        self.popups.append({"text": "STEAM CANNON!", "x": att.x, "y": att.y - 90, "life": 1.5,
                            "color": HAN_STEAM_COLOR, "size": 22})
        self.add_log(f"{att.name} fires the Steam Cannon!", HAN_STEAM_COLOR)
        self.fx.append({"t": "han_cast", "x": att.x - 20, "y": att.y, "life": HAN_CAST_TIME,
                        "dur": HAN_CAST_TIME})
        self.fx.append({"t": "han_steam_shot", "x": att.x - 60, "y": att.y - 10, "tx": tgt.x, "ty": tgt.y,
                        "delay": HAN_CAST_TIME, "life": HAN_SHOT_TRAVEL, "dur": HAN_SHOT_TRAVEL,
                        "tgt": tgt, "dmg": dmg, "crit": crit, "att": att})
        self.add_sparks(att.x, att.y, HAN_STEAM_COLOR, 18)

    def _update_passives(self, dt):
        for u in self.alive(self.players):
            if getattr(u, "stun_timer", 0.0) > 0:
                continue
            p = u.passive
            if p and p.key == "chakra_catalyst":
                u.passive_timer += dt
                if u.passive_timer >= 15.0:
                    u.passive_timer -= 15.0
                    self.trigger_chakra_catalyst(u)
            elif p and p.key == "kurama_cloak":     # first ward 15s after combat starts, then every 15s
                u.passive_timer += dt
                if u.passive_timer >= KURAMA_WARD_INTERVAL:
                    u.passive_timer -= KURAMA_WARD_INTERVAL
                    self.trigger_kurama_ward(u)

    def dash_pos(self, u):
        if u.punch_t <= 0 or not u.alive or u.punch_tgt is None:
            return None
        prog = 1.0 - u.punch_t / PUNCH_DUR
        if prog < 0.30:
            k = prog / 0.30
        elif prog < 0.60:
            k = 1.0
        else:
            k = 1.0 - (prog - 0.60) / 0.40
        k = max(0.0, min(1.0, k))
        k = k * k * (3 - 2 * k)
        stand_off = -PUNCH_STAND_OFF if u.is_player else PUNCH_STAND_OFF
        tx, ty = u.punch_tgt.x + stand_off, u.punch_tgt.y
        return u.x + (tx - u.x) * k, u.y + (ty - u.y) * k, prog

    def _update_punches(self, dt):
        for u in self.players + self.enemies:
            if u.punch_t <= 0:
                continue
            if not u.alive:
                u.punch_t, u.punch_hit = 0.0, True
                continue
            u.punch_t = max(0.0, u.punch_t - dt)
            prog = 1.0 - u.punch_t / PUNCH_DUR
            if not u.punch_hit and prog >= PUNCH_HIT_AT:
                u.punch_hit = True
                tgt = u.punch_tgt
                if tgt is not None and tgt.alive:
                    if u.is_player:
                        pc = KURAMA_COLOR if u.kurama else (255, 170, 205)    # Naruto orange / Sakura pink
                        self.hit(tgt, u.punch_dmg, u.punch_crit, (255, 255, 255))
                        self.add_sparks(tgt.x, tgt.y, pc, 14)
                        self.fx.append({"t": "ring", "x": tgt.x - 20, "y": tgt.y, "life": 0.25, "dur": 0.25,
                                        "c": pc, "r": 55, "w": 5})
                        self._register_basic_hit(u)
                    else:
                        self.hit(tgt, u.punch_dmg, u.punch_crit, (255, 120, 120))
                        self.add_sparks(tgt.x, tgt.y, (100, 210, 175), 14)
                        self.fx.append({"t": "ring", "x": tgt.x + 20, "y": tgt.y, "life": 0.25, "dur": 0.25,
                                        "c": (100, 210, 175), "r": 55, "w": 5})
                        if getattr(u, "yagura_user", False):
                            self._apply_yagura_hit(u, tgt)
                        self._miniboss_on_hit(u, tgt)
                    self.shake = max(self.shake, 0.12)

    def cast(self, u):
        if not self.can_cast(u):
            return False
        sk = u.skill
        u.cd, u.timer = sk.cooldown, 0.0
        if sk.charge_hits:
            u.skill_charge = 0          # the charge is spent
        u.lunge = 0.0 if sk.heal else 0.4
        if sk.heal:
            self.try_shadow_clone(u)
            return self._cast_heal(u, sk)
        targets = self.alive(self.enemies) if sk.aoe else self.alive(self.enemies)[:1]
        self.add_log(f"{u.name} casts {sk.name}!", sk.color)
        self.shake = 0.4
        self.try_shadow_clone(u)

        if sk.name == KURAMA_SKILL_NAME:
            self.trigger_kurama_rasengan(u, sk, targets[0])
            return True

        if sk.name == "Rasen Shuriken":
            avg_x = sum(tg.x for tg in targets) / len(targets)
            avg_y = sum(tg.y for tg in targets) / len(targets)
            self.fx.append({"t": "rasen_shuriken", "x": u.x, "y": u.y, "tx": avg_x, "ty": avg_y,
                            "life": 0.4, "dur": 0.4, "targets": targets, "u": u, "sk": sk})
            return True

        if sk.name == "Fire Ball":
            avg_x = sum(tg.x for tg in targets) / len(targets)
            avg_y = sum(tg.y for tg in targets) / len(targets)
            self.fx.append({"t": "fire_ball", "x": u.x, "y": u.y, "tx": avg_x, "ty": avg_y,
                            "life": 0.35, "dur": 0.35, "targets": targets, "u": u, "sk": sk})
            return True

        if sk.name == "Chidori":
            avg_x = sum(tg.x for tg in targets) / len(targets)
            avg_y = sum(tg.y for tg in targets) / len(targets)
            self.fx.append({"t": "chidori", "x": u.x, "y": u.y, "tx": avg_x, "ty": avg_y,
                            "life": 0.30, "dur": 0.30, "targets": targets, "u": u, "sk": sk})
            return True

        if sk.aoe:
            self.fx.append({"t": "ring", "x": u.x, "y": u.y, "life": 0.7, "dur": 0.7, "c": sk.color, "r": 700, "w": 10})
        for tg in targets:
            self.fx.append({"t": "beam", "a": (u.x, u.y), "b": (tg.x, tg.y), "life": 0.35, "dur": 0.35, "c": sk.color, "w": 24})
            self.fx.append({"t": "ring", "x": tg.x, "y": tg.y, "life": 0.5, "dur": 0.5, "c": sk.color, "r": 130, "w": 6})
            self.add_sparks(tg.x, tg.y, sk.color, 26)
            dmg, crit = self.calc(u.atk, sk.mult, tg.df, sk.dmg_type)
            self.hit(tg, dmg, crit, sk.color)
            self.popups[-1]["size"] = 30
        return True

    def update(self, dt):
        dt *= self.speed
        self.time += dt
        self.shake = max(0, self.shake - dt)
        for p in self.popups:
            p["life"] -= dt
            p["y"] -= 45 * dt
        self.popups = [p for p in self.popups if p["life"] > 0]

        for e in list(self.fx):
            if "delay" in e and e["delay"] > 0:
                e["delay"] -= dt
                continue

            e["life"] -= dt
            if e["t"] == "spark":
                e["x"] += e["vx"] * dt
                e["y"] += e["vy"] * dt
            elif e["t"] == "kunai":
                if e["life"] <= 0 and e["tgt"].alive:
                    self.hit(e["tgt"], e["dmg"], e["crit"], (255, 255, 255))
            elif e["t"] == "rasen_shuriken":
                if e["life"] <= 0:
                    for tg in self.alive(e["targets"]):
                        dmg, crit = self.calc(e["u"].atk, e["sk"].mult, tg.df, e["sk"].dmg_type)
                        self.hit(tg, dmg, crit, e["sk"].color)
                        self.popups[-1]["size"] = 32
                        self.add_sparks(tg.x, tg.y, (100, 220, 255), 20)
            elif e["t"] == "fire_ball":
                if e["life"] <= 0:
                    for tg in self.alive(e["targets"]):
                        dmg, crit = self.calc(e["u"].atk, e["sk"].mult, tg.df, e["sk"].dmg_type)
                        self.hit(tg, dmg, crit, e["sk"].color)
                        self.popups[-1]["size"] = 32
                        self.add_sparks(tg.x, tg.y, (255, 120, 30), 22)
            elif e["t"] == "chidori":
                if e["life"] <= 0:
                    for tg in self.alive(e["targets"]):
                        dmg, crit = self.calc(e["u"].atk, e["sk"].mult, tg.df, e["sk"].dmg_type)
                        self.hit(tg, dmg, crit, e["sk"].color)
                        self.popups[-1]["size"] = 36
                        self.add_sparks(tg.x, tg.y, (100, 200, 255), 25)
            elif e["t"] == "amaterasu_burn":
                if e["life"] <= 0 and e["tgt"].alive:
                    self.hit(e["tgt"], e["dmg"], False, (220, 80, 255))
                    self.add_sparks(e["tgt"].x, e["tgt"].y, (180, 40, 220), 8)
            elif e["t"] == "sand_hand":
                if e["life"] <= 0 and e["tgt"].alive:
                    self.hit(e["tgt"], e["dmg"], e["crit"], SAND_COLOR)
                    self.popups[-1]["size"] = 30
                    self.add_sparks(e["tgt"].x, e["tgt"].y, SAND_COLOR, 20)
            elif e["t"] == "blue_slash":
                if e["life"] <= 0 and e["tgt"].alive:
                    self.hit(e["tgt"], e["dmg"], e["crit"], (80, 190, 255))
                    self.popups[-1]["size"] = 32
                    self.add_sparks(e["tgt"].x, e["tgt"].y, (80, 190, 255), 22)
                    self.fx.append({"t": "ring", "x": e["tgt"].x, "y": e["tgt"].y, "life": 0.4, "dur": 0.4, "c": (80, 190, 255), "r": 90, "w": 6})
            elif e["t"] == "nii_basic_attack":
                if e["life"] <= 0 and e["tgt"].alive:
                    self.hit(e["tgt"], e["dmg"], e["crit"], (80, 160, 255))
                    self.add_sparks(e["tgt"].x, e["tgt"].y, (80, 160, 255), 12)
            elif e["t"] == "naruto_rasengan":
                if e["life"] <= 0:
                    self._land_kurama_rasengan(e)
            elif e["t"] == "magma_shot":
                if e["life"] <= 0 and e["tgt"].alive:
                    self.hit(e["tgt"], e["dmg"], e["crit"], MAGMA_COLOR)
                    self.add_sparks(e["tgt"].x, e["tgt"].y, MAGMA_COLOR, 12)
                    self.fx.append({"t": "ring", "x": e["tgt"].x, "y": e["tgt"].y, "life": 0.3, "dur": 0.3,
                                    "c": MAGMA_COLOR, "r": 60, "w": 5})
            elif e["t"] == "han_steam_shot":
                if e["life"] <= 0 and e["tgt"].alive:
                    self.hit(e["tgt"], e["dmg"], e["crit"], HAN_STEAM_COLOR)
                    self.popups[-1]["size"] = 32
                    self.shake = max(self.shake, 0.3)
                    self.add_sparks(e["tgt"].x, e["tgt"].y, HAN_STEAM_COLOR, 26)
                    self.fx.append({"t": "ring", "x": e["tgt"].x, "y": e["tgt"].y, "life": 0.45, "dur": 0.45,
                                    "c": HAN_STEAM_COLOR, "r": 110, "w": 7})
            elif e["t"] == "super_magma_shot":
                if e["life"] <= 0 and e["tgt"].alive:
                    self.hit(e["tgt"], e["dmg"], e["crit"], MAGMA_COLOR)
                    self.popups[-1]["size"] = 32
                    self.shake = max(self.shake, 0.3)
                    self.add_sparks(e["tgt"].x, e["tgt"].y, MAGMA_COLOR, 26)
                    self.fx.append({"t": "ring", "x": e["tgt"].x, "y": e["tgt"].y, "life": 0.45, "dur": 0.45,
                                    "c": MAGMA_COLOR, "r": 110, "w": 7})
                    if e["tgt"].alive:
                        self._apply_burn(e["att"], e["tgt"])

        self.fx = [e for e in self.fx if e["life"] > 0 or ("delay" in e and e["delay"] > 0)]
        for u in self.players + self.enemies + self.clones:
            u.flash = max(0, u.flash - dt)
            u.lunge = max(0, u.lunge - dt)
            u.shield_timer = max(0.0, u.shield_timer - dt)
            if u.ward_timer > 0:
                u.ward_timer = max(0.0, u.ward_timer - dt)
                if u.ward_timer <= 0:
                    u.ward_pct = 0.0
        self._update_punches(dt)
        self.update_clones(dt)
        if self.state != "fighting":
            return
        if self.wave_delay > 0:
            self.wave_delay -= dt
            if self.wave_delay <= 0:
                self.spawn_wave()
            return
        self._update_passives(dt)
        self._update_statuses(dt)
        for u in self.alive(self.players):
            if getattr(u, "stun_timer", 0.0) > 0:
                continue
            u.cd = max(0, u.cd - dt)
            u.timer += dt
            alive_e = self.alive(self.enemies)
            if not alive_e:
                break
            if self._wants_auto_cast(u) and self.can_cast(u) and self.auto_wants(u):
                self.cast(u)
            elif u.timer >= u.interval:
                self.basic_attack(u, alive_e[0])
        for e in self.alive(self.enemies):
            if getattr(e, "stun_timer", 0.0) > 0:
                continue
            if getattr(e, "yugito_user", False):
                e.skill_timer = max(0.0, e.skill_timer - dt)
                if e.skill_timer <= 0:
                    e.skill_timer = 15.0
                    alive_p = self.alive(self.players)
                    if alive_p:
                        self.trigger_yugito_skill(e, random.choice(alive_p))
            if getattr(e, "roushi_user", False):
                e.skill_timer = max(0.0, e.skill_timer - dt)
                if e.skill_timer <= 0:
                    e.skill_timer = ROUSHI_SKILL_INTERVAL
                    alive_p = self.alive(self.players)
                    if alive_p:
                        self.trigger_roushi_skill(e, random.choice(alive_p))
            if getattr(e, "han_user", False):
                e.passive_timer += dt                     # Steam Armor: +15% DEF every 10s
                if e.passive_timer >= HAN_PASSIVE_INTERVAL:
                    e.passive_timer -= HAN_PASSIVE_INTERVAL
                    self.trigger_han_defense(e)
                e.skill_timer = max(0.0, e.skill_timer - dt)      # Steam Cannon every 10s
                if e.skill_timer <= 0:
                    e.skill_timer = HAN_SKILL_INTERVAL
                    alive_p = self.alive(self.players)
                    if alive_p:
                        self.trigger_han_skill(e, random.choice(alive_p))
            e.timer += dt
            alive_p = self.alive(self.players)
            if alive_p and e.timer >= e.interval:
                self.basic_attack(e, random.choice(alive_p + self.alive(self.clones)))
        if not self.alive(self.players):
            self.state = "defeat"
            self.dismiss_all_clones()
            self.add_log("Your team has fallen...", BAD)
        elif not self.alive(self.enemies):
            if self.wave >= self.max_waves:
                self._win()
            else:
                self.wave_delay = 1.2
                self._clear_statuses()
                self.add_log("Wave cleared!", GOOD)