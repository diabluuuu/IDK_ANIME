"""config.py - constants, colours, balance/rates/pricing and evolution configuration."""

W, H = 1100, 700
FPS = 60

# --- High-End Dark-Orange / Amber Ninja Palette (Obsidian & Chakra Theme) ------------
BG = (14, 15, 22)                   # Deep obsidian night background (#0e0f16)
BG_TOP = (22, 20, 30)               # Warm dusk-obsidian top gradient tint
BG_BOT = (10, 11, 17)               # Deep abyssal bottom gradient tint

PANEL = (22, 24, 34)                # Primary charcoal/obsidian panel surface (#161822)
PANEL_ALT = (30, 33, 46)            # Elevated card / inner container surface (#1e212e)
PANEL_DARK = (14, 16, 24)           # Recessed well / input / slot background (#0e1018)
PANEL_HEADER = (36, 30, 38)         # Warm dark-amber tinted header band

PANEL_BORDER = (230, 115, 0)        # Sleek dark-amber border (#e67300)
PANEL_BORDER_GLOW = (255, 153, 51)  # Bright chakra-amber highlight (#ff9933)
PANEL_BORDER_SUBTLE = (76, 62, 50)  # Muted bronze-charcoal border for inner boxes
PANEL_BORDER_DIM = (52, 54, 68)     # Subtle slate border for inactive slots

CHAKRA_ORANGE = (255, 138, 31)      # Signature ninja chakra orange (#ff8a1f)
CHAKRA_HOT = (255, 179, 71)         # Hot amber glow (#ffb347)
CHAKRA_GOLD = (255, 210, 122)       # Soft gold highlight (#ffd27a)
CHAKRA_DEEP = (205, 76, 12)         # Deep ember orange (#cd4c0c)
NEON_BLUE = (53, 208, 255)          # Clean chakra-cyan / neon-blue highlight (#35d0ff)
NEON_BLUE_DEEP = (24, 118, 175)     # Deep chakra blue for button gradients

TEXT = (242, 244, 250)              # Crisp high-contrast warm white
DIM = (162, 168, 188)               # Readable muted silver-slate
GOOD = (95, 235, 145)               # Vibrant jade emerald
BAD = (255, 92, 92)                 # Crisp crimson alert
GOLD_C = (255, 208, 70)             # Rich imperial gold
GEM_C = (53, 208, 255)              # Neon chakra cyan (#35d0ff)
EXP_C = (120, 245, 165)             # Luminous sage green

RARITIES = ["Common", "Rare", "Epic", "Legendary"]
# "Chase" and "Secret" are ITEM-ONLY rarity tiers (badge colours in the Bag / result screen).
# They are deliberately NOT in RARITIES, so gacha rates, character stars and stats are unaffected.
RARITY_COLOR = {
    "Common": (175, 180, 195),
    "Rare": (65, 175, 255),
    "Epic": (205, 105, 255),
    "Legendary": (255, 185, 40),
    "Chase": (55, 235, 215),
    "Secret": (255, 65, 145),
}
RARITY_BG = {
    "Common": (32, 35, 46),
    "Rare": (22, 38, 62),
    "Epic": (42, 26, 62),
    "Legendary": (56, 40, 20),
    "Chase": (18, 48, 48),
    "Secret": (56, 20, 42),
}
RARITY_RATE = {"Common": 50, "Rare": 35, "Epic": 12, "Legendary": 3}
RARITY_STATS = {"Common": (100, 12, 5), "Rare": (130, 16, 7),
                "Epic": (170, 21, 10), "Legendary": (220, 28, 14)}
EVO_STONES = {"Common": 1, "Rare": 2, "Epic": 3, "Legendary": 5}
EVO_GOLD = {"Common": 300, "Rare": 600, "Epic": 1000, "Legendary": 2000}
EVO_MIN_LEVEL = 5
LEVEL_CAP, EVOLVED_LEVEL_CAP = 30, 50
EVO_MULT = {"hp": 2.0, "atk": 1.8, "df": 1.8}
EVO2_MULT_DEFAULT = 2.5        # Evolution Tier 2 stat multiplier unless a template overrides it
SINGLE_COST, MULTI_COST = 100, 900
TEAM_SIZE = 3
MAX_WAVES = 3

# --- Stage progression: infinite stages, Solo Boss every Nth stage -------------------
BOSS_STAGE_INTERVAL = 10     # stage 10, 20, 30 ... are Solo Boss stages (1 wave, 1 boss)
BOSS_HP_PER_STAGE = 2.0      # Solo Boss HP  = 80 * stage_factor * (BOSS_HP_PER_STAGE * stage)
BOSS_ATK_PER_STAGE = 0.03    # Solo Boss ATK = 11 * stage_factor * (1 + BOSS_ATK_PER_STAGE * stage)


def is_boss_stage(stage):
    return stage > 0 and stage % BOSS_STAGE_INTERVAL == 0


# --- Tailed Beast (Vi Thu) & special drop rates --------------------------------------
TAILED_BEAST_DROP_RATE = 0.01   # Shukaku, Matatabi, Isobu, Son Goku & Kokuo: 1% on their designated World Boss kill
NARUTO_CLOAK_DROP_RATE = 0.001  # Naruto Cloak: 0.1% from EVERY Leaf Village World Boss kill
DANZO_SHARINGAN_BASE_RATE = 0.025      # 2.5% base Legendary drop rate when defeating Danzo
DANZO_SHARINGAN_ONEHIT_RATE = 0.050    # 5.0% drop rate when defeating Danzo via One-Hit KO above 20% HP

# --- Naruto Tier 2 evolution: Nine-Tails Chakra Naruto (Sage Naruto -> Legendary) ----------
NARUTO_EVO2_NAME = "Nine-Tails Chakra Naruto"
NARUTO_EVO2_COST = {
    "duplicates": 2,         # 2 x Epic Naruto = Sage Naruto (evo tier 1) copies, consumed
    "gold": 10000,
    "naruto_cloak": 1,       # ITEMS key (Secret drop)
    "chakra": 50,            # ITEMS key
    "black_chakra": 5,       # ITEMS key
}
NARUTO_EVO2_DUPLICATE_STAGE = 1                    # duplicates must be at this evo stage (Sage Naruto)
NARUTO_EVO2_MULT = {"hp": 3.0, "atk": 3.2, "df": 2.8}   # stat multipliers (tier 1 uses EVO_MULT)
NARUTO_EVO2_LEVEL_CAP = 70                         # level cap of Nine-Tails Chakra Naruto (tier 1 = 50)

# Nine-Tails Chakra Naruto combat tuning
KURAMA_COLOR = (255, 130, 30)       # vibrant chakra-orange (popups, sparks, rings)
KURAMA_SKILL_NAME = "Kurama Rasengan"
KURAMA_SKILL_HITS = 5               # basic attacks that must land to charge the skill
KURAMA_AUTO_FIRE = True             # True: the skill fires by itself once charged (even in manual mode);
                                    # False: it only becomes READY and AUTO / a click casts it
KURAMA_RASENGAN_MULT = 5.0          # x ATK on the main target (skill_naruto_rasengan.png projectile)
KURAMA_RASENGAN_SPLASH = 0.40       # other enemies take this fraction of the main hit (0 = pure single target)
KURAMA_CAST_TIME = 0.55             # naruto_kurama_model_animation.png plays this long before the ball is fired
KURAMA_RASENGAN_TRAVEL = 0.40       # flight time of the Rasengan ball
KURAMA_WARD_INTERVAL = 15.0         # passive: first ward 15s after combat starts, then every 15s
KURAMA_WARD_DURATION = 10.0         # seconds the ward lasts
KURAMA_WARD_REDUCTION = 0.15        # incoming damage -15%
KURAMA_AURA_ALPHA = 105             # 0-255 opacity of aura_kurama.png (soft / faded look)
# naruto_attack.png usage while dashing:  "body" = the sheet IS Naruto while he dashes/punches,
# "impact" = Naruto keeps his normal sprite and the sheet is drawn as the punch effect on the target.
NARUTO_ATTACK_SHEET_MODE = "body"

# Roushi (Stage 40 World Boss) magma / burn colours
MAGMA_COLOR = (255, 110, 40)
BURN_COLOR = (255, 150, 50)

# Han (Stage 50 World Boss) steam / armour colours
HAN_DEF_COLOR = (140, 170, 205)      # "DEF +15%!" popup + armour pulse (steel blue-gray)
HAN_STEAM_COLOR = (200, 215, 230)    # steam cannon sparks / rings / fallback projectile
STEAM_COLOR = HAN_STEAM_COLOR

# New Mini-Boss FX colours
DANZO_WIND_COLOR = (170, 235, 215)
KAKUZU_FIRE_COLOR = (255, 105, 35)
KIMIMARO_BONE_COLOR = (230, 225, 205)
KISAME_WATER_COLOR = (65, 205, 245)

ITEMS = {
    "stones":         {"name": "Evolution Stone", "short": "Stones",    "rarity": "Common",    "color": (255, 150, 220), "desc": "Crystallized energy used to awaken heroes. Farmed in the Stone Mine."},
    "chakra":         {"name": "Chakra",          "short": "Chakra",    "rarity": "Common",    "color": (53, 208, 255),  "desc": "Spiritual energy needed to awaken Naruto, Sasuke, and Sakura. Dropped in Leaf Village."},
    "shukaku":        {"name": "Shukaku",         "short": "Shukaku",   "rarity": "Chase",     "color": (225, 185, 105), "desc": "One-Tailed beast power sealed within Gaara. Dropped exclusively by Stage 10 World Boss."},
    "matatabi":       {"name": "Matatabi",        "short": "Matatabi",  "rarity": "Chase",     "color": (80, 180, 255),  "desc": "Two-Tailed beast spirit shrouded in blue flames. Dropped exclusively by Stage 20 World Boss Nii Yugito."},
    "isobu":          {"name": "Isobu",           "short": "Isobu",     "rarity": "Chase",     "color": (140, 160, 180), "desc": "Three-Tailed giant turtle beast spirit. Dropped exclusively by Stage 30 World Boss Yagura Karatachi."},
    "son_goku":       {"name": "Son Goku",        "short": "Son Goku",  "rarity": "Chase",     "color": (220, 70, 50),   "desc": "Four-Tailed beast spirit. Dropped exclusively by Stage 40 World Boss Roushi."},
    "kokuo":          {"name": "Kokuo",           "short": "Kokuo",     "rarity": "Chase",     "color": (200, 215, 230), "desc": "Five-Tailed horse beast spirit wreathed in boiling steam. Dropped exclusively by Stage 50 World Boss Han."},
    "sharingan_base": {"name": "Sharingan",       "short": "Sharingan", "rarity": "Legendary", "color": (235, 50, 65),   "desc": "Crimson ocular relic dropped by Danzo Shimura (2.5% base rate, boosted to 5.0% on a One-Hit KO above 20% HP)."},
    "naruto_cloak":   {"name": "Naruto Cloak",    "short": "N.Cloak",   "rarity": "Secret",    "color": (255, 70, 150),  "desc": "A flame-patterned cloak of a Leaf legend. Ultra-rare (0.1%) drop from any Leaf Village World Boss."},
    "black_chakra":   {"name": "Black Chakra",    "short": "B.Chakra",  "rarity": "Rare",      "color": (165, 110, 245), "desc": "Forbidden dark chakra required for Sasuke's second awakening."},
}

DEFAULT_THEME = {"bg": (18, 20, 30), "floor": (26, 29, 44), "line": (42, 46, 68), "accent": (255, 153, 51)}
MAPS = [
    {"id": "stone_mine", "name": "Stone Mine",
     "desc": "A dark crystal cavern echoing with ancient ore. Farm Evolution Stones to awaken your heroes.",
     "bg": (28, 22, 34), "floor": (42, 33, 52), "line": (62, 48, 76), "accent": (255, 165, 95),
     "drops": [
         {"item": "stones", "chance": 1.00, "min": 1, "max": 1, "boss_qty_mult": 3},
         {"item": "stones", "chance": 0.40, "min": 1, "max": 1, "note": "bonus",
          "boss_chance": 1.00, "boss_qty_mult": 3},
         {"item": "sharingan_base", "chance": 0.0, "min": 1, "max": 1,
          "miniboss_chance": DANZO_SHARINGAN_BASE_RATE, "note": "Danzo (2.5% / 5% 1-Hit)"},
     ]},
    {"id": "leaf_village", "name": "Leaf Village",
     "desc": "Hidden village of the leaf. Battle rogue ninjas to collect Chakra and legendary tailed beast spirits.",
     "bg": (18, 32, 26), "floor": (26, 48, 36), "line": (38, 70, 50), "accent": (110, 235, 145),
     "enemies": [("Rogue Ninja", (90, 180, 100), "Physical")],
     "bosses": [
         ("Gaara", (210, 140, 60), "Magic"),                # Stage 10 Solo World Boss
         ("Nii Yugito", (80, 160, 255), "Physical"),        # Stage 20 Solo World Boss
         ("Yagura Karatachi", (80, 180, 140), "Physical"),  # Stage 30 Solo World Boss
         ("Roushi", (225, 90, 40), "Magic"),                # Stage 40 Solo World Boss (magma, burn)
         ("Han", (150, 170, 195), "Physical"),              # Stage 50 Solo World Boss (steam armour, steam cannon)
     ],
     # NOTE: boss index = (stage // BOSS_STAGE_INTERVAL - 1) % len(bosses).  Keep this list in stage order:
     # index 0 = stage 10 ... index 4 = stage 50.  With only 4 entries stage 50 wrapped back to Gaara.
     "drops": [
         {"item": "chakra", "chance": 0.90, "min": 2, "max": 4, "qty_per_stage": 0.5,
          "boss_chance": 1.00, "boss_qty_mult": 3},
         {"item": "shukaku", "chance": 0.0, "min": 1, "max": 1,
          "boss_chance": TAILED_BEAST_DROP_RATE, "target_stage": 10, "note": "Gaara Boss"},
         {"item": "matatabi", "chance": 0.0, "min": 1, "max": 1,
          "boss_chance": TAILED_BEAST_DROP_RATE, "target_stage": 20, "note": "Yugito Boss"},
         {"item": "isobu", "chance": 0.0, "min": 1, "max": 1,
          "boss_chance": TAILED_BEAST_DROP_RATE, "target_stage": 30, "note": "Yagura Boss"},
         {"item": "son_goku", "chance": 0.0, "min": 1, "max": 1,
          "boss_chance": TAILED_BEAST_DROP_RATE, "target_stage": 40, "note": "Roushi Boss"},
         {"item": "kokuo", "chance": 0.0, "min": 1, "max": 1,
          "boss_chance": TAILED_BEAST_DROP_RATE, "target_stage": 50, "note": "Han Boss"},   # 1%
         # 0.1% on every World Boss stage (10, 20, 30, 40, ...) - no target_stage, never on regular stages
         {"item": "naruto_cloak", "chance": 0.0, "min": 1, "max": 1,
          "boss_chance": NARUTO_CLOAK_DROP_RATE, "note": "Any World Boss"},
         {"item": "sharingan_base", "chance": 0.0, "min": 1, "max": 1,
          "miniboss_chance": DANZO_SHARINGAN_BASE_RATE, "note": "Danzo (2.5% / 5% 1-Hit)"},
         {"item": "black_chakra", "chance": 0.02, "min": 1, "max": 1, "bonus": 0.002, "cap": 0.03,
          "boss_chance": 0.20, "boss_cap": 0.35},
     ]},
]
MAP_BY_ID = {m["id"]: m for m in MAPS}
DEFAULT_MAP_ID = MAPS[0]["id"]

# --- Admin / cheat menu ----------------------------------------------------------
ADMIN_PASSCODE = "101202"
ADMIN_GRANT = 10000          # amount added by every admin "claim" button


# --- Mini-bosses (spawn in regular waves only, never on Solo Boss stages) -----------
MINIBOSS_CHANCE_FINAL = 0.60   # chance that the last wave's boss slot is one of these mini-bosses
MINIBOSS_CHANCE_EARLY = 0.15   # chance that waves before the last include one (replaces a grunt)
MINIBOSS_CLONE_SUFFIX = " Clone"
MINIBOSS_CLONE_X = 905         # x position of White Zetsu's clones (boss stands at x=830)
BLEED_COLOR = (225, 45, 70)

MINIBOSSES = [
    {"id": "white_zetsu", "name": "White Zetsu", "sprite": "white_zetsu.png", "frames": 8, "flip": False,
     "color": (225, 235, 225), "dmg_type": "Physical", "hp_mult": 2.6, "atk_mult": 1.0, "df_mult": 1.5,
     "weight": 1, "tip": "Spawns 2 clones on entry.",
     "clones": {"count": 2, "hp_pct": 0.15, "dmg_pct": 0.40}},
    {"id": "zabuza_momochi", "name": "Zabuza Momochi", "sprite": "zabuza_momochi.png", "frames": 8,
     "flip": False, "color": (110, 130, 165), "dmg_type": "Physical", "hp_mult": 3.4, "atk_mult": 1.2,
     "df_mult": 1.5, "weight": 1, "tip": "Every 3rd hit on a target causes bleeding.",
     "bleed": {"hits": 3, "atk_pct": 0.02, "ticks": 5, "interval": 1.0, "max_stacks": 5}},
    {"id": "sasori_puppet", "name": "Sasori Puppet", "sprite": "sasori_puppet.png", "frames": 8,
     "flip": False, "color": (170, 95, 60), "dmg_type": "Magic", "hp_mult": 2.8, "atk_mult": 1.0,
     "df_mult": 1.5, "weight": 1, "tip": "Poison: each hit cuts target damage 1-2%.",
     "poison": {"label": "POISON", "min": 0.01, "max": 0.02, "cap": 0.40, "duration": 10.0,
                "color": (150, 235, 90)}},
    {"id": "summon_snake", "name": "Summon Snake", "sprite": "summon_snake.png", "frames": 8,
     "flip": False, "color": (110, 90, 170), "dmg_type": "Physical", "hp_mult": 3.0, "atk_mult": 1.0,
     "df_mult": 1.5, "weight": 1, "tip": "Venom: each strike drains 1-2% damage.",
     "poison": {"label": "VENOM", "min": 0.01, "max": 0.02, "cap": 0.40, "duration": 10.0,
                "color": (190, 120, 255)}},
    {"id": "danzo", "name": "Danzo Shimura", "sprite": "danzo.png", "frames": 8,
     "flip": False, "color": (175, 225, 200), "dmg_type": "Magic", "hp_mult": 2.8, "atk_mult": 1.15,
     "df_mult": 1.4, "weight": 1,
     "tip": "Izanagi: revives 3 times at 20% HP unless One-Hit KO'd above 20% HP!",
     "izanagi": {"revives": 3, "threshold": 0.20, "drop_item": "sharingan_base",
                 "base_rate": DANZO_SHARINGAN_BASE_RATE, "onehit_rate": DANZO_SHARINGAN_ONEHIT_RATE}},
    {"id": "kakuzu", "name": "Kakuzu", "sprite": "kakuzu.png", "frames": 8,
     "flip": False, "color": (245, 95, 45), "dmg_type": "Magic", "hp_mult": 3.2, "atk_mult": 1.15,
     "df_mult": 1.5, "weight": 1,
     "tip": "Summons a fire pillar (1s) at a random hero, burning 1% DMG for 3s!",
     "fire_pillar": {"pillar_dur": 1.0, "burn_ticks": 3, "burn_interval": 1.0, "burn_dmg_pct": 0.01}},
    {"id": "kimimaro", "name": "Kimimaro", "sprite": "kimimaro.png", "frames": 8,
     "flip": False, "color": (225, 220, 205), "dmg_type": "Physical", "hp_mult": 3.2, "atk_mult": 1.15,
     "df_mult": 1.7, "weight": 1,
     "tip": "Innate -15% DMG taken; every 10s Bone Spikes slow hero ATK SPD by 15%.",
     "dmg_reduction": 0.15,
     "bone_spikes": {"interval": 10.0, "dmg_pct": 0.005, "atk_spd_slow": 0.15}},
    {"id": "kisame", "name": "Kisame Hoshigaki", "sprite": "kisame.png", "frames": 8,
     "flip": False, "color": (70, 175, 235), "dmg_type": "Physical", "hp_mult": 3.5, "atk_mult": 1.25,
     "df_mult": 1.6, "weight": 1,
     "tip": "Dashes to slash (-5% ATK SPD); every 20s unleashes 150% Tsunami Wave!",
     "melee_slow": 0.05,
     "tsunami": {"interval": 20.0, "mult": 1.50}},
]
MINIBOSS_BY_ID = {m["id"]: m for m in MINIBOSSES}
MINIBOSS_BY_NAME = {m["name"]: m for m in MINIBOSSES}


def miniboss_for_name(name):
    """Mini-boss definition for a unit name (White Zetsu's clones map to White Zetsu), else None."""
    if name.endswith(MINIBOSS_CLONE_SUFFIX):
        name = name[:-len(MINIBOSS_CLONE_SUFFIX)]
    return MINIBOSS_BY_NAME.get(name)