"""config.py - constants, colours, balance/rates/pricing and evolution configuration."""

W, H = 1100, 700
FPS = 60

# --- UI theme: obsidian panels, amber/gold trim, chakra-blue + ember highlights -------------------
BG = (9, 10, 16)                # deepest obsidian (bottom of the page backdrop)
BG_TOP = (21, 16, 20)           # warm charcoal (top of the page backdrop)
PANEL = (24, 24, 33)            # standard panel body
PANEL_DEEP = (15, 15, 22)       # inset wells and list containers
PANEL_BORDER = (116, 82, 44)    # default (dim amber) trim
AMBER = (255, 153, 51)          # #ff9933  bright trim, corner accents, active tab
AMBER_DEEP = (230, 115, 0)      # #e67300  major panel borders, primary buttons
AMBER_SOFT = (255, 205, 140)    # headings on dark panels
CHAKRA = (72, 200, 255)         # neon chakra-blue highlight
EMBER = (255, 120, 40)          # chakra-orange highlight
TEXT = (242, 238, 230)
DIM = (156, 152, 166)
GOOD = (112, 232, 140)
BAD = (246, 102, 102)
GOLD_C = (255, 205, 70)
GEM_C = (110, 210, 255)
EXP_C = (150, 255, 160)

# Button base colours - drawing.py shades each one into a gradient with a rim and gloss.
BTN_PRIMARY = (226, 118, 14)    # amber: the main call to action on a screen
BTN_CHAKRA = (34, 128, 220)     # neon blue
BTN_GOOD = (36, 148, 92)
BTN_DANGER = (190, 50, 62)
BTN_VIOLET = (112, 78, 196)
BTN_BRONZE = (156, 92, 26)
BTN_NEUTRAL = (60, 60, 82)

RARITIES = ["Common", "Rare", "Epic", "Legendary"]
# "Chase" and "Secret" are ITEM-ONLY rarity tiers (badge colours in the Bag / result screen).
# They are deliberately NOT in RARITIES, so gacha rates, character stars and stats are unaffected.
RARITY_COLOR = {"Common": (170, 172, 182), "Rare": (80, 150, 255),
                "Epic": (185, 95, 245), "Legendary": (255, 190, 50),
                "Chase": (60, 235, 210), "Secret": (255, 60, 140)}
RARITY_RATE = {"Common": 50, "Rare": 35, "Epic": 12, "Legendary": 3}
RARITY_STATS = {"Common": (100, 12, 5), "Rare": (130, 16, 7),
                "Epic": (170, 21, 10), "Legendary": (220, 28, 14)}
EVO_STONES = {"Common": 1, "Rare": 2, "Epic": 3, "Legendary": 5}
EVO_GOLD = {"Common": 300, "Rare": 600, "Epic": 1000, "Legendary": 2000}
EVO_MIN_LEVEL = 5
LEVEL_CAP, EVOLVED_LEVEL_CAP = 30, 50
EVO_MULT = {"hp": 2.0, "atk": 1.8, "df": 1.8}
EVO2_MULT_DEFAULT = 2.5        # Evolution Tier 2 stat multiplier unless a template overrides it
SINGLE_COST, MULTI_COST = 100, 900
TEAM_SIZE = 3
MAX_WAVES = 3

# --- Stage progression: infinite stages, Solo Boss every Nth stage -------------------
BOSS_STAGE_INTERVAL = 10     # stage 10, 20, 30 ... are Solo Boss stages (1 wave, 1 boss)
BOSS_HP_PER_STAGE = 2.0      # Solo Boss HP  = 80 * stage_factor * (BOSS_HP_PER_STAGE * stage)
BOSS_ATK_PER_STAGE = 0.03    # Solo Boss ATK = 11 * stage_factor * (1 + BOSS_ATK_PER_STAGE * stage)


def is_boss_stage(stage):
    return stage > 0 and stage % BOSS_STAGE_INTERVAL == 0


# --- Tailed Beast (Vi Thu) drop rate ------------------------------------------------
TAILED_BEAST_DROP_RATE = 0.01   # Shukaku, Matatabi, Isobu, Son Goku & Kokuo: 1% on their designated World Boss kill
NARUTO_CLOAK_DROP_RATE = 0.001  # Naruto Cloak: 0.1% from EVERY Leaf Village World Boss kill

# --- Naruto Tier 2 evolution: Nine-Tails Chakra Naruto (Sage Naruto -> Legendary) ----------
NARUTO_EVO2_NAME = "Nine-Tails Chakra Naruto"
NARUTO_EVO2_COST = {
    "duplicates": 2,         # 2 x Epic Naruto = Sage Naruto (evo tier 1) copies, consumed
    "gold": 10000,
    "naruto_cloak": 1,       # ITEMS key (Secret drop)
    "chakra": 50,            # ITEMS key
    "black_chakra": 5,       # ITEMS key
}
NARUTO_EVO2_DUPLICATE_STAGE = 1                    # duplicates must be at this evo stage (Sage Naruto)
NARUTO_EVO2_MULT = {"hp": 3.0, "atk": 3.2, "df": 2.8}   # stat multipliers (tier 1 uses EVO_MULT)
NARUTO_EVO2_LEVEL_CAP = 70                         # level cap of Nine-Tails Chakra Naruto (tier 1 = 50)

# Nine-Tails Chakra Naruto combat tuning
KURAMA_COLOR = (255, 130, 30)       # vibrant chakra-orange (popups, sparks, rings)
KURAMA_SKILL_NAME = "Kurama Rasengan"
KURAMA_SKILL_HITS = 5               # basic attacks that must land to charge the skill
KURAMA_AUTO_FIRE = True             # True: the skill fires by itself once charged (even in manual mode);
                                    # False: it only becomes READY and AUTO / a click casts it
KURAMA_RASENGAN_MULT = 5.0          # x ATK on the main target (skill_naruto_rasengan.png projectile)
KURAMA_RASENGAN_SPLASH = 0.40       # other enemies take this fraction of the main hit (0 = pure single target)
KURAMA_CAST_TIME = 0.55             # naruto_kurama_model_animation.png plays this long before the ball is fired
KURAMA_RASENGAN_TRAVEL = 0.40       # flight time of the Rasengan ball
KURAMA_WARD_INTERVAL = 15.0         # passive: first ward 15s after combat starts, then every 15s
KURAMA_WARD_DURATION = 10.0         # seconds the ward lasts
KURAMA_WARD_REDUCTION = 0.15        # incoming damage -15%
KURAMA_AURA_ALPHA = 105             # 0-255 opacity of aura_kurama.png (soft / faded look)
# naruto_attack.png usage while dashing:  "body" = the sheet IS Naruto while he dashes/punches,
# "impact" = Naruto keeps his normal sprite and the sheet is drawn as the punch effect on the target.
NARUTO_ATTACK_SHEET_MODE = "body"

# Roushi (Stage 40 World Boss) magma / burn colours
MAGMA_COLOR = (255, 110, 40)
BURN_COLOR = (255, 150, 50)

# Han (Stage 50 World Boss) steam / armour colours
HAN_DEF_COLOR = (140, 170, 205)      # "DEF +15%!" popup + armour pulse (steel blue-gray)
HAN_STEAM_COLOR = (200, 215, 230)    # steam cannon sparks / rings / fallback projectile

ITEMS = {
    "stones":       {"name": "Evolution Stone", "short": "Stones",   "rarity": "Common",    "color": (255, 150, 220), "desc": "Crystallized energy used to awaken heroes. Farmed in the Stone Mine."},
    "chakra":       {"name": "Chakra",          "short": "Chakra",   "rarity": "Common",    "color": (110, 190, 255), "desc": "Spiritual energy needed to awaken Naruto, Sasuke, and Sakura. Dropped in Leaf Village."},
    "shukaku":      {"name": "Shukaku",         "short": "Shukaku",  "rarity": "Chase",     "color": (225, 185, 105), "desc": "One-Tailed beast power sealed within Gaara. Dropped exclusively by Stage 10 World Boss."},
    "matatabi":     {"name": "Matatabi",        "short": "Matatabi", "rarity": "Chase",     "color": (80, 180, 255), "desc": "Two-Tailed beast spirit shrouded in blue flames. Dropped exclusively by Stage 20 World Boss Nii Yugito."},
    "isobu":        {"name": "Isobu",           "short": "Isobu",    "rarity": "Chase",     "color": (140, 160, 180), "desc": "Three-Tailed giant turtle beast spirit. Dropped exclusively by Stage 30 World Boss Yagura Karatachi."},
    "son_goku":     {"name": "Son Goku",        "short": "Son Goku", "rarity": "Chase",     "color": (220, 70, 50), "desc": "Four-Tailed beast spirit. Dropped exclusively by Stage 40 World Boss Roushi."},
    "naruto_cloak": {"name": "Naruto Cloak",    "short": "N.Cloak",  "rarity": "Secret",    "color": (255, 70, 150), "desc": "A flame-patterned cloak of a Leaf legend. Ultra-rare (0.1%) drop from any Leaf Village World Boss."},
    "kokuo":        {"name": "Kokuo",           "short": "Kokuo",    "rarity": "Chase",     "color": (200, 215, 230), "desc": "Five-Tailed horse beast spirit wreathed in boiling steam. Dropped exclusively by Stage 50 World Boss Han."},
    "black_chakra": {"name": "Black Chakra",    "short": "B.Chakra", "rarity": "Rare",      "color": (150, 100, 235), "desc": "Forbidden dark chakra required for Sasuke's second awakening."},
}

DEFAULT_THEME = {"bg": (22, 26, 42), "floor": (32, 38, 58), "line": (40, 46, 70), "accent": (150, 160, 220)}
MAPS = [
    {"id": "stone_mine", "name": "Stone Mine",
     "desc": "A dark crystal cave. Farm Evolution Stones to awaken your heroes.",
     "bg": (34, 28, 40), "floor": (50, 42, 60), "line": (64, 54, 76), "accent": (255, 150, 220),
     "drops": [
         {"item": "stones", "chance": 1.00, "min": 1, "max": 1, "boss_qty_mult": 3},
         {"item": "stones", "chance": 0.40, "min": 1, "max": 1, "note": "bonus",
          "boss_chance": 1.00, "boss_qty_mult": 3},
     ]},
    {"id": "leaf_village", "name": "Leaf Village",
     "desc": "Hidden village of the leaf. Battle rogue ninjas to collect Chakra and legendary tailed beast spirits.",
     "bg": (20, 38, 30), "floor": (30, 60, 42), "line": (40, 78, 54), "accent": (120, 225, 130),
     "enemies": [("Rogue Ninja", (90, 180, 100), "Physical")],
     "bosses": [
         ("Gaara", (210, 140, 60), "Magic"),                # Stage 10 Solo World Boss
         ("Nii Yugito", (80, 160, 255), "Physical"),        # Stage 20 Solo World Boss
         ("Yagura Karatachi", (80, 180, 140), "Physical"),  # Stage 30 Solo World Boss
         ("Roushi", (225, 90, 40), "Magic"),                # Stage 40 Solo World Boss (magma, burn)
         ("Han", (150, 170, 195), "Physical"),              # Stage 50 Solo World Boss (steam armour, steam cannon)
     ],
     # NOTE: boss index = (stage // BOSS_STAGE_INTERVAL - 1) % len(bosses).  Keep this list in stage order:
     # index 0 = stage 10 ... index 4 = stage 50.  With only 4 entries stage 50 wrapped back to Gaara.
     "drops": [
         {"item": "chakra", "chance": 0.90, "min": 2, "max": 4, "qty_per_stage": 0.5,
          "boss_chance": 1.00, "boss_qty_mult": 3},
         {"item": "shukaku", "chance": 0.0, "min": 1, "max": 1,
          "boss_chance": TAILED_BEAST_DROP_RATE, "target_stage": 10, "note": "Gaara Boss"},
         {"item": "matatabi", "chance": 0.0, "min": 1, "max": 1,
          "boss_chance": TAILED_BEAST_DROP_RATE, "target_stage": 20, "note": "Yugito Boss"},
         {"item": "isobu", "chance": 0.0, "min": 1, "max": 1,
          "boss_chance": TAILED_BEAST_DROP_RATE, "target_stage": 30, "note": "Yagura Boss"},
         {"item": "son_goku", "chance": 0.0, "min": 1, "max": 1,
          "boss_chance": TAILED_BEAST_DROP_RATE, "target_stage": 40, "note": "Roushi Boss"},
         {"item": "kokuo", "chance": 0.0, "min": 1, "max": 1,
          "boss_chance": TAILED_BEAST_DROP_RATE, "target_stage": 50, "note": "Han Boss"},   # 1%
         # 0.1% on every World Boss stage (10, 20, 30, 40, ...) - no target_stage, never on regular stages
         {"item": "naruto_cloak", "chance": 0.0, "min": 1, "max": 1,
          "boss_chance": NARUTO_CLOAK_DROP_RATE, "note": "Any World Boss"},
         {"item": "black_chakra", "chance": 0.02, "min": 1, "max": 1, "bonus": 0.002, "cap": 0.03,
          "boss_chance": 0.20, "boss_cap": 0.35},
     ]},
]
MAP_BY_ID = {m["id"]: m for m in MAPS}
DEFAULT_MAP_ID = MAPS[0]["id"]

# --- Admin / cheat menu ----------------------------------------------------------
ADMIN_PASSCODE = "101202"
ADMIN_GRANT = 10000          # amount added by every admin "claim" button


# --- Mini-bosses (spawn in regular waves only, never on Solo Boss stages) -----------
# Sprites live in assets/enemies/<sprite>.  "frames": None = auto-detect from the sheet's aspect
# ratio; set it to the real frame count (e.g. 4) if a sheet animates wrongly.
# "flip": True mirrors the sprite (use it if a sheet faces right and should face the heroes).
MINIBOSS_CHANCE_FINAL = 0.60   # chance that the last wave's boss slot is one of these mini-bosses
MINIBOSS_CHANCE_EARLY = 0.15   # chance that waves before the last include one (replaces a grunt)
MINIBOSS_CLONE_SUFFIX = " Clone"
MINIBOSS_CLONE_X = 905         # x position of White Zetsu's clones (boss stands at x=830)
BLEED_COLOR = (225, 45, 70)

MINIBOSSES = [
    {"id": "white_zetsu", "name": "White Zetsu", "sprite": "white_zetsu.png", "frames": 8, "flip": False,
     "color": (225, 235, 225), "dmg_type": "Physical", "hp_mult": 2.6, "atk_mult": 1.0, "df_mult": 1.5,
     "weight": 1, "tip": "Spawns 2 clones on entry.",
     # Each clone: 15% of the boss's max HP, 40% of its damage.
     "clones": {"count": 2, "hp_pct": 0.15, "dmg_pct": 0.40}},
    {"id": "zabuza_momochi", "name": "Zabuza Momochi", "sprite": "zabuza_momochi.png", "frames": 8,
     "flip": False, "color": (110, 130, 165), "dmg_type": "Physical", "hp_mult": 3.4, "atk_mult": 1.2,
     "df_mult": 1.5, "weight": 1, "tip": "Every 3rd hit on a target causes bleeding.",
     # Every `hits`-th basic attack on the same target adds a bleed stack: `ticks` ticks of
     # `atk_pct` x boss ATK (min 1) every `interval` seconds. Up to `max_stacks` stacks per target.
     "bleed": {"hits": 3, "atk_pct": 0.02, "ticks": 5, "interval": 1.0, "max_stacks": 5}},
    {"id": "sasori_puppet", "name": "Sasori Puppet", "sprite": "sasori_puppet.png", "frames": 8,
     "flip": False, "color": (170, 95, 60), "dmg_type": "Magic", "hp_mult": 2.8, "atk_mult": 1.0,
     "df_mult": 1.5, "weight": 1, "tip": "Poison: each hit cuts target damage 1-2%.",
     # Each basic attack: target loses uniform(min, max) of its damage output, stacking up to `cap`.
     # The debuff refreshes on every hit and wears off `duration` seconds after the last one.
     "poison": {"label": "POISON", "min": 0.01, "max": 0.02, "cap": 0.40, "duration": 10.0,
                "color": (150, 235, 90)}},
    {"id": "summon_snake", "name": "Summon Snake", "sprite": "summon_snake.png", "frames": 8,
     "flip": False, "color": (110, 90, 170), "dmg_type": "Physical", "hp_mult": 3.0, "atk_mult": 1.0,
     "df_mult": 1.5, "weight": 1, "tip": "Venom: each strike drains 1-2% damage.",
     "poison": {"label": "VENOM", "min": 0.01, "max": 0.02, "cap": 0.40, "duration": 10.0,
                "color": (190, 120, 255)}},
]
MINIBOSS_BY_ID = {m["id"]: m for m in MINIBOSSES}
MINIBOSS_BY_NAME = {m["name"]: m for m in MINIBOSSES}


def miniboss_for_name(name):
    """Mini-boss definition for a unit name (White Zetsu's clones map to White Zetsu), else None."""
    if name.endswith(MINIBOSS_CLONE_SUFFIX):
        name = name[:-len(MINIBOSS_CLONE_SUFFIX)]
    return MINIBOSS_BY_NAME.get(name)