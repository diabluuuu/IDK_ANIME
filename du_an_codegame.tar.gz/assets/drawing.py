"""drawing.py - font cache, gradient/glow panel helpers, and hero/enemy rendering with fallback shapes."""
import math

import pygame

from config import *
from asset_manager import AssetManager

assets = AssetManager()


def shade(c, f):
    return tuple(max(0, min(255, int(v * f))) for v in c[:3])


def blend(c1, c2, t):
    """Linearly interpolates between two RGB colours (t in 0.0..1.0)."""
    t = max(0.0, min(1.0, float(t)))
    return (
        int(c1[0] + (c2[0] - c1[0]) * t),
        int(c1[1] + (c2[1] - c1[1]) * t),
        int(c1[2] + (c2[2] - c1[2]) * t),
    )


_fonts = {}
_grad_cache = {}
_glow_cache = {}
_backdrop_cache = None


def font(size, bold=False):
    key = (size, bold)
    if key not in _fonts:
        _fonts[key] = pygame.font.SysFont("bahnschrift,segoeui,arial,dejavusans,freesans", size, bold=bold)
    return _fonts[key]


def txt(surf, s, size, color, pos, anchor="topleft", bold=False, shadow=True):
    f = font(size, bold)
    text_str = str(s)
    if shadow and (bold or size >= 15):
        sh_img = f.render(text_str, True, (6, 7, 12))
        sh_r = sh_img.get_rect(**{anchor: (pos[0] + 1, pos[1] + 2 if size >= 22 else pos[1] + 1)})
        surf.blit(sh_img, sh_r)
    img = f.render(text_str, True, color[:3])
    r = img.get_rect(**{anchor: pos})
    surf.blit(img, r)
    return r


def overlay(surf, rect, rgba, radius=0):
    rect = pygame.Rect(rect)
    if rect.w <= 0 or rect.h <= 0:
        return
    s = pygame.Surface((rect.w, rect.h), pygame.SRCALPHA)
    pygame.draw.rect(s, rgba, s.get_rect(), border_radius=radius)
    surf.blit(s, rect.topleft)


def gradient_rect(surf, rect, top_col, bot_col, radius=10):
    """Draws a rounded rectangle filled with a smooth vertical gradient (cached by size & colours)."""
    rect = pygame.Rect(rect)
    w, h = max(1, rect.w), max(1, rect.h)
    top_c, bot_c = tuple(top_col[:3]), tuple(bot_col[:3])
    radius = max(0, min(int(radius), min(w, h) // 2))
    key = (w, h, top_c, bot_c, radius)
    if key not in _grad_cache:
        if len(_grad_cache) > 320:
            _grad_cache.clear()
        grad = pygame.Surface((w, h), pygame.SRCALPHA)
        # Build a 1px wide vertical strip and scale it horizontally for fast smooth gradients
        strip = pygame.Surface((1, h), pygame.SRCALPHA)
        hm1 = max(1, h - 1)
        for y in range(h):
            c = blend(top_c, bot_c, y / hm1)
            strip.set_at((0, y), (*c, 255))
        scaled_strip = pygame.transform.scale(strip, (w, h))
        if radius > 0:
            mask = pygame.Surface((w, h), pygame.SRCALPHA)
            pygame.draw.rect(mask, (255, 255, 255, 255), (0, 0, w, h), border_radius=radius)
            scaled_strip.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
        grad.blit(scaled_strip, (0, 0))
        _grad_cache[key] = grad
    surf.blit(_grad_cache[key], rect.topleft)


def glow_rect(surf, rect, color, radius=12, spread=6, alpha=65):
    """Draws a soft multi-ring outer glow around `rect` (cached for 60 FPS performance)."""
    rect = pygame.Rect(rect)
    if rect.w <= 0 or rect.h <= 0 or alpha <= 0:
        return
    col = tuple(color[:3])
    spread = max(2, int(spread))
    alpha = max(0, min(255, int(alpha))) // 8 * 8
    if alpha <= 0:
        return
    key = (rect.w, rect.h, col, int(radius), spread, alpha)
    if key not in _glow_cache:
        if len(_glow_cache) > 200:
            _glow_cache.clear()
        pad = spread * 2
        gs = pygame.Surface((rect.w + pad * 2, rect.h + pad * 2), pygame.SRCALPHA)
        steps = 3
        for i in range(steps, 0, -1):
            inf = int(spread * (i / steps) * 1.6)
            a = int(alpha * (1.0 - (i - 1) / (steps + 0.5)) * 0.55)
            r_box = pygame.Rect(pad - inf, pad - inf, rect.w + inf * 2, rect.h + inf * 2)
            pygame.draw.rect(gs, (*col, a), r_box, width=max(2, spread // 2 + 1), border_radius=radius + inf)
        _glow_cache[key] = (gs, pad)
    gs, pad = _glow_cache[key]
    surf.blit(gs, (rect.x - pad, rect.y - pad))


def draw_corner_accents(surf, rect, color=PANEL_BORDER_GLOW, length=12, thickness=2, inset=3):
    """Draws sleek ninja L-bracket corner ornaments on a card or panel."""
    rect = pygame.Rect(rect)
    x0, y0 = rect.x + inset, rect.y + inset
    x1, y1 = rect.right - 1 - inset, rect.bottom - 1 - inset
    L = min(length, rect.w // 4, rect.h // 4)
    if L < 4:
        return
    c = color[:3]
    # Top-left
    pygame.draw.line(surf, c, (x0, y0), (x0 + L, y0), thickness)
    pygame.draw.line(surf, c, (x0, y0), (x0, y0 + L), thickness)
    # Top-right
    pygame.draw.line(surf, c, (x1 - L, y0), (x1, y0), thickness)
    pygame.draw.line(surf, c, (x1, y0), (x1, y0 + L), thickness)
    # Bottom-left
    pygame.draw.line(surf, c, (x0, y1), (x0 + L, y1), thickness)
    pygame.draw.line(surf, c, (x0, y1 - L), (x0, y1), thickness)
    # Bottom-right
    pygame.draw.line(surf, c, (x1 - L, y1), (x1, y1), thickness)
    pygame.draw.line(surf, c, (x1, y1 - L), (x1, y1), thickness)


def draw_backdrop(surf, t=0.0):
    """Renders the cohesive obsidian-and-chakra background across the 1100x700 screen."""
    global _backdrop_cache
    if _backdrop_cache is None:
        bg = pygame.Surface((W, H))
        gradient_rect(bg, pygame.Rect(0, 0, W, H), BG_TOP, BG_BOT, radius=0)
        # Subtle warm chakra glow in bottom-left & cool neon-blue aura in top-right
        warm = pygame.Surface((W, H), pygame.SRCALPHA)
        for rad, a in ((460, 12), (320, 16), (190, 20)):
            pygame.draw.circle(warm, (*CHAKRA_ORANGE, a), (140, H + 20), rad)
        for rad, a in ((420, 10), (260, 14)):
            pygame.draw.circle(warm, (*NEON_BLUE, a), (W - 90, 30), rad)
        # Faint diagonal ninja lattice lines
        for x in range(-H, W + H, 36):
            pygame.draw.line(warm, (255, 175, 95, 7), (x, 0), (x - H // 2, H), 1)
        bg.blit(warm, (0, 0))
        _backdrop_cache = bg
    surf.blit(_backdrop_cache, (0, 0))


def panel(surf, rect, fill=PANEL, border=PANEL_BORDER, radius=12, width=2,
          glow=None, corners=None, grad_bottom=None):
    """Modern layered RPG panel with gradient fill, drop shadow, inner bevel, and corner brackets."""
    rect = pygame.Rect(rect)
    if rect.w <= 0 or rect.h <= 0:
        return

    # Soft grounded drop shadow
    if width >= 2 and rect.h >= 28:
        overlay(surf, rect.move(0, 3), (0, 0, 0, 95), radius=radius)

    if glow is not None:
        glow_rect(surf, rect, glow, radius=radius, spread=5, alpha=64)

    top_c = shade(fill, 1.15)
    bot_c = grad_bottom if grad_bottom is not None else shade(fill, 0.84)
    gradient_rect(surf, rect, top_c, bot_c, radius=radius)

    # Inner dark bevel / specular sheen
    if rect.w > 12 and rect.h > 12:
        inner = rect.inflate(-2, -2)
        pygame.draw.rect(surf, shade(fill, 1.32), inner, 1, border_radius=max(1, radius - 1))

    if width > 0 and border is not None:
        pygame.draw.rect(surf, border, rect, width, border_radius=radius)

    show_corners = corners if corners is not None else (rect.w >= 240 and rect.h >= 135 and width >= 2)
    if show_corners:
        accent_col = PANEL_BORDER_GLOW if border == PANEL_BORDER else shade(border, 1.25)
        draw_corner_accents(surf, rect, color=accent_col, length=11, thickness=2, inset=4)


def hp_bar(surf, x, y, w, h, frac, color=(80, 220, 110)):
    """Glossy two-tone RPG health/progress bar with recessed trough and edge highlight."""
    x, y, w, h = int(x), int(y), int(w), int(h)
    frac = max(0.0, min(1.0, float(frac)))
    rad = max(3, h // 2)
    trough = pygame.Rect(x, y, w, h)
    pygame.draw.rect(surf, (12, 14, 22), trough, border_radius=rad)
    if frac > 0:
        fw = max(rad * 2, int(w * frac))
        fw = min(w, fw)
        fill_r = pygame.Rect(x, y, fw, h)
        pygame.draw.rect(surf, shade(color, 0.82), fill_r, border_radius=rad)
        if h >= 6:
            shine_r = pygame.Rect(x + 1, y + 1, max(1, fw - 2), max(2, h // 2))
            pygame.draw.rect(surf, shade(color, 1.28), shine_r, border_radius=max(2, rad - 1))
    pygame.draw.rect(surf, (88, 78, 68), trough, 1, border_radius=rad)


def draw_star_polygon(surf, cx, cy, r, color, outline=(18, 14, 20)):
    """Draws a crisp 5-pointed star icon at (cx, cy) with outer radius `r`."""
    cx, cy = float(cx), float(cy)
    r = max(2.5, float(r))
    ri = r * 0.44
    pts = []
    for i in range(10):
        ang = -math.pi / 2 + i * (math.pi / 5)
        rad = r if i % 2 == 0 else ri
        pts.append((cx + math.cos(ang) * rad, cy + math.sin(ang) * rad))
    pygame.draw.polygon(surf, color, pts)
    if r >= 4:
        pygame.draw.polygon(surf, shade(color, 1.35), pts[:4] + [(cx, cy)])
    pygame.draw.polygon(surf, outline, pts, 1)


def draw_pedestal(surf, cx, cy, rx=38, ry=13, color=CHAKRA_ORANGE, t=0.0):
    """Draws an glowing anime RPG summoning/chakra pedestal beneath a hero portrait."""
    cx, cy, rx, ry = int(cx), int(cy), int(rx), int(ry)
    pulse = 1.0 + 0.05 * math.sin(t * 4.0)
    w, h = int(rx * 2.5), int(ry * 2.8)
    ped = pygame.Surface((w, h), pygame.SRCALPHA)
    mx, my = w // 2, h // 2
    r_outer = (mx - int(rx * pulse), my - int(ry * pulse), int(rx * 2 * pulse), int(ry * 2 * pulse))
    r_inner = (mx - int(rx * 0.72), my - int(ry * 0.72), int(rx * 1.44), int(ry * 1.44))
    pygame.draw.ellipse(ped, (*color[:3], 42), r_outer)
    pygame.draw.ellipse(ped, (*color[:3], 150), r_outer, 2)
    pygame.draw.ellipse(ped, (*shade(color, 1.35), 110), r_inner, 1)
    surf.blit(ped, (cx - mx, cy - my))


def _draw_aura(surf, col, cx, cy, s, t):
    size = int(s * 3)
    aura = pygame.Surface((size, size), pygame.SRCALPHA)
    c = size // 2
    pulse = 1 + 0.06 * math.sin(t * 4)
    for i, a in enumerate((35, 55, 85)):
        pygame.draw.circle(aura, (*col, a), (c, c), int(s * (1.4 - 0.25 * i) * pulse))
    surf.blit(aura, (cx - c, cy - c))


def _draw_stars(surf, tpl, cx, cy, s, evo_stage=0):
    if s >= 34:
        rarity = ((tpl.evo2_rarity or tpl.evo_rarity) if evo_stage == 2
                  else (tpl.evo_rarity if evo_stage == 1 else tpl.rarity))
        k = RARITIES.index(rarity) + 1
        star_r = max(3.5, s * 0.095)
        spacing = max(star_r * 2.15, s * 0.23)
        rc = RARITY_COLOR[rarity]
        for i in range(k):
            sx = cx + (i - (k - 1) / 2) * spacing
            sy = cy - s * 1.02
            draw_star_polygon(surf, sx, sy, star_r, rc)


def _stone_tint_surface(img):
    """Creates a petrified stone-gray version of a sprite surface."""
    try:
        gray = pygame.transform.grayscale(img)
    except (AttributeError, pygame.error, ValueError):
        gray = img.copy()
    tinted = gray.copy()
    tinted.fill((175, 175, 185, 255), special_flags=pygame.BLEND_RGBA_MULT)
    return tinted


def draw_hero(surf, tpl, evo_stage, cx, cy, s, t=0.0, stunned=False):
    # 1.4x keeps the sprite inside the Roster/Team card frames
    cx, cy = int(cx), int(cy)
    anim_t = 0.0 if stunned else t
    img = assets.get_character_image(tpl.name, evo_stage, int(s * 1.4), time_sec=anim_t)
    col = (tpl.evo2_color or tpl.evo_color) if evo_stage == 2 else (tpl.evo_color if evo_stage == 1 else tpl.color)
    if stunned:
        col = (150, 150, 160)

    if img is not None:
        # Safety net: a sprite wider than the portrait box (e.g. a badly sliced sheet) is shrunk to fit
        # instead of spilling outside the card / circle.
        max_w = int(s * 1.8)
        if img.get_width() > max_w:
            nh = max(1, int(img.get_height() * max_w / img.get_width()))
            img = pygame.transform.smoothscale(img, (max_w, nh))
        if evo_stage > 0 and not stunned:
            _draw_aura(surf, col, cx, cy, s, t)
        if stunned:
            stone_img = _stone_tint_surface(img)
            surf.blit(stone_img, stone_img.get_rect(center=(int(cx), int(cy))))
        else:
            surf.blit(img, img.get_rect(center=(int(cx), int(cy))))
        _draw_stars(surf, tpl, cx, cy, s, evo_stage)
    else:
        # Fallback rendering when the hero has no PNG file
        _draw_hero_shapes(surf, tpl, evo_stage, cx, cy, s, anim_t, stunned=stunned)


def _draw_hero_shapes(surf, tpl, evo_stage, cx, cy, s, t=0.0, stunned=False):
    cx, cy = int(cx), int(cy)
    col = (tpl.evo2_color or tpl.evo_color) if evo_stage == 2 else (tpl.evo_color if evo_stage == 1 else tpl.color)
    if stunned:
        col = (145, 145, 155)
    dark, light = shade(col, 0.55), shade(col, 1.3)
    if evo_stage > 0 and not stunned:
        _draw_aura(surf, col, cx, cy, s, t)
        rarity = (tpl.evo2_rarity or tpl.evo_rarity) if evo_stage == 2 else tpl.evo_rarity
        n = {"Common": 2, "Rare": 3, "Epic": 5, "Legendary": 9}.get(rarity, 3)
        bx, by = cx - s * 0.2, cy + s * 0.2
        for k in range(n):
            ang = math.pi + (k - (n - 1) / 2) * (1.9 / n) + math.sin(t * 3 + k) * 0.08
            ex, ey = bx + math.cos(ang) * s * 1.0, by + math.sin(ang) * s * 0.9
            pygame.draw.line(surf, col, (bx, by), (ex, ey), max(2, int(s * 0.13)))
            pygame.draw.circle(surf, light, (int(ex), int(ey)), max(2, int(s * 0.08)))

    pygame.draw.rect(surf, dark, (cx - s * 0.25, cy + s * 0.4, s * 0.18, s * 0.3), border_radius=3)
    pygame.draw.rect(surf, dark, (cx + s * 0.07, cy + s * 0.4, s * 0.18, s * 0.3), border_radius=3)
    pygame.draw.rect(surf, col, (cx - s * 0.32, cy - s * 0.1, s * 0.64, s * 0.55), border_radius=int(s * 0.15))
    pygame.draw.rect(surf, light, (cx - s * 0.32, cy + s * 0.18, s * 0.64, s * 0.08))
    pygame.draw.circle(surf, dark, (cx, int(cy - s * 0.32)), int(s * 0.31))
    skin = (175, 175, 185) if stunned else (240, 208, 175)
    pygame.draw.circle(surf, skin, (cx, int(cy - s * 0.25)), int(s * 0.25))

    eye = (110, 110, 120) if stunned else ((255, 40, 40) if evo_stage > 0 else (30, 30, 40))
    for ex in (-0.09, 0.09):
        pygame.draw.circle(surf, eye, (int(cx + s * ex), int(cy - s * 0.27)), max(2, int(s * 0.05)))
    if evo_stage > 0:
        for sx in (-1, 1):
            pygame.draw.polygon(surf, light, [(cx + sx * s * 0.12, cy - s * 0.52),
                                              (cx + sx * s * 0.30, cy - s * 0.85),
                                              (cx + sx * s * 0.28, cy - s * 0.48)])
    _draw_stars(surf, tpl, cx, cy, s, evo_stage)


HEAL_COLOR = (120, 255, 170)


def draw_punch(surf, cx, cy, frame_idx, size=80):
    """Sakura's punch impact (3-frame sheet). Falls back to a pink fist burst if the PNG is missing."""
    cx, cy = int(cx), int(cy)
    img = assets.get_sakura_punch_frame(frame_idx, size)
    if img is not None:
        surf.blit(img, img.get_rect(center=(cx, cy)))
        return
    r = int(size * (0.22 + 0.10 * frame_idx))
    pygame.draw.circle(surf, (255, 200, 225), (cx, cy), r)
    pygame.draw.circle(surf, (230, 100, 150), (cx, cy), r, 3)
    for k in range(8):
        ang = k * math.tau / 8 + frame_idx * 0.3
        pygame.draw.line(surf, (255, 255, 255),
                         (cx + int(math.cos(ang) * r * 1.1), cy + int(math.sin(ang) * r * 1.1)),
                         (cx + int(math.cos(ang) * r * 1.8), cy + int(math.sin(ang) * r * 1.8)), 3)


def draw_heal_pulse(surf, cx, cy, f, size=60):
    """Healing pulse over one ally. f = remaining life fraction (1 -> 0)."""
    f = max(0.0, min(1.0, f))
    prog = 1.0 - f
    cx, cy = int(cx), int(cy)
    rad = max(4, int(size * (0.5 + 1.1 * prog)))
    box = rad * 2 + 24
    pulse = pygame.Surface((box, box), pygame.SRCALPHA)
    c = box // 2
    pygame.draw.circle(pulse, (*HEAL_COLOR, int(70 * f)), (c, c), rad)
    pygame.draw.circle(pulse, (*HEAL_COLOR, int(220 * f)), (c, c), rad, 3)
    surf.blit(pulse, (cx - c, cy - c))
    # rising "+" crosses
    for k in range(4):
        px = cx + int((k - 1.5) * size * 0.28)
        py = cy + int(size * 0.3 - prog * size * (0.9 + 0.12 * k))
        a = int(255 * f)
        arm = max(3, int(size * 0.1))
        cross = pygame.Surface((arm * 2 + 4, arm * 2 + 4), pygame.SRCALPHA)
        m = arm + 2
        pygame.draw.line(cross, (*HEAL_COLOR, a), (m - arm, m), (m + arm, m), 3)
        pygame.draw.line(cross, (*HEAL_COLOR, a), (m, m - arm), (m, m + arm), 3)
        surf.blit(cross, (px - m, py - m))


def draw_sand_shield(surf, cx, cy, s, t=0.0):
    """Draws the 5-frame Sand Shield animation around the Boss, or a sand-sphere fallback."""
    sh_img = assets.get_enemy_skill_sheet_frame("gaara_shied.png", num_frames=5, time_sec=t, size=int(s * 2.1))
    if sh_img is not None:
        surf.blit(sh_img, sh_img.get_rect(center=(int(cx), int(cy))))
        return

    # Fallback: protective swirling sand sphere aura
    rad = int(s * 1.15 * (1 + 0.05 * math.sin(t * 6)))
    size = rad * 2 + 12
    sphere = pygame.Surface((size, size), pygame.SRCALPHA)
    c = size // 2
    pygame.draw.circle(sphere, (215, 175, 85, 70), (c, c), rad)
    pygame.draw.circle(sphere, (240, 205, 110, 150), (c, c), rad, 4)
    pygame.draw.circle(sphere, (185, 140, 60, 120), (c, c), int(rad * 0.82), 2)
    for k in range(6):
        ang = t * 5 + k * (math.tau / 6)
        px = c + int(math.cos(ang) * rad * 0.9)
        py = c + int(math.sin(ang) * rad * 0.65)
        pygame.draw.circle(sphere, (245, 215, 130, 200), (px, py), 5)
    surf.blit(sphere, (int(cx) - c, int(cy) - c))


def _blit_oriented(surf, img, x, y, tx, ty):
    """Blit a right-facing projectile sprite at (x, y), turned to point at (tx, ty) (never upside-down)."""
    dx, dy = tx - x, ty - y
    if dx < 0:
        img = pygame.transform.flip(img, True, False)
        ang = math.degrees(math.atan2(dy, -dx))
    else:
        ang = math.degrees(math.atan2(-dy, dx))
    img = pygame.transform.rotate(img, ang)
    surf.blit(img, img.get_rect(center=(int(x), int(y))))


def _magma_ball(surf, cx, cy, tx, ty, r, t):
    """Fallback molten projectile: glowing core with a fading trail."""
    ang = math.atan2(ty - cy, tx - cx)
    glow = pygame.Surface((r * 5, r * 5), pygame.SRCALPHA)
    gc = r * 5 // 2
    pygame.draw.circle(glow, (*MAGMA_COLOR, 60), (gc, gc), int(r * 2.2))
    surf.blit(glow, (int(cx) - gc, int(cy) - gc))
    for k in range(1, 5):
        pygame.draw.circle(surf, shade(MAGMA_COLOR, 1.0 - 0.17 * k),
                           (int(cx - math.cos(ang) * k * r * 0.9), int(cy - math.sin(ang) * k * r * 0.9)),
                           max(2, int(r * (1 - 0.17 * k))))
    pygame.draw.circle(surf, MAGMA_COLOR, (int(cx), int(cy)), r)
    pygame.draw.circle(surf, (255, 225, 130), (int(cx), int(cy)), max(2, int(r * (0.5 + 0.08 * math.sin(t * 20)))))
    pygame.draw.circle(surf, (140, 40, 20), (int(cx), int(cy)), r, 2)


def draw_magma_shot(surf, cx, cy, tx, ty, size=46, t=0.0):
    """Roushi's basic attack projectile (assets/attacks/magma_shot.png), shapes if the PNG is missing."""
    img = assets.get_magma_shot_frame(time_sec=t, size=size)
    if img is not None:
        _blit_oriented(surf, img, cx, cy, tx, ty)
    else:
        _magma_ball(surf, cx, cy, tx, ty, max(5, int(size * 0.3)), t)


def draw_super_magma_shot(surf, cx, cy, tx, ty, size=96, t=0.0):
    """Roushi's skill projectile (assets/attacks/super_magma_shot.png), shapes if the PNG is missing."""
    img = assets.get_super_magma_shot_frame(time_sec=t, size=size)
    if img is not None:
        _blit_oriented(surf, img, cx, cy, tx, ty)
    else:
        _magma_ball(surf, cx, cy, tx, ty, max(10, int(size * 0.3)), t)


def draw_roushi_cast(surf, cx, cy, progress, size=150):
    """Roushi's casting animation (assets/enemy_skills/roushi_skill.png), progress 0 -> 1."""
    img = assets.get_roushi_skill_frame(progress=progress, size=size)
    if img is not None:
        surf.blit(img, img.get_rect(center=(int(cx), int(cy))))
        return
    cx, cy = int(cx), int(cy)
    rad = max(6, int(size * (0.25 + 0.35 * progress)))
    pygame.draw.circle(surf, MAGMA_COLOR, (cx, cy), rad, max(2, int(8 * (1 - progress))))
    pygame.draw.circle(surf, (255, 220, 120), (cx, cy), max(3, rad // 2), 2)
    for k in range(8):
        ang = k * math.tau / 8 + progress * 3
        pygame.draw.circle(surf, MAGMA_COLOR, (int(cx + math.cos(ang) * rad * 1.15),
                                               int(cy + math.sin(ang) * rad * 1.15 - progress * 20)), 5)


def _steam_ball(surf, cx, cy, tx, ty, r, t):
    """Fallback steam-cannon projectile: puffy white-blue cloud with a trailing vapour wake."""
    ang = math.atan2(ty - cy, tx - cx)
    glow = pygame.Surface((r * 5, r * 5), pygame.SRCALPHA)
    gc = r * 5 // 2
    pygame.draw.circle(glow, (*HAN_STEAM_COLOR, 55), (gc, gc), int(r * 2.2))
    surf.blit(glow, (int(cx) - gc, int(cy) - gc))
    for k in range(1, 5):
        puff = pygame.Surface((r * 3, r * 3), pygame.SRCALPHA)
        pygame.draw.circle(puff, (*HAN_STEAM_COLOR, max(20, 150 - 32 * k)), (r * 3 // 2, r * 3 // 2),
                           max(3, int(r * (1 - 0.15 * k))))
        surf.blit(puff, (int(cx - math.cos(ang) * k * r * 1.0) - r * 3 // 2,
                         int(cy - math.sin(ang) * k * r * 1.0) - r * 3 // 2))
    pygame.draw.circle(surf, HAN_STEAM_COLOR, (int(cx), int(cy)), r)
    pygame.draw.circle(surf, (245, 250, 255), (int(cx), int(cy)), max(2, int(r * (0.55 + 0.08 * math.sin(t * 20)))))
    pygame.draw.circle(surf, HAN_DEF_COLOR, (int(cx), int(cy)), r, 2)


def draw_han_steam_shot(surf, cx, cy, tx, ty, size=64, t=0.0):
    """Han's Steam Cannon projectile (assets/attacks/bullet_han.png), shapes if the PNG is missing."""
    img = assets.get_han_bullet_frame(time_sec=t, size=size)
    if img is not None:
        _blit_oriented(surf, img, cx, cy, tx, ty)
    else:
        _steam_ball(surf, cx, cy, tx, ty, max(8, int(size * 0.3)), t)


def draw_bullet_han(surf, cx, cy, tx, ty, size=82, t=0.0):
    draw_han_steam_shot(surf, cx, cy, tx, ty, size=size, t=t)


def draw_han_cast(surf, cx, cy, progress, size=150):
    """Han's casting animation (assets/enemy_skills/han_skill_animation.png), progress 0 -> 1."""
    img = assets.get_han_skill_frame(progress=progress, size=size)
    if img is not None:
        surf.blit(img, img.get_rect(center=(int(cx), int(cy))))
        return
    cx, cy = int(cx), int(cy)
    rad = max(6, int(size * (0.25 + 0.35 * progress)))
    pygame.draw.circle(surf, HAN_STEAM_COLOR, (cx, cy), rad, max(2, int(8 * (1 - progress))))
    pygame.draw.circle(surf, (245, 250, 255), (cx, cy), max(3, rad // 2), 2)
    for k in range(8):
        ang = k * math.tau / 8 + progress * 3
        pygame.draw.circle(surf, HAN_STEAM_COLOR, (int(cx + math.cos(ang) * rad * 1.15),
                                                   int(cy + math.sin(ang) * rad * 1.15 - progress * 24)), 5)


# --- 4 New Mini-Boss FX drawing helpers (Danzo, Kakuzu, Kimimaro, Kisame) --------------------
def draw_danzo_wind(surf, cx, cy, progress=0.0, size=64, t=0.0):
    """Danzo's wind blade projectile (assets/attacks/danzo_attack.png, 3 frames)."""
    img = assets.get_danzo_attack_frame(time_sec=t, progress=progress, size=size)
    if img is not None:
        surf.blit(img, img.get_rect(center=(int(cx), int(cy))))
        return
    cx, cy = int(cx), int(cy)
    r = max(8, int(size * 0.35))
    pygame.draw.circle(surf, DANZO_WIND_COLOR, (cx, cy), r, 3)
    pygame.draw.circle(surf, (235, 255, 245), (cx, cy), max(3, r // 2), 2)


def draw_kakuzu_fire(surf, cx, cy, f=1.0, size=94, t=0.0):
    """Kakuzu's 1s fire tornado pillar summoned on a hero (assets/attacks/kakuzu_attack.png)."""
    cx, cy = int(cx), int(cy)
    img = assets.get_kakuzu_attack_frame(time_sec=t, size=size)
    if img is not None:
        wobble = int(math.sin(t * 22) * 3)
        surf.blit(img, img.get_rect(center=(cx + wobble, cy)))
        return
    h = int(size * 0.9)
    w = int(size * 0.45)
    pygame.draw.polygon(surf, KAKUZU_FIRE_COLOR, [(cx - w, cy - h // 2), (cx + w, cy - h // 2), (cx, cy + h // 2)])
    pygame.draw.polygon(surf, (255, 220, 110), [(cx - w // 2, cy - h // 3), (cx + w // 2, cy - h // 3), (cx, cy + h // 3)])


def draw_kimimaro_bone_shot(surf, cx, cy, progress=0.0, size=46, t=0.0):
    """Kimimaro's bone projectile (assets/attacks/kimimaro_attack.png, 2 frames)."""
    img = assets.get_kimimaro_attack_frame(time_sec=t, progress=progress, size=size)
    if img is not None:
        surf.blit(img, img.get_rect(center=(int(cx), int(cy))))
        return
    cx, cy = int(cx), int(cy)
    pygame.draw.polygon(surf, KIMIMARO_BONE_COLOR, [(cx - 18, cy), (cx + 14, cy - 6), (cx + 14, cy + 6)])
    pygame.draw.polygon(surf, (160, 155, 140), [(cx - 18, cy), (cx + 14, cy - 6), (cx + 14, cy + 6)], 2)


def draw_kimimaro_bones(surf, cx, cy, progress=0.0, size=92, t=0.0):
    """Kimimaro's erupting bone spikes from the ground (assets/enemy_skills/kimimaro_bones.png, 2 frames)."""
    cx, cy = int(cx), int(cy)
    img = assets.get_kimimaro_bones_frame(progress=progress, time_sec=t, size=size)
    if img is not None:
        surf.blit(img, img.get_rect(center=(cx, cy)))
        return
    for dx, h in ((-22, 34), (-8, 52), (8, 58), (22, 38)):
        pts = [(cx + dx - 7, cy + 24), (cx + dx + 7, cy + 24), (cx + dx, cy + 24 - h)]
        pygame.draw.polygon(surf, KIMIMARO_BONE_COLOR, pts)
        pygame.draw.polygon(surf, (140, 135, 120), pts, 2)


def draw_kisame_slash(surf, cx, cy, size=76, t=0.0):
    """Kisame's melee Samehada slash effect (assets/attacks/kisame_attack.png)."""
    cx, cy = int(cx), int(cy)
    img = assets.get_kisame_attack_frame(time_sec=t, size=size)
    if img is not None:
        surf.blit(img, img.get_rect(center=(cx, cy)))
        return
    pygame.draw.arc(surf, KISAME_WATER_COLOR, (cx - 32, cy - 32, 64, 64), 0.4, 2.8, 5)


def draw_kisame_wave(surf, cx, cy, progress=0.0, size=135, t=0.0):
    """Kisame's 20s tsunami wave (assets/enemy_skills/kisame_wave.png, 2 frames)."""
    cx, cy = int(cx), int(cy)
    img = assets.get_kisame_wave_frame(time_sec=t, progress=progress, size=size)
    if img is not None:
        surf.blit(img, img.get_rect(center=(cx, cy)))
        return
    r = int(size * 0.48)
    pygame.draw.circle(surf, KISAME_WATER_COLOR, (cx, cy), r)
    pygame.draw.circle(surf, (230, 250, 255), (cx - r // 3, cy - r // 3), max(6, r // 3))


def draw_burn_status(surf, cx, cy, t, s=50):
    """Flickering flames over a burning unit (Roushi's or Kakuzu's burn)."""
    cx, cy = int(cx), int(cy)
    for k in (-1, 0, 1):
        bx = cx + k * s * 0.3
        h = s * (0.42 + 0.14 * math.sin(t * 9 + k * 2.1))
        base = cy + s * 0.3
        pygame.draw.polygon(surf, BURN_COLOR, [(bx - s * 0.13, base), (bx + s * 0.13, base), (bx, base - h)])
        pygame.draw.polygon(surf, (255, 225, 120), [(bx - s * 0.06, base), (bx + s * 0.06, base),
                                                    (bx, base - h * 0.6)])


# --- Nine-Tails Chakra Naruto (Naruto Evolution Tier 2) -------------------------------------
NARUTO_ATTACK_BODY_SIZE = 104    # px height of naruto_attack.png when it replaces Naruto while he dashes


def draw_kurama_aura(surf, cx, cy, s, t=0.0, strength=1.0):
    """Soft, translucent Kurama chakra cloak (assets/skills/aura_kurama.png) wrapped around one ally."""
    strength = max(0.0, min(1.0, strength))
    if strength <= 0:
        return
    cx, cy = int(cx), int(cy)
    img = assets.get_kurama_aura_frame(time_sec=t, size=int(s * 2.5), alpha=int(KURAMA_AURA_ALPHA * strength))
    if img is not None:
        surf.blit(img, img.get_rect(center=(cx, cy)))
        return
    pulse = 1 + 0.07 * math.sin(t * 5)
    size = int(s * 3.4)
    glow = pygame.Surface((size, size), pygame.SRCALPHA)
    c = size // 2
    for rad, a in ((1.15, 22), (0.95, 34), (0.72, 48)):
        pygame.draw.circle(glow, (*KURAMA_COLOR, int(a * strength * 1.6)), (c, c), int(s * rad * pulse))
    surf.blit(glow, (cx - c, cy - c))


def draw_kurama_cast(surf, cx, cy, progress, size=150):
    """Casting animation (assets/skills/naruto_kurama_model_animation.png), progress 0 -> 1."""
    cx, cy = int(cx), int(cy)
    img = assets.get_kurama_cast_frame(progress=progress, size=size)
    if img is not None:
        surf.blit(img, img.get_rect(center=(cx, cy)))
        return
    rad = max(6, int(size * (0.25 + 0.30 * progress)))
    pygame.draw.circle(surf, KURAMA_COLOR, (cx, cy), rad, max(2, int(8 * (1 - progress))))
    pygame.draw.circle(surf, (255, 225, 140), (cx, cy), max(3, rad // 2), 2)
    for k in range(8):
        ang = k * math.tau / 8 + progress * 4
        pygame.draw.circle(surf, KURAMA_COLOR, (int(cx + math.cos(ang) * rad * 1.2),
                                                int(cy + math.sin(ang) * rad * 1.2)), 5)


def draw_naruto_rasengan(surf, cx, cy, tx, ty, size=90, t=0.0):
    """Rasengan ball (assets/attacks/skill_naruto_rasengan.png); a swirling blue-white ball if missing."""
    img = assets.get_naruto_rasengan_frame(time_sec=t, size=size)
    if img is not None:
        _blit_oriented(surf, img, cx, cy, tx, ty)
        return
    cx, cy = int(cx), int(cy)
    r = max(10, int(size * 0.3))
    glow = pygame.Surface((r * 5, r * 5), pygame.SRCALPHA)
    gc = r * 5 // 2
    pygame.draw.circle(glow, (120, 200, 255, 70), (gc, gc), int(r * 2.1))
    surf.blit(glow, (cx - gc, cy - gc))
    pygame.draw.circle(surf, (110, 190, 255), (cx, cy), r)
    pygame.draw.circle(surf, (235, 250, 255), (cx, cy), max(3, int(r * 0.55)))
    for k in range(3):
        ang = t * 14 + k * math.tau / 3
        pygame.draw.line(surf, (255, 255, 255), (cx, cy),
                         (int(cx + math.cos(ang) * r), int(cy + math.sin(ang) * r)), 2)
    pygame.draw.circle(surf, KURAMA_COLOR, (cx, cy), r, 2)


def draw_naruto_attack(surf, cx, cy, progress, size=NARUTO_ATTACK_BODY_SIZE):
    """One frame of assets/attacks/naruto_attack.png (progress 0 -> 1 across the dash/punch/return)."""
    img = assets.get_naruto_attack_frame(progress=progress, size=size)
    if img is None:
        return False
    surf.blit(img, img.get_rect(center=(int(cx), int(cy))))
    return True


def draw_enemy(surf, name, color, cx, cy, s, boss, t=0.0, world_boss=False, shield_timer=0.0, is_miniboss=False):
    """Renders world bosses, mini-bosses (including White Zetsu clones), and normal enemies
    that have a sprite in assets/enemies/ (e.g. Rogue Ninja). Falls back safely to shapes
    only when the PNG file is missing."""
    mini = None if world_boss else miniboss_for_name(name)
    is_mb = bool(is_miniboss or mini is not None)
    frames = mini.get("frames") if mini else None
    flip = mini.get("flip", False) if mini else False
    target_name = mini["sprite"] if (mini and mini.get("sprite")) else name

    img = assets.get_enemy_image(
        target_name,
        size=int(s * 1.8),
        time_sec=t,
        is_boss=bool(boss or world_boss),
        is_miniboss=is_mb,
        frames=frames,
        flip=flip,
    )

    if img is not None:
        if name == "Nii Yugito":
            aura_rad = int(s * 0.95 + math.sin(t * 6) * 4)
            aura = pygame.Surface((aura_rad * 2 + 10, aura_rad * 2 + 10), pygame.SRCALPHA)
            pygame.draw.circle(aura, (60, 140, 255, 50), (aura_rad + 5, aura_rad + 5), aura_rad)
            surf.blit(aura, (int(cx) - aura_rad - 5, int(cy) - aura_rad - 5))
        elif name == "Yagura Karatachi":
            aura_rad = int(s * 0.95 + math.sin(t * 6) * 4)
            aura = pygame.Surface((aura_rad * 2 + 10, aura_rad * 2 + 10), pygame.SRCALPHA)
            pygame.draw.circle(aura, (80, 190, 150, 50), (aura_rad + 5, aura_rad + 5), aura_rad)
            surf.blit(aura, (int(cx) - aura_rad - 5, int(cy) - aura_rad - 5))
        elif name == "Han":
            aura_rad = int(s * 1.0 + math.sin(t * 4) * 5)
            aura = pygame.Surface((aura_rad * 2 + 10, aura_rad * 2 + 10), pygame.SRCALPHA)
            pygame.draw.circle(aura, (*HAN_DEF_COLOR, 50), (aura_rad + 5, aura_rad + 5), aura_rad)
            pygame.draw.circle(aura, (*HAN_STEAM_COLOR, 35), (aura_rad + 5, aura_rad + 5), int(aura_rad * 0.7))
            surf.blit(aura, (int(cx) - aura_rad - 5, int(cy) - aura_rad - 5))
        elif name == "Roushi":
            aura_rad = int(s * 1.0 + math.sin(t * 5) * 5)
            aura = pygame.Surface((aura_rad * 2 + 10, aura_rad * 2 + 10), pygame.SRCALPHA)
            pygame.draw.circle(aura, (*MAGMA_COLOR, 55), (aura_rad + 5, aura_rad + 5), aura_rad)
            pygame.draw.circle(aura, (*MAGMA_COLOR, 35), (aura_rad + 5, aura_rad + 5), int(aura_rad * 0.7))
            surf.blit(aura, (int(cx) - aura_rad - 5, int(cy) - aura_rad - 5))
        surf.blit(img, img.get_rect(center=(int(cx), int(cy))))
        if world_boss or boss:
            pygame.draw.polygon(surf, GOLD_C, [(cx - s * 0.2, cy - s * 0.7), (cx - s * 0.1, cy - s * 0.9),
                                               (cx, cy - s * 0.75), (cx + s * 0.1, cy - s * 0.9),
                                               (cx + s * 0.2, cy - s * 0.7)])
    else:
        _draw_enemy_shapes(surf, color, cx, cy, s, boss, t)

    if shield_timer > 0:
        draw_sand_shield(surf, cx, cy, s, t)


def _draw_enemy_shapes(surf, color, cx, cy, s, boss, t=0.0):
    sq = 1 + 0.05 * math.sin(t * 5)
    body = pygame.Rect(0, 0, int(s * 1.3), int(s * 1.0 * sq))
    body.center = (cx, cy)
    pygame.draw.ellipse(surf, color, body)
    pygame.draw.ellipse(surf, shade(color, 1.3), body.inflate(-int(s * 0.5), -int(s * 0.55)).move(0, -int(s * 0.12)))
    for ex in (-0.22, 0.22):
        pygame.draw.circle(surf, (255, 255, 255), (int(cx + s * ex), int(cy - s * 0.06)), int(s * 0.12))
        pygame.draw.circle(surf, (200, 20, 20), (int(cx + s * ex), int(cy - s * 0.06)), int(s * 0.06))
    if boss:
        pygame.draw.polygon(surf, GOLD_C, [(cx - s * 0.3, cy - s * 0.48), (cx - s * 0.2, cy - s * 0.8),
                                           (cx, cy - s * 0.55), (cx + s * 0.2, cy - s * 0.8),
                                           (cx + s * 0.3, cy - s * 0.48)])