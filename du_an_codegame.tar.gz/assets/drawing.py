"""drawing.py - UI toolkit (obsidian / amber ninja theme), font + text cache, and hero/enemy rendering.

Everything above the "hero / enemy rendering" divider is presentation helpers used by ui.py.
Expensive pieces (gradients, glows, shadows, button faces, rendered text) are built once and cached,
so a frame is mostly cheap blits - important for the Pygbag / WebAssembly build.
"""
import math
import os

import pygame

from config import *
from asset_manager import AssetManager

assets = AssetManager()

WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
_KEY = (255, 0, 255)            # colour-key for cached rounded gradients (never used as a UI colour)


def shade(c, f):
    return tuple(max(0, min(255, int(v * f))) for v in c)


def mix(a, b, t):
    """Linear blend of two RGB colours (t=0 -> a, t=1 -> b)."""
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))


# ---------------------------------------------------------------------------------------------
# Fonts and text
# ---------------------------------------------------------------------------------------------
_fonts = {}
_FONT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", "fonts")
_FONT_FILES = {False: "ui.ttf", True: "ui_bold.ttf"}    # optional: drop these two files in assets/fonts/


def font(size, bold=False):
    key = (size, bold)
    f = _fonts.get(key)
    if f is None:
        path = os.path.join(_FONT_DIR, _FONT_FILES[bool(bold)])
        try:
            f = pygame.font.Font(path, size) if os.path.isfile(path) else None
        except (pygame.error, OSError):
            f = None
        if f is None:
            f = pygame.font.SysFont("arial,dejavusans,freesans", size, bold=bold)
        _fonts[key] = f
    return f


_text_cache = {}
_shadow_cache = {}
_fit_cache = {}


def _text_surface(s, size, color, bold):
    key = (s, size, color, bold)
    img = _text_cache.get(key)
    if img is None:
        if len(_text_cache) >= 1200:
            _text_cache.clear()
        img = _text_cache[key] = font(size, bold).render(s, True, color)
    return img


def _shadow_surface(s, size, bold):
    key = (s, size, bold)
    img = _shadow_cache.get(key)
    if img is None:
        if len(_shadow_cache) >= 600:
            _shadow_cache.clear()
        img = font(size, bold).render(s, True, (0, 0, 0))
        img.set_alpha(185)
        _shadow_cache[key] = img
    return img


def txt(surf, s, size, color, pos, anchor="topleft", bold=False, shadow=False):
    s = str(s)
    img = _text_surface(s, size, tuple(color), bool(bold))
    r = img.get_rect(**{anchor: pos})
    if shadow:
        surf.blit(_shadow_surface(s, size, bool(bold)), r.move(1, 2))
    surf.blit(img, r)
    return r


def fit_text(s, size, max_w, bold=False, min_size=10):
    """Shrinks the font (down to min_size) and then truncates with '...' until `s` fits max_w pixels."""
    s = str(s)
    key = (s, size, max_w, bool(bold), min_size)
    hit = _fit_cache.get(key)
    if hit is not None:
        return hit
    sz = size
    while sz > min_size and font(sz, bold).size(s)[0] > max_w:
        sz -= 1
    f = font(sz, bold)
    out = s
    if f.size(out)[0] > max_w:
        while len(out) > 1 and f.size(out + "...")[0] > max_w:
            out = out[:-1]
        out = out.rstrip() + "..."
    if len(_fit_cache) >= 1500:
        _fit_cache.clear()
    _fit_cache[key] = (out, sz)
    return out, sz


def txt_fit(surf, s, size, color, pos, max_w, anchor="topleft", bold=False, min_size=10, shadow=False):
    out, sz = fit_text(s, size, max_w, bold, min_size)
    return txt(surf, out, sz, color, pos, anchor, bold, shadow)


# ---------------------------------------------------------------------------------------------
# Cached surfaces: gradients, soft shadows, glows
# ---------------------------------------------------------------------------------------------
_CACHE_MAX = 600
_cache = {}


def _cached(key, build):
    img = _cache.get(key)
    if img is None:
        if len(_cache) >= _CACHE_MAX:
            _cache.clear()
        img = _cache[key] = build()
    return img


def _build_gradient(w, h, top, bottom, radius):
    """Vertical gradient. With radius > 0 the corners are cut with the same primitive pygame uses for
    rounded borders (so a border drawn on top lines up exactly) and keyed out; call _seal() when done."""
    grad = pygame.Surface((w, h), pygame.SRCALPHA)
    last = max(1, h - 1)
    for y in range(h):
        f = y / last
        c = (int(top[0] + (bottom[0] - top[0]) * f),
             int(top[1] + (bottom[1] - top[1]) * f),
             int(top[2] + (bottom[2] - top[2]) * f))
        pygame.draw.line(grad, c, (0, y), (w - 1, y))
    out = pygame.Surface((w, h))
    if radius > 0:
        mask = pygame.Surface((w, h), pygame.SRCALPHA)
        pygame.draw.rect(mask, (255, 255, 255, 255), mask.get_rect(), border_radius=radius)
        grad.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
        out.fill(_KEY)
    out.blit(grad, (0, 0))
    return out


def _seal(surf, radius):
    if radius > 0:
        surf.set_colorkey(_KEY, pygame.RLEACCEL)
    return surf


def gradient_surface(w, h, top, bottom, radius=0):
    w, h = max(1, int(w)), max(1, int(h))
    radius = max(0, min(int(radius), w // 2, h // 2))
    top, bottom = tuple(top), tuple(bottom)
    return _cached(("g", w, h, top, bottom, radius),
                   lambda: _seal(_build_gradient(w, h, top, bottom, radius), radius))


def _falloff_ring(w, h, radius, color, spread, alpha, power):
    """Soft halo around a w x h rounded rect: a (w+2s) x (h+2s) alpha surface with a transparent middle."""
    surf = pygame.Surface((w + spread * 2, h + spread * 2), pygame.SRCALPHA)
    for i in range(spread, 0, -1):
        a = int(alpha * (1 - i / (spread + 1)) ** power)
        pygame.draw.rect(surf, (color[0], color[1], color[2], a),
                         (spread - i, spread - i, w + 2 * i, h + 2 * i), border_radius=radius + i)
    pygame.draw.rect(surf, (0, 0, 0, 0), (spread, spread, w, h), border_radius=radius)
    return surf


def _blit_ring(surf, ring, x, y, band):
    """Blits only the outer `band` pixels of a halo surface (its middle is hidden or transparent anyway)."""
    sw, sh = ring.get_size()
    band = max(1, min(band, sw // 2, sh // 2))
    x, y = int(x), int(y)
    surf.blit(ring, (x, y), (0, 0, sw, band))
    surf.blit(ring, (x, y + sh - band), (0, sh - band, sw, band))
    if sh - 2 * band > 0:
        surf.blit(ring, (x, y + band), (0, band, band, sh - 2 * band))
        surf.blit(ring, (x + sw - band, y + band), (sw - band, band, band, sh - 2 * band))


SHADOW_SPREAD = 9


def draw_glow(surf, rect, radius, color, spread=8, alpha=120, strength=1.0):
    """Coloured outer glow around a rounded rect. `strength` (0..1) lets callers pulse it."""
    rect = pygame.Rect(rect)
    if strength <= 0 or rect.w < 4 or rect.h < 4:
        return
    color = tuple(color)
    radius = max(0, min(radius, rect.w // 2, rect.h // 2))
    ring = _cached(("gl", rect.w, rect.h, radius, color, spread, alpha),
                   lambda: _falloff_ring(rect.w, rect.h, radius, color, spread, alpha, 1.6))
    ring.set_alpha(max(0, min(255, int(255 * strength))))
    _blit_ring(surf, ring, rect.x - spread, rect.y - spread, spread)


def radial_glow(radius, color, alpha=120):
    """Round soft light (bright centre, fades to nothing at the edge)."""
    color = tuple(color)

    def build():
        surf = pygame.Surface((radius * 2, radius * 2), pygame.SRCALPHA)
        steps = min(32, max(8, radius // 2))
        for i in range(steps):
            f = i / steps
            pygame.draw.circle(surf, (color[0], color[1], color[2], int(alpha * f * f)),
                               (radius, radius), max(1, int(radius * (1 - f))))
        return surf
    return _cached(("rg", radius, color, alpha), build)


def corner_accents(surf, rect, color, length=14, thickness=2, inset=4):
    """Bracket-shaped accents with a bright dot in each corner of a panel or card."""
    rect = pygame.Rect(rect)
    x0, y0 = rect.left + inset, rect.top + inset
    x1, y1 = rect.right - 1 - inset, rect.bottom - 1 - inset
    for cx, cy, dx, dy in ((x0, y0, 1, 1), (x1, y0, -1, 1), (x0, y1, 1, -1), (x1, y1, -1, -1)):
        pygame.draw.line(surf, color, (cx, cy), (cx + dx * length, cy), thickness)
        pygame.draw.line(surf, color, (cx, cy), (cx, cy + dy * length), thickness)
        pygame.draw.circle(surf, color, (cx, cy), thickness + 1)


def panel(surf, rect, fill=PANEL, border=PANEL_BORDER, radius=10, width=2,
          glow=None, corners=None, shadow=True, flat=False):
    """Layered panel: soft drop shadow, optional coloured glow, gradient body with an inner highlight,
    border, optional corner accents.  glow = (colour, spread, alpha); corners = accent colour."""
    rect = pygame.Rect(rect)
    if rect.w < 8 or rect.h < 8:
        pygame.draw.rect(surf, fill, rect)
        return
    radius = max(0, min(radius, rect.w // 2, rect.h // 2))
    if shadow and rect.w >= 48 and rect.h >= 28:
        ring = _cached(("sh", rect.w, rect.h, radius),
                       lambda: _falloff_ring(rect.w, rect.h, radius, BLACK, SHADOW_SPREAD, 120, 2.0))
        ring.set_alpha(255)
        _blit_ring(surf, ring, rect.x - SHADOW_SPREAD, rect.y - SHADOW_SPREAD + 4, SHADOW_SPREAD)
    if glow:
        draw_glow(surf, rect, radius, glow[0], glow[1], glow[2])
    if flat:
        pygame.draw.rect(surf, fill, rect, border_radius=radius)
    else:
        top, bot = mix(fill, WHITE, 0.07), mix(fill, BLACK, 0.32)
        surf.blit(gradient_surface(rect.w, rect.h, top, bot, radius), rect.topleft)
        if rect.h >= 24 and width > 0:
            pygame.draw.line(surf, mix(fill, WHITE, 0.2), (rect.x + radius, rect.y + width),
                             (rect.right - radius - 1, rect.y + width))
    if width > 0:
        pygame.draw.rect(surf, border, rect, width, border_radius=radius)
    if corners:
        corner_accents(surf, rect, corners, min(16, rect.w // 4, rect.h // 3), 2, width + 2)


def overlay(surf, rect, rgba, radius=0):
    rect = pygame.Rect(rect)
    if rect.w <= 0 or rect.h <= 0:
        return

    def build():
        s = pygame.Surface((rect.w, rect.h), pygame.SRCALPHA)
        pygame.draw.rect(s, rgba, s.get_rect(), border_radius=radius)
        return s
    if rect.w * rect.h <= 30000:        # small overlays repeat every frame - cache them, never the big flashes
        s = _cached(("ov", rect.w, rect.h, tuple(rgba), radius), build)
    else:
        s = build()
    surf.blit(s, rect.topleft)


def hp_bar(surf, x, y, w, h, frac, color=(80, 220, 110)):
    """Rounded bar: dark trough, gradient fill with a gloss line, thin amber-brown rim."""
    r = max(1, min(h // 2, 5))
    trough = pygame.Rect(x, y, w, h)
    pygame.draw.rect(surf, (10, 10, 15), trough, border_radius=r)
    frac = max(0.0, min(1.0, frac))
    if frac > 0:
        fw = max(min(w, 4), int(w * frac))
        grad = gradient_surface(w, h, shade(color, 1.3), shade(color, 0.7), r)
        surf.blit(grad, (x, y), (0, 0, fw, h))
        if h >= 8 and fw > 2 * r + 2:
            pygame.draw.line(surf, shade(color, 1.6), (x + r, y + 1), (x + fw - r - 1, y + 1))
    pygame.draw.rect(surf, (98, 78, 52), trough, 1, border_radius=r)


# ---------------------------------------------------------------------------------------------
# Buttons, tabs and small widgets
# ---------------------------------------------------------------------------------------------
def button_face(w, h, color, radius, state):
    """Cached button body. state: n(ormal) / h(over) / p(ressed) / d(isabled)."""
    color = tuple(color)

    def build():
        if state == "d":
            top, bot, rim = (62, 62, 76), (34, 34, 44), (80, 78, 94)
        else:
            base = shade(color, {"n": 1.0, "h": 1.16, "p": 0.82}[state])
            top, bot = shade(base, 1.34), shade(base, 0.64)
            if state == "p":
                top, bot = bot, top
            rim = mix(shade(base, 1.75), AMBER_SOFT, 0.2)
        surf = _build_gradient(w, h, top, bot, radius)
        if w > 14 and h > 14:
            gloss = pygame.Surface((w - 8, max(2, h // 2 - 3)), pygame.SRCALPHA)
            pygame.draw.rect(gloss, (255, 255, 255, 34 if state != "d" else 12), gloss.get_rect(),
                             border_radius=max(2, radius - 4))
            surf.blit(gloss, (4, 3))
        pygame.draw.rect(surf, rim, surf.get_rect(), 2 if h >= 28 else 1, border_radius=radius)
        return _seal(surf, radius)
    return _cached(("bf", w, h, color, radius, state), build)


def tab_face(w, h, state):
    """Cached navigation-tab body. state: a(ctive) / h(over) / n(ormal) / d(isabled)."""
    def build():
        if state == "a":
            top, bot, rim = (255, 178, 84), (214, 104, 10), (255, 226, 172)
        elif state == "h":
            top, bot, rim = (60, 52, 64), (34, 30, 42), AMBER_DEEP
        elif state == "d":
            top, bot, rim = (30, 30, 38), (20, 20, 27), (50, 48, 58)
        else:
            top, bot, rim = (46, 42, 56), (26, 24, 34), (98, 72, 44)
        surf = _build_gradient(w, h, top, bot, 11)
        gloss = pygame.Surface((w - 8, max(2, h // 2 - 3)), pygame.SRCALPHA)
        pygame.draw.rect(gloss, (255, 255, 255, 40 if state == "a" else 14), gloss.get_rect(), border_radius=7)
        surf.blit(gloss, (4, 3))
        pygame.draw.rect(surf, rim, surf.get_rect(), 2, border_radius=11)
        return _seal(surf, 11)
    return _cached(("tab", w, h, state), build)


def section_title(surf, text, x, y, size=20, color=TEXT):
    """Heading with a short amber bar in front of it. Returns the rect of the text."""
    r = txt(surf, text, size, color, (x + 12, y), "topleft", True, shadow=True)
    pygame.draw.rect(surf, AMBER, (x, r.y + 3, 4, max(8, r.h - 6)), border_radius=2)
    return r


def divider(surf, x0, x1, y, color=AMBER_DEEP, diamond=True):
    """Hairline that fades out at both ends, with a small diamond in the middle."""
    w = max(4, int(x1 - x0))
    color = tuple(color)

    def build():
        s = pygame.Surface((w, 2), pygame.SRCALPHA)
        for x in range(w):
            f = 1 - abs((x / (w - 1)) * 2 - 1)
            a = int(230 * min(1.0, f * 2.2))
            s.set_at((x, 0), (color[0], color[1], color[2], a))
            s.set_at((x, 1), (color[0], color[1], color[2], a // 3))
        return s
    surf.blit(_cached(("dv", w, color), build), (int(x0), int(y)))
    if diamond:
        cx = int((x0 + x1) // 2)
        pygame.draw.polygon(surf, color, [(cx, y - 3), (cx + 4, y + 1), (cx, y + 5), (cx - 4, y + 1)])


def badge(surf, text, size, color, pos, anchor="topleft", padx=8, pady=3, fill=None):
    """Small pill with coloured text. `pos` is placed on the pill's `anchor`. Returns the pill rect."""
    img = _text_surface(str(text), size, tuple(color), True)
    r = pygame.Rect(0, 0, img.get_width() + padx * 2, img.get_height() + pady * 2)
    setattr(r, anchor, (int(pos[0]), int(pos[1])))
    pygame.draw.rect(surf, fill or mix((12, 12, 18), color, 0.22), r, border_radius=r.h // 2)
    pygame.draw.rect(surf, shade(color, 0.75), r, 1, border_radius=r.h // 2)
    surf.blit(img, img.get_rect(center=r.center))
    return r


def dashed_rect(surf, rect, color, dash=8, gap=6, width=2, inset=0):
    r = pygame.Rect(rect).inflate(-2 * inset, -2 * inset)
    x = r.left
    while x < r.right:
        x2 = min(x + dash, r.right)
        pygame.draw.line(surf, color, (x, r.top), (x2, r.top), width)
        pygame.draw.line(surf, color, (x, r.bottom - 1), (x2, r.bottom - 1), width)
        x += dash + gap
    y = r.top
    while y < r.bottom:
        y2 = min(y + dash, r.bottom)
        pygame.draw.line(surf, color, (r.left, y), (r.left, y2), width)
        pygame.draw.line(surf, color, (r.right - 1, y), (r.right - 1, y2), width)
        y += dash + gap


def scrollbar(surf, area, content_h, scroll):
    """Thin amber thumb in the 4px margin right of a scrolling list (visual only)."""
    if content_h <= area.h:
        return
    track = pygame.Rect(area.right, area.y + 4, 4, area.h - 8)
    pygame.draw.rect(surf, (30, 28, 36), track, border_radius=2)
    th = max(24, int(track.h * area.h / content_h))
    ty = track.y + int((track.h - th) * (scroll / max(1, content_h - area.h)))
    pygame.draw.rect(surf, AMBER_DEEP, (track.x, ty, track.w, th), border_radius=2)


def draw_star(surf, cx, cy, r, color, outline=None):
    pts = []
    for i in range(10):
        ang = -math.pi / 2 + i * math.pi / 5
        rad = r if i % 2 == 0 else r * 0.46
        pts.append((cx + math.cos(ang) * rad, cy + math.sin(ang) * rad))
    pygame.draw.polygon(surf, color, pts)
    if outline:
        pygame.draw.polygon(surf, outline, pts, 1)


def star_row(surf, n, cx, cy, r, color):
    gap = r * 0.55
    total = n * 2 * r + (n - 1) * gap
    x = cx - total / 2 + r
    for _ in range(n):
        draw_star(surf, x, cy, r, color, shade(color, 0.45))
        x += 2 * r + gap


def draw_coin(surf, cx, cy, r):
    pygame.draw.circle(surf, (255, 205, 70), (cx, cy), r)
    pygame.draw.circle(surf, (176, 122, 18), (cx, cy), r, 2)
    pygame.draw.circle(surf, (255, 238, 160), (cx, cy), max(2, r // 2), 1)


def draw_gem(surf, cx, cy, r):
    pts = [(cx, cy - r), (cx + r, cy - r * 0.2), (cx + r * 0.6, cy + r), (cx - r * 0.6, cy + r), (cx - r, cy - r * 0.2)]
    pygame.draw.polygon(surf, GEM_C, pts)
    pygame.draw.polygon(surf, (228, 248, 255), [(cx, cy - r), (cx + r, cy - r * 0.2), (cx, cy - r * 0.2)])
    pygame.draw.polygon(surf, (36, 112, 168), pts, 2)


def draw_exp_icon(surf, cx, cy, r):
    pts = [(cx, cy - r), (cx + r * 0.3, cy - r * 0.3), (cx + r, cy), (cx + r * 0.3, cy + r * 0.3),
           (cx, cy + r), (cx - r * 0.3, cy + r * 0.3), (cx - r, cy), (cx - r * 0.3, cy - r * 0.3)]
    pygame.draw.polygon(surf, EXP_C, pts)
    pygame.draw.polygon(surf, (50, 140, 80), pts, 1)


def draw_seal(surf, cx, cy, r, t, color=AMBER, accent=CHAKRA):
    """Slowly turning summoning circle (empty state of the Summon Portal)."""
    cx, cy = int(cx), int(cy)
    dim = shade(color, 0.5)
    surf.blit(radial_glow(r, accent, 38), (cx - r, cy - r))
    pygame.draw.circle(surf, dim, (cx, cy), r, 2)
    pygame.draw.circle(surf, dim, (cx, cy), int(r * 0.80), 1)
    pygame.draw.circle(surf, color, (cx, cy), int(r * 0.50), 2)
    for k in range(24):
        a = t * 0.3 + k * math.tau / 24
        major = k % 3 == 0
        r0, r1 = r * 0.80, r * (0.97 if major else 0.90)
        pygame.draw.line(surf, color if major else dim,
                         (cx + math.cos(a) * r0, cy + math.sin(a) * r0),
                         (cx + math.cos(a) * r1, cy + math.sin(a) * r1), 2 if major else 1)
    for sq, spin in ((0, 0.22), (1, -0.22)):
        a0 = t * spin + sq * math.pi / 4
        pts = [(cx + math.cos(a0 + k * math.pi / 2) * r * 0.66, cy + math.sin(a0 + k * math.pi / 2) * r * 0.66)
               for k in range(4)]
        pygame.draw.polygon(surf, accent if sq else color, pts, 1)
    pygame.draw.circle(surf, accent, (cx, cy), max(3, int(r * 0.07)))


_backdrop = None


def backdrop():
    """Full-screen page background: charcoal gradient, faint diagonal scroll texture, ember + chakra glows."""
    global _backdrop
    if _backdrop is None:
        surf = pygame.Surface((W, H))
        for y in range(H):
            pygame.draw.line(surf, mix(BG_TOP, BG, y / (H - 1)), (0, y), (W - 1, y))
        hatch = pygame.Surface((W, H), pygame.SRCALPHA)
        for x in range(-H, W, 34):
            pygame.draw.line(hatch, (255, 170, 90, 8), (x, H), (x + H, 0))
        surf.blit(hatch, (0, 0))
        surf.blit(radial_glow(380, AMBER_DEEP, 30), (-130, H - 250))
        surf.blit(radial_glow(320, CHAKRA, 16), (W - 230, -140))
        _backdrop = surf
    return _backdrop


# ---------------------------------------------------------------------------------------------
# Hero / enemy rendering with fallback shapes
# ---------------------------------------------------------------------------------------------
def _draw_aura(surf, col, cx, cy, s, t):
    size = int(s * 3)
    aura = pygame.Surface((size, size), pygame.SRCALPHA)
    c = size // 2
    pulse = 1 + 0.06 * math.sin(t * 4)
    for i, a in enumerate((35, 55, 85)):
        pygame.draw.circle(aura, (*col, a), (c, c), int(s * (1.4 - 0.25 * i) * pulse))
    surf.blit(aura, (cx - c, cy - c))


def _draw_stars(surf, tpl, cx, cy, s, evo_stage=0):
    if s >= 36:
        rarity = ((tpl.evo2_rarity or tpl.evo_rarity) if evo_stage == 2
                  else (tpl.evo_rarity if evo_stage == 1 else tpl.rarity))
        k = RARITIES.index(rarity) + 1
        star_row(surf, k, cx, cy - s * 1.0, max(3, int(s * 0.085)), shade(RARITY_COLOR[rarity], 1.12))


def _stone_tint_surface(img):
    """Creates a petrified stone-gray version of a sprite surface."""
    try:
        gray = pygame.transform.grayscale(img)
    except (AttributeError, pygame.error, ValueError):
        gray = img.copy()
    tinted = gray.copy()
    tinted.fill((175, 175, 185, 255), special_flags=pygame.BLEND_RGBA_MULT)
    return tinted


def draw_hero(surf, tpl, evo_stage, cx, cy, s, t=0.0, stunned=False, stars=True, aura=True):
    # 1.4x keeps the sprite inside the Roster/Team card frames
    cx, cy = int(cx), int(cy)
    anim_t = 0.0 if stunned else t
    img = assets.get_character_image(tpl.name, evo_stage, int(s * 1.4), time_sec=anim_t)
    col = (tpl.evo2_color or tpl.evo_color) if evo_stage == 2 else (tpl.evo_color if evo_stage == 1 else tpl.color)
    if stunned:
        col = (150, 150, 160)

    if img is not None:
        # Safety net: a sprite wider than the portrait box (e.g. a badly sliced sheet) is shrunk to fit
        # instead of spilling outside the card / circle.
        max_w = int(s * 1.8)
        if img.get_width() > max_w:
            nh = max(1, int(img.get_height() * max_w / img.get_width()))
            img = pygame.transform.smoothscale(img, (max_w, nh))
        if evo_stage > 0 and not stunned and aura:
            _draw_aura(surf, col, cx, cy, s, t)
        if stunned:
            stone_img = _stone_tint_surface(img)
            surf.blit(stone_img, stone_img.get_rect(center=(int(cx), int(cy))))
        else:
            surf.blit(img, img.get_rect(center=(int(cx), int(cy))))
        if stars:
            _draw_stars(surf, tpl, cx, cy, s, evo_stage)
    else:
        # Fallback rendering when the hero has no PNG file
        _draw_hero_shapes(surf, tpl, evo_stage, cx, cy, s, anim_t, stunned=stunned, stars=stars, aura=aura)


def _draw_hero_shapes(surf, tpl, evo_stage, cx, cy, s, t=0.0, stunned=False, stars=True, aura=True):
    cx, cy = int(cx), int(cy)
    col = (tpl.evo2_color or tpl.evo_color) if evo_stage == 2 else (tpl.evo_color if evo_stage == 1 else tpl.color)
    if stunned:
        col = (145, 145, 155)
    dark, light = shade(col, 0.55), shade(col, 1.3)
    if evo_stage > 0 and not stunned:
        if aura:
            _draw_aura(surf, col, cx, cy, s, t)
        rarity = (tpl.evo2_rarity or tpl.evo_rarity) if evo_stage == 2 else tpl.evo_rarity
        n = {"Common": 2, "Rare": 3, "Epic": 5, "Legendary": 9}.get(rarity, 3)
        bx, by = cx - s * 0.2, cy + s * 0.2
        for k in range(n):
            ang = math.pi + (k - (n - 1) / 2) * (1.9 / n) + math.sin(t * 3 + k) * 0.08
            ex, ey = bx + math.cos(ang) * s * 1.0, by + math.sin(ang) * s * 0.9
            pygame.draw.line(surf, col, (bx, by), (ex, ey), max(2, int(s * 0.13)))
            pygame.draw.circle(surf, light, (int(ex), int(ey)), max(2, int(s * 0.08)))

    pygame.draw.rect(surf, dark, (cx - s * 0.25, cy + s * 0.4, s * 0.18, s * 0.3), border_radius=3)
    pygame.draw.rect(surf, dark, (cx + s * 0.07, cy + s * 0.4, s * 0.18, s * 0.3), border_radius=3)
    pygame.draw.rect(surf, col, (cx - s * 0.32, cy - s * 0.1, s * 0.64, s * 0.55), border_radius=int(s * 0.15))
    pygame.draw.rect(surf, light, (cx - s * 0.32, cy + s * 0.18, s * 0.64, s * 0.08))
    pygame.draw.circle(surf, dark, (cx, int(cy - s * 0.32)), int(s * 0.31))
    skin = (175, 175, 185) if stunned else (240, 208, 175)
    pygame.draw.circle(surf, skin, (cx, int(cy - s * 0.25)), int(s * 0.25))

    eye = (110, 110, 120) if stunned else ((255, 40, 40) if evo_stage > 0 else (30, 30, 40))
    for ex in (-0.09, 0.09):
        pygame.draw.circle(surf, eye, (int(cx + s * ex), int(cy - s * 0.27)), max(2, int(s * 0.05)))
    if evo_stage > 0:
        for sx in (-1, 1):
            pygame.draw.polygon(surf, light, [(cx + sx * s * 0.12, cy - s * 0.52),
                                              (cx + sx * s * 0.30, cy - s * 0.85),
                                              (cx + sx * s * 0.28, cy - s * 0.48)])
    if stars:
        _draw_stars(surf, tpl, cx, cy, s, evo_stage)


HEAL_COLOR = (120, 255, 170)


def draw_punch(surf, cx, cy, frame_idx, size=80):
    """Sakura's punch impact (3-frame sheet). Falls back to a pink fist burst if the PNG is missing."""
    cx, cy = int(cx), int(cy)
    img = assets.get_sakura_punch_frame(frame_idx, size)
    if img is not None:
        surf.blit(img, img.get_rect(center=(cx, cy)))
        return
    r = int(size * (0.22 + 0.10 * frame_idx))
    pygame.draw.circle(surf, (255, 200, 225), (cx, cy), r)
    pygame.draw.circle(surf, (230, 100, 150), (cx, cy), r, 3)
    for k in range(8):
        ang = k * math.tau / 8 + frame_idx * 0.3
        pygame.draw.line(surf, (255, 255, 255),
                         (cx + int(math.cos(ang) * r * 1.1), cy + int(math.sin(ang) * r * 1.1)),
                         (cx + int(math.cos(ang) * r * 1.8), cy + int(math.sin(ang) * r * 1.8)), 3)


def draw_heal_pulse(surf, cx, cy, f, size=60):
    """Healing pulse over one ally. f = remaining life fraction (1 -> 0)."""
    f = max(0.0, min(1.0, f))
    prog = 1.0 - f
    cx, cy = int(cx), int(cy)
    rad = max(4, int(size * (0.5 + 1.1 * prog)))
    box = rad * 2 + 24
    pulse = pygame.Surface((box, box), pygame.SRCALPHA)
    c = box // 2
    pygame.draw.circle(pulse, (*HEAL_COLOR, int(70 * f)), (c, c), rad)
    pygame.draw.circle(pulse, (*HEAL_COLOR, int(220 * f)), (c, c), rad, 3)
    surf.blit(pulse, (cx - c, cy - c))
    # rising "+" crosses
    for k in range(4):
        px = cx + int((k - 1.5) * size * 0.28)
        py = cy + int(size * 0.3 - prog * size * (0.9 + 0.12 * k))
        a = int(255 * f)
        arm = max(3, int(size * 0.1))
        cross = pygame.Surface((arm * 2 + 4, arm * 2 + 4), pygame.SRCALPHA)
        m = arm + 2
        pygame.draw.line(cross, (*HEAL_COLOR, a), (m - arm, m), (m + arm, m), 3)
        pygame.draw.line(cross, (*HEAL_COLOR, a), (m, m - arm), (m, m + arm), 3)
        surf.blit(cross, (px - m, py - m))


def draw_sand_shield(surf, cx, cy, s, t=0.0):
    """Draws the 5-frame Sand Shield animation around the Boss, or a sand-sphere fallback."""
    sh_img = assets.get_enemy_skill_sheet_frame("gaara_shied.png", num_frames=5, time_sec=t, size=int(s * 2.1))
    if sh_img is not None:
        surf.blit(sh_img, sh_img.get_rect(center=(int(cx), int(cy))))
        return

    # Fallback: protective swirling sand sphere aura
    rad = int(s * 1.15 * (1 + 0.05 * math.sin(t * 6)))
    size = rad * 2 + 12
    sphere = pygame.Surface((size, size), pygame.SRCALPHA)
    c = size // 2
    pygame.draw.circle(sphere, (215, 175, 85, 70), (c, c), rad)
    pygame.draw.circle(sphere, (240, 205, 110, 150), (c, c), rad, 4)
    pygame.draw.circle(sphere, (185, 140, 60, 120), (c, c), int(rad * 0.82), 2)
    for k in range(6):
        ang = t * 5 + k * (math.tau / 6)
        px = c + int(math.cos(ang) * rad * 0.9)
        py = c + int(math.sin(ang) * rad * 0.65)
        pygame.draw.circle(sphere, (245, 215, 130, 200), (px, py), 5)
    surf.blit(sphere, (int(cx) - c, int(cy) - c))


def _blit_oriented(surf, img, x, y, tx, ty):
    """Blit a right-facing projectile sprite at (x, y), turned to point at (tx, ty) (never upside-down)."""
    dx, dy = tx - x, ty - y
    if dx < 0:
        img = pygame.transform.flip(img, True, False)
        ang = math.degrees(math.atan2(dy, -dx))
    else:
        ang = math.degrees(math.atan2(-dy, dx))
    img = pygame.transform.rotate(img, ang)
    surf.blit(img, img.get_rect(center=(int(x), int(y))))


def _magma_ball(surf, cx, cy, tx, ty, r, t):
    """Fallback molten projectile: glowing core with a fading trail."""
    ang = math.atan2(ty - cy, tx - cx)
    glow = pygame.Surface((r * 5, r * 5), pygame.SRCALPHA)
    gc = r * 5 // 2
    pygame.draw.circle(glow, (*MAGMA_COLOR, 60), (gc, gc), int(r * 2.2))
    surf.blit(glow, (int(cx) - gc, int(cy) - gc))
    for k in range(1, 5):
        pygame.draw.circle(surf, shade(MAGMA_COLOR, 1.0 - 0.17 * k),
                           (int(cx - math.cos(ang) * k * r * 0.9), int(cy - math.sin(ang) * k * r * 0.9)),
                           max(2, int(r * (1 - 0.17 * k))))
    pygame.draw.circle(surf, MAGMA_COLOR, (int(cx), int(cy)), r)
    pygame.draw.circle(surf, (255, 225, 130), (int(cx), int(cy)), max(2, int(r * (0.5 + 0.08 * math.sin(t * 20)))))
    pygame.draw.circle(surf, (140, 40, 20), (int(cx), int(cy)), r, 2)


def draw_magma_shot(surf, cx, cy, tx, ty, size=46, t=0.0):
    """Roushi's basic attack projectile (assets/attacks/magma_shot.png), shapes if the PNG is missing."""
    img = assets.get_magma_shot_frame(time_sec=t, size=size)
    if img is not None:
        _blit_oriented(surf, img, cx, cy, tx, ty)
    else:
        _magma_ball(surf, cx, cy, tx, ty, max(5, int(size * 0.3)), t)


def draw_super_magma_shot(surf, cx, cy, tx, ty, size=96, t=0.0):
    """Roushi's skill projectile (assets/attacks/super_magma_shot.png), shapes if the PNG is missing."""
    img = assets.get_super_magma_shot_frame(time_sec=t, size=size)
    if img is not None:
        _blit_oriented(surf, img, cx, cy, tx, ty)
    else:
        _magma_ball(surf, cx, cy, tx, ty, max(10, int(size * 0.3)), t)


def draw_roushi_cast(surf, cx, cy, progress, size=150):
    """Roushi's casting animation (assets/enemy_skills/roushi_skill.png), progress 0 -> 1."""
    img = assets.get_roushi_skill_frame(progress=progress, size=size)
    if img is not None:
        surf.blit(img, img.get_rect(center=(int(cx), int(cy))))
        return
    cx, cy = int(cx), int(cy)
    rad = max(6, int(size * (0.25 + 0.35 * progress)))
    pygame.draw.circle(surf, MAGMA_COLOR, (cx, cy), rad, max(2, int(8 * (1 - progress))))
    pygame.draw.circle(surf, (255, 220, 120), (cx, cy), max(3, rad // 2), 2)
    for k in range(8):
        ang = k * math.tau / 8 + progress * 3
        pygame.draw.circle(surf, MAGMA_COLOR, (int(cx + math.cos(ang) * rad * 1.15),
                                               int(cy + math.sin(ang) * rad * 1.15 - progress * 20)), 5)


def _steam_ball(surf, cx, cy, tx, ty, r, t):
    """Fallback steam-cannon projectile: puffy white-blue cloud with a trailing vapour wake."""
    ang = math.atan2(ty - cy, tx - cx)
    glow = pygame.Surface((r * 5, r * 5), pygame.SRCALPHA)
    gc = r * 5 // 2
    pygame.draw.circle(glow, (*HAN_STEAM_COLOR, 55), (gc, gc), int(r * 2.2))
    surf.blit(glow, (int(cx) - gc, int(cy) - gc))
    for k in range(1, 5):
        puff = pygame.Surface((r * 3, r * 3), pygame.SRCALPHA)
        pygame.draw.circle(puff, (*HAN_STEAM_COLOR, max(20, 150 - 32 * k)), (r * 3 // 2, r * 3 // 2),
                           max(3, int(r * (1 - 0.15 * k))))
        surf.blit(puff, (int(cx - math.cos(ang) * k * r * 1.0) - r * 3 // 2,
                         int(cy - math.sin(ang) * k * r * 1.0) - r * 3 // 2))
    pygame.draw.circle(surf, HAN_STEAM_COLOR, (int(cx), int(cy)), r)
    pygame.draw.circle(surf, (245, 250, 255), (int(cx), int(cy)), max(2, int(r * (0.55 + 0.08 * math.sin(t * 20)))))
    pygame.draw.circle(surf, HAN_DEF_COLOR, (int(cx), int(cy)), r, 2)


def draw_han_steam_shot(surf, cx, cy, tx, ty, size=64, t=0.0):
    """Han's Steam Cannon projectile (assets/attacks/bullet_han.png), shapes if the PNG is missing."""
    img = assets.get_han_bullet_frame(time_sec=t, size=size)
    if img is not None:
        _blit_oriented(surf, img, cx, cy, tx, ty)
    else:
        _steam_ball(surf, cx, cy, tx, ty, max(8, int(size * 0.3)), t)


def draw_han_cast(surf, cx, cy, progress, size=150):
    """Han's casting animation (assets/enemy_skills/han_skill_animation.png), progress 0 -> 1."""
    img = assets.get_han_skill_frame(progress=progress, size=size)
    if img is not None:
        surf.blit(img, img.get_rect(center=(int(cx), int(cy))))
        return
    cx, cy = int(cx), int(cy)
    rad = max(6, int(size * (0.25 + 0.35 * progress)))
    pygame.draw.circle(surf, HAN_STEAM_COLOR, (cx, cy), rad, max(2, int(8 * (1 - progress))))
    pygame.draw.circle(surf, (245, 250, 255), (cx, cy), max(3, rad // 2), 2)
    for k in range(8):
        ang = k * math.tau / 8 + progress * 3
        pygame.draw.circle(surf, HAN_STEAM_COLOR, (int(cx + math.cos(ang) * rad * 1.15),
                                                   int(cy + math.sin(ang) * rad * 1.15 - progress * 24)), 5)


def draw_burn_status(surf, cx, cy, t, s=50):
    """Flickering flames over a burning unit (Roushi's burn)."""
    cx, cy = int(cx), int(cy)
    for k in (-1, 0, 1):
        bx = cx + k * s * 0.3
        h = s * (0.42 + 0.14 * math.sin(t * 9 + k * 2.1))
        base = cy + s * 0.3
        pygame.draw.polygon(surf, BURN_COLOR, [(bx - s * 0.13, base), (bx + s * 0.13, base), (bx, base - h)])
        pygame.draw.polygon(surf, (255, 225, 120), [(bx - s * 0.06, base), (bx + s * 0.06, base),
                                                    (bx, base - h * 0.6)])


# --- Nine-Tails Chakra Naruto (Naruto Evolution Tier 2) -------------------------------------
NARUTO_ATTACK_BODY_SIZE = 104    # px height of naruto_attack.png when it replaces Naruto while he dashes


def draw_kurama_aura(surf, cx, cy, s, t=0.0, strength=1.0):
    """Soft, translucent Kurama chakra cloak (assets/skills/aura_kurama.png) wrapped around one ally.
    `s` = the unit's hero size (56 in battle), `strength` 0..1 fades it in/out. Falls back to a faint
    orange glow when the PNG is missing."""
    strength = max(0.0, min(1.0, strength))
    if strength <= 0:
        return
    cx, cy = int(cx), int(cy)
    img = assets.get_kurama_aura_frame(time_sec=t, size=int(s * 2.5), alpha=int(KURAMA_AURA_ALPHA * strength))
    if img is not None:
        surf.blit(img, img.get_rect(center=(cx, cy)))
        return
    pulse = 1 + 0.07 * math.sin(t * 5)
    size = int(s * 3.4)
    glow = pygame.Surface((size, size), pygame.SRCALPHA)
    c = size // 2
    for rad, a in ((1.15, 22), (0.95, 34), (0.72, 48)):
        pygame.draw.circle(glow, (*KURAMA_COLOR, int(a * strength * 1.6)), (c, c), int(s * rad * pulse))
    surf.blit(glow, (cx - c, cy - c))


def draw_kurama_cast(surf, cx, cy, progress, size=150):
    """Casting animation (assets/skills/naruto_kurama_model_animation.png), progress 0 -> 1."""
    cx, cy = int(cx), int(cy)
    img = assets.get_kurama_cast_frame(progress=progress, size=size)
    if img is not None:
        surf.blit(img, img.get_rect(center=(cx, cy)))
        return
    rad = max(6, int(size * (0.25 + 0.30 * progress)))
    pygame.draw.circle(surf, KURAMA_COLOR, (cx, cy), rad, max(2, int(8 * (1 - progress))))
    pygame.draw.circle(surf, (255, 225, 140), (cx, cy), max(3, rad // 2), 2)
    for k in range(8):
        ang = k * math.tau / 8 + progress * 4
        pygame.draw.circle(surf, KURAMA_COLOR, (int(cx + math.cos(ang) * rad * 1.2),
                                                int(cy + math.sin(ang) * rad * 1.2)), 5)


def draw_naruto_rasengan(surf, cx, cy, tx, ty, size=90, t=0.0):
    """Rasengan ball (assets/attacks/skill_naruto_rasengan.png); a swirling blue-white ball if missing."""
    img = assets.get_naruto_rasengan_frame(time_sec=t, size=size)
    if img is not None:
        _blit_oriented(surf, img, cx, cy, tx, ty)
        return
    cx, cy = int(cx), int(cy)
    r = max(10, int(size * 0.3))
    glow = pygame.Surface((r * 5, r * 5), pygame.SRCALPHA)
    gc = r * 5 // 2
    pygame.draw.circle(glow, (120, 200, 255, 70), (gc, gc), int(r * 2.1))
    surf.blit(glow, (cx - gc, cy - gc))
    pygame.draw.circle(surf, (110, 190, 255), (cx, cy), r)
    pygame.draw.circle(surf, (235, 250, 255), (cx, cy), max(3, int(r * 0.55)))
    for k in range(3):
        ang = t * 14 + k * math.tau / 3
        pygame.draw.line(surf, (255, 255, 255), (cx, cy),
                         (int(cx + math.cos(ang) * r), int(cy + math.sin(ang) * r)), 2)
    pygame.draw.circle(surf, KURAMA_COLOR, (cx, cy), r, 2)


def draw_naruto_attack(surf, cx, cy, progress, size=NARUTO_ATTACK_BODY_SIZE):
    """One frame of assets/attacks/naruto_attack.png (progress 0 -> 1 across the dash/punch/return).
    Returns True when the sheet exists and was drawn, False so the caller can draw its normal sprite."""
    img = assets.get_naruto_attack_frame(progress=progress, size=size)
    if img is None:
        return False
    surf.blit(img, img.get_rect(center=(int(cx), int(cy))))
    return True


def draw_enemy(surf, name, color, cx, cy, s, boss, t=0.0, world_boss=False, shield_timer=0.0, is_miniboss=False):
    """Renders world bosses, mini-bosses (including White Zetsu clones), and normal enemies
    that have a sprite in assets/enemies/ (e.g. Rogue Ninja). Falls back safely to shapes
    only when the PNG file is missing."""
    mini = None if world_boss else miniboss_for_name(name)
    is_mb = bool(is_miniboss or mini is not None)
    frames = mini.get("frames") if mini else None
    flip = mini.get("flip", False) if mini else False
    target_name = mini["sprite"] if (mini and mini.get("sprite")) else name

    img = assets.get_enemy_image(
        target_name,
        size=int(s * 1.8),
        time_sec=t,
        is_boss=bool(boss or world_boss),
        is_miniboss=is_mb,
        frames=frames,
        flip=flip,
    )

    if img is not None:
        if name == "Nii Yugito":
            aura_rad = int(s * 0.95 + math.sin(t * 6) * 4)
            aura = pygame.Surface((aura_rad * 2 + 10, aura_rad * 2 + 10), pygame.SRCALPHA)
            pygame.draw.circle(aura, (60, 140, 255, 50), (aura_rad + 5, aura_rad + 5), aura_rad)
            surf.blit(aura, (int(cx) - aura_rad - 5, int(cy) - aura_rad - 5))
        elif name == "Yagura Karatachi":
            aura_rad = int(s * 0.95 + math.sin(t * 6) * 4)
            aura = pygame.Surface((aura_rad * 2 + 10, aura_rad * 2 + 10), pygame.SRCALPHA)
            pygame.draw.circle(aura, (80, 190, 150, 50), (aura_rad + 5, aura_rad + 5), aura_rad)
            surf.blit(aura, (int(cx) - aura_rad - 5, int(cy) - aura_rad - 5))
        elif name == "Han":
            aura_rad = int(s * 1.0 + math.sin(t * 4) * 5)
            aura = pygame.Surface((aura_rad * 2 + 10, aura_rad * 2 + 10), pygame.SRCALPHA)
            pygame.draw.circle(aura, (*HAN_DEF_COLOR, 50), (aura_rad + 5, aura_rad + 5), aura_rad)
            pygame.draw.circle(aura, (*HAN_STEAM_COLOR, 35), (aura_rad + 5, aura_rad + 5), int(aura_rad * 0.7))
            surf.blit(aura, (int(cx) - aura_rad - 5, int(cy) - aura_rad - 5))
        elif name == "Roushi":
            aura_rad = int(s * 1.0 + math.sin(t * 5) * 5)
            aura = pygame.Surface((aura_rad * 2 + 10, aura_rad * 2 + 10), pygame.SRCALPHA)
            pygame.draw.circle(aura, (*MAGMA_COLOR, 55), (aura_rad + 5, aura_rad + 5), aura_rad)
            pygame.draw.circle(aura, (*MAGMA_COLOR, 35), (aura_rad + 5, aura_rad + 5), int(aura_rad * 0.7))
            surf.blit(aura, (int(cx) - aura_rad - 5, int(cy) - aura_rad - 5))
        surf.blit(img, img.get_rect(center=(int(cx), int(cy))))
        if world_boss or boss:
            pygame.draw.polygon(surf, GOLD_C, [(cx - s * 0.2, cy - s * 0.7), (cx - s * 0.1, cy - s * 0.9),
                                               (cx, cy - s * 0.75), (cx + s * 0.1, cy - s * 0.9),
                                               (cx + s * 0.2, cy - s * 0.7)])
    else:
        _draw_enemy_shapes(surf, color, cx, cy, s, boss, t)

    if shield_timer > 0:
        draw_sand_shield(surf, cx, cy, s, t)


def _draw_enemy_shapes(surf, color, cx, cy, s, boss, t=0.0):
    sq = 1 + 0.05 * math.sin(t * 5)
    body = pygame.Rect(0, 0, int(s * 1.3), int(s * 1.0 * sq))
    body.center = (cx, cy)
    pygame.draw.ellipse(surf, color, body)
    pygame.draw.ellipse(surf, shade(color, 1.3), body.inflate(-int(s * 0.5), -int(s * 0.55)).move(0, -int(s * 0.12)))
    for ex in (-0.22, 0.22):
        pygame.draw.circle(surf, (255, 255, 255), (int(cx + s * ex), int(cy - s * 0.06)), int(s * 0.12))
        pygame.draw.circle(surf, (200, 20, 20), (int(cx + s * ex), int(cy - s * 0.06)), int(s * 0.06))
    if boss:
        pygame.draw.polygon(surf, GOLD_C, [(cx - s * 0.3, cy - s * 0.48), (cx - s * 0.2, cy - s * 0.8),
                                           (cx, cy - s * 0.55), (cx + s * 0.2, cy - s * 0.8),
                                           (cx + s * 0.3, cy - s * 0.48)])