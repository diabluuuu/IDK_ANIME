"""drawing.py - font cache, text/panel helpers and hero/enemy rendering with fallback shapes."""
import math

import pygame

from config import *
from asset_manager import AssetManager

assets = AssetManager()


def shade(c, f):
    return tuple(max(0, min(255, int(v * f))) for v in c)


_fonts = {}


def font(size, bold=False):
    key = (size, bold)
    if key not in _fonts:
        _fonts[key] = pygame.font.SysFont("arial,dejavusans,freesans", size, bold=bold)
    return _fonts[key]


def txt(surf, s, size, color, pos, anchor="topleft", bold=False):
    img = font(size, bold).render(str(s), True, color)
    r = img.get_rect(**{anchor: pos})
    surf.blit(img, r)
    return r


def panel(surf, rect, fill=PANEL, border=PANEL_BORDER, radius=10, width=2):
    pygame.draw.rect(surf, fill, rect, border_radius=radius)
    pygame.draw.rect(surf, border, rect, width, border_radius=radius)


def overlay(surf, rect, rgba, radius=0):
    s = pygame.Surface((rect.w, rect.h), pygame.SRCALPHA)
    pygame.draw.rect(s, rgba, s.get_rect(), border_radius=radius)
    surf.blit(s, rect.topleft)


def hp_bar(surf, x, y, w, h, frac, color=(80, 220, 110)):
    pygame.draw.rect(surf, (20, 20, 28), (x, y, w, h), border_radius=3)
    if frac > 0:
        pygame.draw.rect(surf, color, (x, y, max(2, int(w * frac)), h), border_radius=3)
    pygame.draw.rect(surf, (95, 95, 120), (x, y, w, h), 1, border_radius=3)


def _draw_aura(surf, col, cx, cy, s, t):
    size = int(s * 3)
    aura = pygame.Surface((size, size), pygame.SRCALPHA)
    c = size // 2
    pulse = 1 + 0.06 * math.sin(t * 4)
    for i, a in enumerate((35, 55, 85)):
        pygame.draw.circle(aura, (*col, a), (c, c), int(s * (1.4 - 0.25 * i) * pulse))
    surf.blit(aura, (cx - c, cy - c))


def _draw_stars(surf, tpl, cx, cy, s, evo_stage=0):
    if s >= 36:
        rarity = ((tpl.evo2_rarity or tpl.evo_rarity) if evo_stage == 2
                  else (tpl.evo_rarity if evo_stage == 1 else tpl.rarity))
        k = RARITIES.index(rarity) + 1
        for i in range(k):
            pygame.draw.circle(surf, RARITY_COLOR[rarity],
                               (int(cx + (i - (k - 1) / 2) * s * 0.22), int(cy - s * 1.0)), max(2, int(s * 0.07)))


def _stone_tint_surface(img):
    """Creates a petrified stone-gray version of a sprite surface."""
    try:
        gray = pygame.transform.grayscale(img)
    except (AttributeError, pygame.error, ValueError):
        gray = img.copy()
    tinted = gray.copy()
    tinted.fill((175, 175, 185, 255), special_flags=pygame.BLEND_RGBA_MULT)
    return tinted


def draw_hero(surf, tpl, evo_stage, cx, cy, s, t=0.0, stunned=False):
    # 1.4x keeps the sprite inside the Roster/Team card frames
    cx, cy = int(cx), int(cy)
    anim_t = 0.0 if stunned else t
    img = assets.get_character_image(tpl.name, evo_stage, int(s * 1.4), time_sec=anim_t)
    col = (tpl.evo2_color or tpl.evo_color) if evo_stage == 2 else (tpl.evo_color if evo_stage == 1 else tpl.color)
    if stunned:
        col = (150, 150, 160)

    if img is not None:
        # Safety net: a sprite wider than the portrait box (e.g. a badly sliced sheet) is shrunk to fit
        # instead of spilling outside the card / circle.
        max_w = int(s * 1.8)
        if img.get_width() > max_w:
            nh = max(1, int(img.get_height() * max_w / img.get_width()))
            img = pygame.transform.smoothscale(img, (max_w, nh))
        if evo_stage > 0 and not stunned:
            _draw_aura(surf, col, cx, cy, s, t)
        if stunned:
            stone_img = _stone_tint_surface(img)
            surf.blit(stone_img, stone_img.get_rect(center=(int(cx), int(cy))))
        else:
            surf.blit(img, img.get_rect(center=(int(cx), int(cy))))
        _draw_stars(surf, tpl, cx, cy, s, evo_stage)
    else:
        # Fallback rendering when the hero has no PNG file
        _draw_hero_shapes(surf, tpl, evo_stage, cx, cy, s, anim_t, stunned=stunned)


def _draw_hero_shapes(surf, tpl, evo_stage, cx, cy, s, t=0.0, stunned=False):
    cx, cy = int(cx), int(cy)
    col = (tpl.evo2_color or tpl.evo_color) if evo_stage == 2 else (tpl.evo_color if evo_stage == 1 else tpl.color)
    if stunned:
        col = (145, 145, 155)
    dark, light = shade(col, 0.55), shade(col, 1.3)
    if evo_stage > 0 and not stunned:
        _draw_aura(surf, col, cx, cy, s, t)
        rarity = (tpl.evo2_rarity or tpl.evo_rarity) if evo_stage == 2 else tpl.evo_rarity
        n = {"Common": 2, "Rare": 3, "Epic": 5, "Legendary": 9}.get(rarity, 3)
        bx, by = cx - s * 0.2, cy + s * 0.2
        for k in range(n):
            ang = math.pi + (k - (n - 1) / 2) * (1.9 / n) + math.sin(t * 3 + k) * 0.08
            ex, ey = bx + math.cos(ang) * s * 1.0, by + math.sin(ang) * s * 0.9
            pygame.draw.line(surf, col, (bx, by), (ex, ey), max(2, int(s * 0.13)))
            pygame.draw.circle(surf, light, (int(ex), int(ey)), max(2, int(s * 0.08)))

    pygame.draw.rect(surf, dark, (cx - s * 0.25, cy + s * 0.4, s * 0.18, s * 0.3), border_radius=3)
    pygame.draw.rect(surf, dark, (cx + s * 0.07, cy + s * 0.4, s * 0.18, s * 0.3), border_radius=3)
    pygame.draw.rect(surf, col, (cx - s * 0.32, cy - s * 0.1, s * 0.64, s * 0.55), border_radius=int(s * 0.15))
    pygame.draw.rect(surf, light, (cx - s * 0.32, cy + s * 0.18, s * 0.64, s * 0.08))
    pygame.draw.circle(surf, dark, (cx, int(cy - s * 0.32)), int(s * 0.31))
    skin = (175, 175, 185) if stunned else (240, 208, 175)
    pygame.draw.circle(surf, skin, (cx, int(cy - s * 0.25)), int(s * 0.25))

    eye = (110, 110, 120) if stunned else ((255, 40, 40) if evo_stage > 0 else (30, 30, 40))
    for ex in (-0.09, 0.09):
        pygame.draw.circle(surf, eye, (int(cx + s * ex), int(cy - s * 0.27)), max(2, int(s * 0.05)))
    if evo_stage > 0:
        for sx in (-1, 1):
            pygame.draw.polygon(surf, light, [(cx + sx * s * 0.12, cy - s * 0.52),
                                              (cx + sx * s * 0.30, cy - s * 0.85),
                                              (cx + sx * s * 0.28, cy - s * 0.48)])
    _draw_stars(surf, tpl, cx, cy, s, evo_stage)


HEAL_COLOR = (120, 255, 170)


def draw_punch(surf, cx, cy, frame_idx, size=80):
    """Sakura's punch impact (3-frame sheet). Falls back to a pink fist burst if the PNG is missing."""
    cx, cy = int(cx), int(cy)
    img = assets.get_sakura_punch_frame(frame_idx, size)
    if img is not None:
        surf.blit(img, img.get_rect(center=(cx, cy)))
        return
    r = int(size * (0.22 + 0.10 * frame_idx))
    pygame.draw.circle(surf, (255, 200, 225), (cx, cy), r)
    pygame.draw.circle(surf, (230, 100, 150), (cx, cy), r, 3)
    for k in range(8):
        ang = k * math.tau / 8 + frame_idx * 0.3
        pygame.draw.line(surf, (255, 255, 255),
                         (cx + int(math.cos(ang) * r * 1.1), cy + int(math.sin(ang) * r * 1.1)),
                         (cx + int(math.cos(ang) * r * 1.8), cy + int(math.sin(ang) * r * 1.8)), 3)


def draw_heal_pulse(surf, cx, cy, f, size=60):
    """Healing pulse over one ally. f = remaining life fraction (1 -> 0)."""
    f = max(0.0, min(1.0, f))
    prog = 1.0 - f
    cx, cy = int(cx), int(cy)
    rad = max(4, int(size * (0.5 + 1.1 * prog)))
    box = rad * 2 + 24
    pulse = pygame.Surface((box, box), pygame.SRCALPHA)
    c = box // 2
    pygame.draw.circle(pulse, (*HEAL_COLOR, int(70 * f)), (c, c), rad)
    pygame.draw.circle(pulse, (*HEAL_COLOR, int(220 * f)), (c, c), rad, 3)
    surf.blit(pulse, (cx - c, cy - c))
    # rising "+" crosses
    for k in range(4):
        px = cx + int((k - 1.5) * size * 0.28)
        py = cy + int(size * 0.3 - prog * size * (0.9 + 0.12 * k))
        a = int(255 * f)
        arm = max(3, int(size * 0.1))
        cross = pygame.Surface((arm * 2 + 4, arm * 2 + 4), pygame.SRCALPHA)
        m = arm + 2
        pygame.draw.line(cross, (*HEAL_COLOR, a), (m - arm, m), (m + arm, m), 3)
        pygame.draw.line(cross, (*HEAL_COLOR, a), (m, m - arm), (m, m + arm), 3)
        surf.blit(cross, (px - m, py - m))


def draw_sand_shield(surf, cx, cy, s, t=0.0):
    """Draws the 5-frame Sand Shield animation around the Boss, or a sand-sphere fallback."""
    sh_img = assets.get_enemy_skill_sheet_frame("gaara_shied.png", num_frames=5, time_sec=t, size=int(s * 2.1))
    if sh_img is not None:
        surf.blit(sh_img, sh_img.get_rect(center=(int(cx), int(cy))))
        return

    # Fallback: protective swirling sand sphere aura
    rad = int(s * 1.15 * (1 + 0.05 * math.sin(t * 6)))
    size = rad * 2 + 12
    sphere = pygame.Surface((size, size), pygame.SRCALPHA)
    c = size // 2
    pygame.draw.circle(sphere, (215, 175, 85, 70), (c, c), rad)
    pygame.draw.circle(sphere, (240, 205, 110, 150), (c, c), rad, 4)
    pygame.draw.circle(sphere, (185, 140, 60, 120), (c, c), int(rad * 0.82), 2)
    for k in range(6):
        ang = t * 5 + k * (math.tau / 6)
        px = c + int(math.cos(ang) * rad * 0.9)
        py = c + int(math.sin(ang) * rad * 0.65)
        pygame.draw.circle(sphere, (245, 215, 130, 200), (px, py), 5)
    surf.blit(sphere, (int(cx) - c, int(cy) - c))


def _blit_oriented(surf, img, x, y, tx, ty):
    """Blit a right-facing projectile sprite at (x, y), turned to point at (tx, ty) (never upside-down)."""
    dx, dy = tx - x, ty - y
    if dx < 0:
        img = pygame.transform.flip(img, True, False)
        ang = math.degrees(math.atan2(dy, -dx))
    else:
        ang = math.degrees(math.atan2(-dy, dx))
    img = pygame.transform.rotate(img, ang)
    surf.blit(img, img.get_rect(center=(int(x), int(y))))


def _magma_ball(surf, cx, cy, tx, ty, r, t):
    """Fallback molten projectile: glowing core with a fading trail."""
    ang = math.atan2(ty - cy, tx - cx)
    glow = pygame.Surface((r * 5, r * 5), pygame.SRCALPHA)
    gc = r * 5 // 2
    pygame.draw.circle(glow, (*MAGMA_COLOR, 60), (gc, gc), int(r * 2.2))
    surf.blit(glow, (int(cx) - gc, int(cy) - gc))
    for k in range(1, 5):
        pygame.draw.circle(surf, shade(MAGMA_COLOR, 1.0 - 0.17 * k),
                           (int(cx - math.cos(ang) * k * r * 0.9), int(cy - math.sin(ang) * k * r * 0.9)),
                           max(2, int(r * (1 - 0.17 * k))))
    pygame.draw.circle(surf, MAGMA_COLOR, (int(cx), int(cy)), r)
    pygame.draw.circle(surf, (255, 225, 130), (int(cx), int(cy)), max(2, int(r * (0.5 + 0.08 * math.sin(t * 20)))))
    pygame.draw.circle(surf, (140, 40, 20), (int(cx), int(cy)), r, 2)


def draw_magma_shot(surf, cx, cy, tx, ty, size=46, t=0.0):
    """Roushi's basic attack projectile (assets/attacks/magma_shot.png), shapes if the PNG is missing."""
    img = assets.get_magma_shot_frame(time_sec=t, size=size)
    if img is not None:
        _blit_oriented(surf, img, cx, cy, tx, ty)
    else:
        _magma_ball(surf, cx, cy, tx, ty, max(5, int(size * 0.3)), t)


def draw_super_magma_shot(surf, cx, cy, tx, ty, size=96, t=0.0):
    """Roushi's skill projectile (assets/attacks/super_magma_shot.png), shapes if the PNG is missing."""
    img = assets.get_super_magma_shot_frame(time_sec=t, size=size)
    if img is not None:
        _blit_oriented(surf, img, cx, cy, tx, ty)
    else:
        _magma_ball(surf, cx, cy, tx, ty, max(10, int(size * 0.3)), t)


def draw_roushi_cast(surf, cx, cy, progress, size=150):
    """Roushi's casting animation (assets/enemy_skills/roushi_skill.png), progress 0 -> 1."""
    img = assets.get_roushi_skill_frame(progress=progress, size=size)
    if img is not None:
        surf.blit(img, img.get_rect(center=(int(cx), int(cy))))
        return
    cx, cy = int(cx), int(cy)
    rad = max(6, int(size * (0.25 + 0.35 * progress)))
    pygame.draw.circle(surf, MAGMA_COLOR, (cx, cy), rad, max(2, int(8 * (1 - progress))))
    pygame.draw.circle(surf, (255, 220, 120), (cx, cy), max(3, rad // 2), 2)
    for k in range(8):
        ang = k * math.tau / 8 + progress * 3
        pygame.draw.circle(surf, MAGMA_COLOR, (int(cx + math.cos(ang) * rad * 1.15),
                                               int(cy + math.sin(ang) * rad * 1.15 - progress * 20)), 5)


def _steam_ball(surf, cx, cy, tx, ty, r, t):
    """Fallback steam-cannon projectile: puffy white-blue cloud with a trailing vapour wake."""
    ang = math.atan2(ty - cy, tx - cx)
    glow = pygame.Surface((r * 5, r * 5), pygame.SRCALPHA)
    gc = r * 5 // 2
    pygame.draw.circle(glow, (*HAN_STEAM_COLOR, 55), (gc, gc), int(r * 2.2))
    surf.blit(glow, (int(cx) - gc, int(cy) - gc))
    for k in range(1, 5):
        puff = pygame.Surface((r * 3, r * 3), pygame.SRCALPHA)
        pygame.draw.circle(puff, (*HAN_STEAM_COLOR, max(20, 150 - 32 * k)), (r * 3 // 2, r * 3 // 2),
                           max(3, int(r * (1 - 0.15 * k))))
        surf.blit(puff, (int(cx - math.cos(ang) * k * r * 1.0) - r * 3 // 2,
                         int(cy - math.sin(ang) * k * r * 1.0) - r * 3 // 2))
    pygame.draw.circle(surf, HAN_STEAM_COLOR, (int(cx), int(cy)), r)
    pygame.draw.circle(surf, (245, 250, 255), (int(cx), int(cy)), max(2, int(r * (0.55 + 0.08 * math.sin(t * 20)))))
    pygame.draw.circle(surf, HAN_DEF_COLOR, (int(cx), int(cy)), r, 2)


def draw_han_steam_shot(surf, cx, cy, tx, ty, size=64, t=0.0):
    """Han's Steam Cannon projectile (assets/attacks/bullet_han.png), shapes if the PNG is missing."""
    img = assets.get_han_bullet_frame(time_sec=t, size=size)
    if img is not None:
        _blit_oriented(surf, img, cx, cy, tx, ty)
    else:
        _steam_ball(surf, cx, cy, tx, ty, max(8, int(size * 0.3)), t)


def draw_han_cast(surf, cx, cy, progress, size=150):
    """Han's casting animation (assets/enemy_skills/han_skill_animation.png), progress 0 -> 1."""
    img = assets.get_han_skill_frame(progress=progress, size=size)
    if img is not None:
        surf.blit(img, img.get_rect(center=(int(cx), int(cy))))
        return
    cx, cy = int(cx), int(cy)
    rad = max(6, int(size * (0.25 + 0.35 * progress)))
    pygame.draw.circle(surf, HAN_STEAM_COLOR, (cx, cy), rad, max(2, int(8 * (1 - progress))))
    pygame.draw.circle(surf, (245, 250, 255), (cx, cy), max(3, rad // 2), 2)
    for k in range(8):
        ang = k * math.tau / 8 + progress * 3
        pygame.draw.circle(surf, HAN_STEAM_COLOR, (int(cx + math.cos(ang) * rad * 1.15),
                                                   int(cy + math.sin(ang) * rad * 1.15 - progress * 24)), 5)


def draw_burn_status(surf, cx, cy, t, s=50):
    """Flickering flames over a burning unit (Roushi's burn)."""
    cx, cy = int(cx), int(cy)
    for k in (-1, 0, 1):
        bx = cx + k * s * 0.3
        h = s * (0.42 + 0.14 * math.sin(t * 9 + k * 2.1))
        base = cy + s * 0.3
        pygame.draw.polygon(surf, BURN_COLOR, [(bx - s * 0.13, base), (bx + s * 0.13, base), (bx, base - h)])
        pygame.draw.polygon(surf, (255, 225, 120), [(bx - s * 0.06, base), (bx + s * 0.06, base),
                                                    (bx, base - h * 0.6)])


# --- Nine-Tails Chakra Naruto (Naruto Evolution Tier 2) -------------------------------------
NARUTO_ATTACK_BODY_SIZE = 104    # px height of naruto_attack.png when it replaces Naruto while he dashes


def draw_kurama_aura(surf, cx, cy, s, t=0.0, strength=1.0):
    """Soft, translucent Kurama chakra cloak (assets/skills/aura_kurama.png) wrapped around one ally.
    `s` = the unit's hero size (56 in battle), `strength` 0..1 fades it in/out. Falls back to a faint
    orange glow when the PNG is missing."""
    strength = max(0.0, min(1.0, strength))
    if strength <= 0:
        return
    cx, cy = int(cx), int(cy)
    img = assets.get_kurama_aura_frame(time_sec=t, size=int(s * 2.5), alpha=int(KURAMA_AURA_ALPHA * strength))
    if img is not None:
        surf.blit(img, img.get_rect(center=(cx, cy)))
        return
    pulse = 1 + 0.07 * math.sin(t * 5)
    size = int(s * 3.4)
    glow = pygame.Surface((size, size), pygame.SRCALPHA)
    c = size // 2
    for rad, a in ((1.15, 22), (0.95, 34), (0.72, 48)):
        pygame.draw.circle(glow, (*KURAMA_COLOR, int(a * strength * 1.6)), (c, c), int(s * rad * pulse))
    surf.blit(glow, (cx - c, cy - c))


def draw_kurama_cast(surf, cx, cy, progress, size=150):
    """Casting animation (assets/skills/naruto_kurama_model_animation.png), progress 0 -> 1."""
    cx, cy = int(cx), int(cy)
    img = assets.get_kurama_cast_frame(progress=progress, size=size)
    if img is not None:
        surf.blit(img, img.get_rect(center=(cx, cy)))
        return
    rad = max(6, int(size * (0.25 + 0.30 * progress)))
    pygame.draw.circle(surf, KURAMA_COLOR, (cx, cy), rad, max(2, int(8 * (1 - progress))))
    pygame.draw.circle(surf, (255, 225, 140), (cx, cy), max(3, rad // 2), 2)
    for k in range(8):
        ang = k * math.tau / 8 + progress * 4
        pygame.draw.circle(surf, KURAMA_COLOR, (int(cx + math.cos(ang) * rad * 1.2),
                                                int(cy + math.sin(ang) * rad * 1.2)), 5)


def draw_naruto_rasengan(surf, cx, cy, tx, ty, size=90, t=0.0):
    """Rasengan ball (assets/attacks/skill_naruto_rasengan.png); a swirling blue-white ball if missing."""
    img = assets.get_naruto_rasengan_frame(time_sec=t, size=size)
    if img is not None:
        _blit_oriented(surf, img, cx, cy, tx, ty)
        return
    cx, cy = int(cx), int(cy)
    r = max(10, int(size * 0.3))
    glow = pygame.Surface((r * 5, r * 5), pygame.SRCALPHA)
    gc = r * 5 // 2
    pygame.draw.circle(glow, (120, 200, 255, 70), (gc, gc), int(r * 2.1))
    surf.blit(glow, (cx - gc, cy - gc))
    pygame.draw.circle(surf, (110, 190, 255), (cx, cy), r)
    pygame.draw.circle(surf, (235, 250, 255), (cx, cy), max(3, int(r * 0.55)))
    for k in range(3):
        ang = t * 14 + k * math.tau / 3
        pygame.draw.line(surf, (255, 255, 255), (cx, cy),
                         (int(cx + math.cos(ang) * r), int(cy + math.sin(ang) * r)), 2)
    pygame.draw.circle(surf, KURAMA_COLOR, (cx, cy), r, 2)


def draw_naruto_attack(surf, cx, cy, progress, size=NARUTO_ATTACK_BODY_SIZE):
    """One frame of assets/attacks/naruto_attack.png (progress 0 -> 1 across the dash/punch/return).
    Returns True when the sheet exists and was drawn, False so the caller can draw its normal sprite."""
    img = assets.get_naruto_attack_frame(progress=progress, size=size)
    if img is None:
        return False
    surf.blit(img, img.get_rect(center=(int(cx), int(cy))))
    return True


def draw_enemy(surf, name, color, cx, cy, s, boss, t=0.0, world_boss=False, shield_timer=0.0, is_miniboss=False):
    """Renders world bosses, mini-bosses (including White Zetsu clones), and normal enemies
    that have a sprite in assets/enemies/ (e.g. Rogue Ninja). Falls back safely to shapes
    only when the PNG file is missing."""
    mini = None if world_boss else miniboss_for_name(name)
    is_mb = bool(is_miniboss or mini is not None)
    frames = mini.get("frames") if mini else None
    flip = mini.get("flip", False) if mini else False
    target_name = mini["sprite"] if (mini and mini.get("sprite")) else name

    img = assets.get_enemy_image(
        target_name,
        size=int(s * 1.8),
        time_sec=t,
        is_boss=bool(boss or world_boss),
        is_miniboss=is_mb,
        frames=frames,
        flip=flip,
    )

    if img is not None:
        if name == "Nii Yugito":
            aura_rad = int(s * 0.95 + math.sin(t * 6) * 4)
            aura = pygame.Surface((aura_rad * 2 + 10, aura_rad * 2 + 10), pygame.SRCALPHA)
            pygame.draw.circle(aura, (60, 140, 255, 50), (aura_rad + 5, aura_rad + 5), aura_rad)
            surf.blit(aura, (int(cx) - aura_rad - 5, int(cy) - aura_rad - 5))
        elif name == "Yagura Karatachi":
            aura_rad = int(s * 0.95 + math.sin(t * 6) * 4)
            aura = pygame.Surface((aura_rad * 2 + 10, aura_rad * 2 + 10), pygame.SRCALPHA)
            pygame.draw.circle(aura, (80, 190, 150, 50), (aura_rad + 5, aura_rad + 5), aura_rad)
            surf.blit(aura, (int(cx) - aura_rad - 5, int(cy) - aura_rad - 5))
        elif name == "Han":
            aura_rad = int(s * 1.0 + math.sin(t * 4) * 5)
            aura = pygame.Surface((aura_rad * 2 + 10, aura_rad * 2 + 10), pygame.SRCALPHA)
            pygame.draw.circle(aura, (*HAN_DEF_COLOR, 50), (aura_rad + 5, aura_rad + 5), aura_rad)
            pygame.draw.circle(aura, (*HAN_STEAM_COLOR, 35), (aura_rad + 5, aura_rad + 5), int(aura_rad * 0.7))
            surf.blit(aura, (int(cx) - aura_rad - 5, int(cy) - aura_rad - 5))
        elif name == "Roushi":
            aura_rad = int(s * 1.0 + math.sin(t * 5) * 5)
            aura = pygame.Surface((aura_rad * 2 + 10, aura_rad * 2 + 10), pygame.SRCALPHA)
            pygame.draw.circle(aura, (*MAGMA_COLOR, 55), (aura_rad + 5, aura_rad + 5), aura_rad)
            pygame.draw.circle(aura, (*MAGMA_COLOR, 35), (aura_rad + 5, aura_rad + 5), int(aura_rad * 0.7))
            surf.blit(aura, (int(cx) - aura_rad - 5, int(cy) - aura_rad - 5))
        surf.blit(img, img.get_rect(center=(int(cx), int(cy))))
        if world_boss or boss:
            pygame.draw.polygon(surf, GOLD_C, [(cx - s * 0.2, cy - s * 0.7), (cx - s * 0.1, cy - s * 0.9),
                                               (cx, cy - s * 0.75), (cx + s * 0.1, cy - s * 0.9),
                                               (cx + s * 0.2, cy - s * 0.7)])
    else:
        _draw_enemy_shapes(surf, color, cx, cy, s, boss, t)

    if shield_timer > 0:
        draw_sand_shield(surf, cx, cy, s, t)


def _draw_enemy_shapes(surf, color, cx, cy, s, boss, t=0.0):
    sq = 1 + 0.05 * math.sin(t * 5)
    body = pygame.Rect(0, 0, int(s * 1.3), int(s * 1.0 * sq))
    body.center = (cx, cy)
    pygame.draw.ellipse(surf, color, body)
    pygame.draw.ellipse(surf, shade(color, 1.3), body.inflate(-int(s * 0.5), -int(s * 0.55)).move(0, -int(s * 0.12)))
    for ex in (-0.22, 0.22):
        pygame.draw.circle(surf, (255, 255, 255), (int(cx + s * ex), int(cy - s * 0.06)), int(s * 0.12))
        pygame.draw.circle(surf, (200, 20, 20), (int(cx + s * ex), int(cy - s * 0.06)), int(s * 0.06))
    if boss:
        pygame.draw.polygon(surf, GOLD_C, [(cx - s * 0.3, cy - s * 0.48), (cx - s * 0.2, cy - s * 0.8),
                                           (cx, cy - s * 0.55), (cx + s * 0.2, cy - s * 0.8),
                                           (cx + s * 0.3, cy - s * 0.48)])