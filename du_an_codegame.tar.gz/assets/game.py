"""game.py - Game: state, player inventory, event loop and high-level game logic."""
import sys

import pygame

from config import *
from models import Character, GachaSystem, BY_NAME, TEMPLATES
from battle import BattleManager
from ui import UIManager


SEARCH_MAX_LEN = 30

# Reward announcements, highest priority first: when a battle drops several of these at once only the
# first match gets the toast + screen flash (the result screen still lists every drop).
DROP_ANNOUNCEMENTS = (
    ("naruto_cloak", "SECRET DROP: Naruto Cloak!"),
    ("kokuo", "LEGENDARY DROP: Kokuo (Ngũ Vĩ)!"),
    ("son_goku", "CHASE DROP: Son Goku (Tứ Vĩ)!"),
    ("isobu", "CHASE DROP: Isobu (Tam Vĩ)!"),
    ("matatabi", "CHASE DROP: Matatabi (Nhị Vĩ)!"),
    ("shukaku", "CHASE DROP: Shukaku (Nhất Vĩ)!"),
    ("black_chakra", "RARE DROP: Black Chakra!"),
)


class Game:
    def __init__(self):
        pygame.init()
        pygame.display.set_caption("Eternal Summoners - Gacha Strategy RPG")
        self.screen = pygame.display.set_mode((W, H))
        self.clock = pygame.time.Clock()
        self.gold, self.gems, self.exp, self.stones = 1000, 1600, 300, 3
        self.gacha = GachaSystem()
        self.roster, self.team = [], []
        self.chakra, self.naruto_cloak, self.black_chakra = 10, 0, 0
        self.shukaku, self.matatabi, self.isobu, self.son_goku = 0, 0, 0, 0
        self.kokuo = 0
        self.selected_map = None
        # per map: highest unlocked stage (infinite) and the stage chosen to fight
        self.map_stage = {m["id"]: {"max_unlocked_stage": 1, "selected_stage": 1} for m in MAPS}
        self.battle, self.tab = None, "gacha"
        self.last_pull, self.pull_time, self.total_pulls = [], 0.0, 0
        self.toast_msg, self.toast_t = "", 0.0
        self.flash_t, self.flash_color = 0.0, (255, 255, 255)
        self.admin_prompt_open = False
        self.admin_panel_open = False
        self.admin_input_code = ""
        self.search_text, self.search_focused = "", False
        self.admin_stage_target = 10
        self.bag_open, self.bag_search, self.bag_selected = False, "", None
        for n in ("Naruto", "Village Militia", "Apprentice Mage"):
            c = Character(BY_NAME[n])
            self.roster.append(c)
            self.team.append(c.uid)
        self.ui = UIManager(self, self.screen)
        self.running = True

    def toast(self, msg):
        self.toast_msg, self.toast_t = msg, 2.2

    def get_char(self, uid):
        return next((c for c in self.roster if c.uid == uid), None)

    def team_chars(self):
        return [c for c in (self.get_char(u) for u in self.team) if c]

    def sanitize_team(self):
        """Keeps self.team consistent with the roster: drops unknown/duplicate uids and caps its size.
        Prevents a stale uid (consumed by an evolution, etc.) from blocking a team slot."""
        seen, clean = set(), []
        for uid in self.team:
            if uid not in seen and self.get_char(uid) is not None:
                seen.add(uid)
                clean.append(uid)
        self.team = clean[:TEAM_SIZE]

    def set_tab(self, tab):
        self.tab = tab
        self.set_search_focus(False)

    # --- search bar (Roster / Team tabs) -------------------------------------------------
    def set_search_focus(self, focused):
        if focused == self.search_focused:
            return
        self.search_focused = focused
        if focused:
            pygame.key.start_text_input()
            pygame.key.set_repeat(400, 35)      # hold Backspace to keep deleting
        else:
            pygame.key.stop_text_input()
            pygame.key.set_repeat()             # no key repeat elsewhere (admin keypad, hotkeys)

    def set_search_text(self, text):
        """Edits the Bag search while the Bag is open, otherwise the Roster/Team search."""
        text = text[:SEARCH_MAX_LEN]
        if self.bag_open:
            self.bag_search = text
            self.ui.bag_scroll = 0
        else:
            self.search_text = text
            self.ui.roster_scroll = self.ui.team_scroll = 0

    def _active_search_text(self):
        return self.bag_search if self.bag_open else self.search_text

    def _search_hit(self, pos):
        r = self.ui.search_rect
        return bool(r and r.collidepoint(pos))

    def _handle_search_event(self, e):
        if e.type == pygame.TEXTINPUT:
            self.set_search_text(self._active_search_text() + "".join(ch for ch in e.text if ch.isprintable()))
        elif e.type == pygame.KEYDOWN:
            if e.key == pygame.K_BACKSPACE:
                self.set_search_text(self._active_search_text()[:-1])
            elif e.key in (pygame.K_ESCAPE, pygame.K_RETURN, pygame.K_KP_ENTER):
                self.set_search_focus(False)

    # --- Bag / inventory ---------------------------------------------------------------------
    def owned_items(self):
        """[(item_key, quantity)] for every item type the player currently owns."""
        return [(k, getattr(self, k, 0)) for k in ITEMS if getattr(self, k, 0) > 0]

    def bag_total(self):
        return sum(q for _, q in self.owned_items())

    def open_bag(self):
        self.set_search_focus(False)
        self.bag_open, self.bag_search = True, ""
        self.ui.bag_scroll = 0

    def close_bag(self):
        self.set_search_focus(False)
        self.bag_open = False

    def select_bag_item(self, key):
        self.bag_selected = key

    def _handle_bag_event(self, e):
        if e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
            self.set_search_focus(self._search_hit(e.pos))
            self.ui.click(e.pos)
        elif e.type == pygame.MOUSEWHEEL:
            self.ui.bag_scroll -= e.y * 40
        elif self.search_focused and e.type in (pygame.TEXTINPUT, pygame.KEYDOWN):
            self._handle_search_event(e)
        elif e.type == pygame.KEYDOWN and e.key == pygame.K_ESCAPE:
            self.close_bag()

    @property
    def stage(self):
        """Stage that will be fought on the selected map."""
        st = self.map_stage.get(self.selected_map)
        return st["selected_stage"] if st else 1

    @property
    def max_stage(self):
        st = self.map_stage.get(self.selected_map)
        return st["max_unlocked_stage"] if st else 1

    def set_stage(self, n):
        st = self.map_stage.get(self.selected_map)
        if st:
            st["selected_stage"] = max(1, min(int(n), st["max_unlocked_stage"]))

    def change_stage(self, delta):
        self.set_stage(self.stage + delta)

    @property
    def current_map(self):
        return MAP_BY_ID.get(self.selected_map)

    def _pull(self, n, cost):
        if self.gems < cost:
            self.toast("Not enough Gems!")
            return
        self.gems -= cost
        res = self.gacha.pull(n)
        self.roster.extend(res)
        self.last_pull, self.total_pulls = res, self.total_pulls + n
        self.pull_time = pygame.time.get_ticks() / 1000
        best = max(res, key=lambda c: RARITIES.index(c.rarity))
        if best.rarity in ("Epic", "Legendary"):
            self.flash_t, self.flash_color = 0.6, RARITY_COLOR[best.rarity]
            self.toast(f"{best.rarity}: {best.name}!")

    def do_pull_1(self):
        self._pull(1, SINGLE_COST)

    def do_pull_10(self):
        self._pull(10, MULTI_COST)

    def free_gems(self):
        self.gems += 500
        self.toast("+500 Gems (demo)")

    def level_up(self, ch):
        ne, ng = ch.level_cost()
        if ch.level >= ch.level_cap or self.exp < ne or self.gold < ng:
            return
        self.exp -= ne
        self.gold -= ng
        ch.level += 1
        self.toast(f"{ch.name} reached Lv.{ch.level}!")

    def get_naruto_duplicates(self, target_uid, evo_stage=0):
        """Other Naruto copies at `evo_stage` (0 = base Naruto, 1 = Epic Sage Naruto) usable as evolution fodder."""
        return [c for c in self.roster
                if c.tpl.name == "Naruto" and c.evo_stage == evo_stage and c.uid != target_uid]

    def get_sasuke_duplicates(self, target_uid, evo_stage=0):
        return [c for c in self.roster if c.tpl.name == "Sasuke" and c.evo_stage == evo_stage and c.uid != target_uid]

    def evolve(self, ch):
        if ch is None or ch not in self.roster:
            return
        if ch.evo_stage >= ch.max_evo_stage:
            self.toast(f"{ch.name} is already at max evolution!")
            return
        if ch.level < EVO_MIN_LEVEL:
            self.toast(f"{ch.name} must reach Lv.{EVO_MIN_LEVEL} to evolve!")
            return

        old = ch.name                       # captured before the stage changes (for the toast)
        cost = ch.evo_cost()

        if ch.tpl.name == "Naruto" and ch.evo_stage == 1:
            # Tier 2: Sage Naruto -> Kurama Link Naruto
            dupes = self.get_naruto_duplicates(ch.uid, NARUTO_EVO2_DUPLICATE_STAGE)
            if (len(dupes) < cost["duplicates"] or self.gold < cost["gold"] or self.chakra < cost["chakra"]
                    or self.black_chakra < cost["black_chakra"] or self.naruto_cloak < cost["naruto_cloak"]):
                self.toast(f"Need {cost['duplicates']} Sage Naruto, {cost['gold']:,} Gold, {cost['chakra']} Chakra, "
                           f"{cost['black_chakra']} Black Chakra & {cost['naruto_cloak']} Naruto Cloak!")
                return
            for extra in dupes[:cost["duplicates"]]:
                if extra.uid in self.team:
                    self.team.remove(extra.uid)
                self.roster.remove(extra)
            self.gold -= cost["gold"]
            self.chakra -= cost["chakra"]
            self.black_chakra -= cost["black_chakra"]
            self.naruto_cloak -= cost["naruto_cloak"]
            ch.evo_stage = 2

        elif ch.tpl.name == "Naruto":
            dupes = self.get_naruto_duplicates(ch.uid)
            if len(dupes) < cost["duplicates"] or self.gold < cost["gold"] or self.chakra < cost["chakra"]:
                self.toast("Need 2 Naruto, 2000 Gold & 10 Chakra!")
                return
            for extra in dupes[:cost["duplicates"]]:
                if extra.uid in self.team:
                    self.team.remove(extra.uid)
                self.roster.remove(extra)
            self.gold -= cost["gold"]
            self.chakra -= cost["chakra"]
            ch.evo_stage = 1

        elif ch.tpl.name == "Sasuke":
            dupes = self.get_sasuke_duplicates(ch.uid, ch.evo_stage)
            need_d = cost["duplicates"]
            need_g = cost["gold"]
            need_c = cost["chakra"]
            need_bc = cost.get("black_chakra", 0)

            if len(dupes) < need_d or self.gold < need_g or self.chakra < need_c or self.black_chakra < need_bc:
                if ch.evo_stage == 0:
                    self.toast("Need 2 Sasuke, 2500 Gold & 15 Chakra!")
                else:
                    self.toast("Need 2 Curse Mark Sasuke, 7000 Gold, 20 Chakra & 1 Black Chakra!")
                return

            for extra in dupes[:need_d]:
                if extra.uid in self.team:
                    self.team.remove(extra.uid)
                self.roster.remove(extra)

            self.gold -= need_g
            self.chakra -= need_c
            self.black_chakra -= need_bc
            ch.evo_stage += 1

        elif ch.tpl.name == "Sakura":
            need_g = cost["gold"]
            need_c = cost["chakra"]
            if self.gold < need_g or self.chakra < need_c:
                self.toast(f"Need {need_g} Gold & {need_c} Chakra!")
                return
            self.gold -= need_g
            self.chakra -= need_c
            ch.evo_stage = 1

        else:
            stones, gold = cost["stones"], cost["gold"]
            if self.stones < stones or self.gold < gold:
                self.toast(f"Need {stones} Evolution Stone(s) & {gold} Gold!")
                return
            self.stones -= stones
            self.gold -= gold
            ch.evo_stage = 1

        self.sanitize_team()
        self.flash_t, self.flash_color = 0.8, ch.color
        self.toast(f"{old} awakened into {ch.name}!")

    # --- Admin / cheat menu -----------------------------------------------------------
    @property
    def admin_modal_active(self):
        return self.admin_prompt_open or self.admin_panel_open

    def open_admin(self):
        self.set_search_focus(False)
        self.admin_prompt_open, self.admin_panel_open, self.admin_input_code = True, False, ""

    def close_admin(self):
        self.admin_prompt_open, self.admin_panel_open, self.admin_input_code = False, False, ""

    def admin_press_digit(self, d):
        if self.admin_prompt_open and len(self.admin_input_code) < len(ADMIN_PASSCODE):
            self.admin_input_code += str(d)

    def admin_backspace(self):
        self.admin_input_code = self.admin_input_code[:-1]

    def admin_clear(self):
        self.admin_input_code = ""

    def admin_submit(self):
        if not self.admin_prompt_open:
            return
        if self.admin_input_code == ADMIN_PASSCODE:
            self.admin_prompt_open, self.admin_panel_open = False, True
            self.toast("Admin Unlocked!")
        else:
            self.toast("Incorrect Passcode!")
        self.admin_input_code = ""

    # --- admin: stage cheats ----------------------------------------------------------------
    def _admin_stage_states(self):
        """Progress record(s) the stage cheats act on: selected map, or every map if none."""
        if self.selected_map in self.map_stage:
            return [self.map_stage[self.selected_map]]
        return list(self.map_stage.values())

    def admin_change_target(self, delta):
        self.admin_stage_target = max(1, self.admin_stage_target + delta)

    def admin_set_max_stage(self):
        if not self.admin_panel_open:
            return
        n = self.admin_stage_target
        for st in self._admin_stage_states():
            st["max_unlocked_stage"] = st["selected_stage"] = n
        self.toast(f"Admin: Max Stage set to {n}!")

    def admin_skip_stage(self):
        """Mark the selected stage as cleared without fighting and move on to the next one."""
        if not self.admin_panel_open:
            return
        cleared = None
        for st in self._admin_stage_states():
            cleared = st["selected_stage"]
            if cleared >= st["max_unlocked_stage"]:
                st["max_unlocked_stage"] = cleared + 1
            st["selected_stage"] = cleared + 1
        self.toast(f"Admin: Stage {cleared} skipped!" if self.selected_map in self.map_stage
                   else "Admin: Stage skipped on all maps!")

    def admin_instant_win(self):
        b = self.battle
        if not self.admin_panel_open or not b or b.state != "fighting":
            return
        b.force_victory()
        self._apply_rewards()
        self.toast("Admin: Battle cleared!")
        self.close_admin()

    def admin_give_all_characters(self):
        """Admin: add one new copy of EVERY template to the roster, in every form it can take -
        Base (evo_stage 0), Evolution Tier 1 and, for templates that have one, Evolution Tier 2."""
        if not self.admin_panel_open:
            return
        for tpl in TEMPLATES:
            base = Character(tpl)
            self.roster.append(base)
            for stage in range(1, base.max_evo_stage + 1):
                form = Character(tpl)
                form.evo_stage = stage
                self.roster.append(form)
        self.sanitize_team()
        self.toast("Admin Granted: All Characters & Evolutions added to roster!")

    def admin_claim(self, kind):
        if not self.admin_panel_open:
            return
        n = ADMIN_GRANT
        if kind in ("currency", "all"):
            self.gold += n
            self.gems += n
        if kind in ("materials", "all"):
            self.exp += n
            for key in ITEMS:
                setattr(self, key, getattr(self, key, 0) + n)
        self.toast({"currency": f"Admin Granted! +{n:,} Gems & Gold",
                    "materials": f"Admin Granted! +{n:,} to all materials",
                    "all": f"Admin Granted! +{n:,} of everything"}[kind])

    _KP_NAMES = [f"K_KP{i}" for i in range(10)]

    def _handle_admin_event(self, e):
        if e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
            self.ui.click(e.pos)
        elif e.type == pygame.KEYDOWN:
            k = e.key
            if k == pygame.K_ESCAPE:
                self.close_admin()
            elif self.admin_prompt_open:
                if k == pygame.K_BACKSPACE:
                    self.admin_backspace()
                elif k in (pygame.K_RETURN, pygame.K_KP_ENTER):
                    self.admin_submit()
                elif pygame.K_0 <= k <= pygame.K_9:
                    self.admin_press_digit(k - pygame.K_0)
                else:
                    for i, name in enumerate(self._KP_NAMES):
                        if k == getattr(pygame, name, None):
                            self.admin_press_digit(i)

    def toggle_team(self, uid):
        self.sanitize_team()
        if self.get_char(uid) is None:
            return
        if uid in self.team:
            self.team.remove(uid)
        elif len(self.team) < TEAM_SIZE:
            self.team.append(uid)
        else:
            self.toast(f"Team is full ({TEAM_SIZE}). Remove someone first.")

    def select_map(self, map_id):
        if map_id in MAP_BY_ID:
            self.selected_map = map_id

    def start_battle(self):
        if self.selected_map is None:
            self.toast("Select a map first!")
            return
        self.sanitize_team()
        chars = self.team_chars()
        if not chars:
            self.toast("Select at least one character!")
            return
        self.battle = BattleManager(chars, self.stage, self.selected_map)

    def retreat(self):
        self.battle = None
        self.toast("You retreated.")

    def finish_battle(self, then=None):
        """Close the result screen. Winning the newest stage unlocks the next one; replaying a
        cleared stage keeps progress as is. then = None | "replay" | "next" starts a new fight."""
        b, self.battle = self.battle, None
        if not b:
            return
        st = self.map_stage.get(b.map_id)
        if not st:
            return
        won = b.state == "victory"
        if won and b.stage >= st["max_unlocked_stage"]:
            st["max_unlocked_stage"] = b.stage + 1
            st["selected_stage"] = st["max_unlocked_stage"]
            self.toast(f"Stage {st['max_unlocked_stage']} unlocked!")
        if then in ("replay", "next"):
            target = b.stage + 1 if (then == "next" and won) else b.stage
            self.selected_map = b.map_id
            self.set_stage(target)
            self.start_battle()

    def _apply_rewards(self):
        b = self.battle
        if b and b.state == "victory" and b.rewards and not b.rewards.get("applied"):
            r = b.rewards
            self.gold += r["gold"]
            self.gems += r["gems"]
            self.exp += r["exp"]
            for item, amt in r["drops"].items():
                setattr(self, item, getattr(self, item, 0) + amt)
            for key, message in DROP_ANNOUNCEMENTS:
                if key in r["drops"]:
                    self.flash_t, self.flash_color = 0.8, ITEMS[key]["color"]
                    self.toast(message)
                    break
            r["applied"] = True

    def handle_event(self, e):
        if e.type == pygame.QUIT:
            self.running = False
        elif self.admin_modal_active:
            self._handle_admin_event(e)
        elif self.bag_open:
            self._handle_bag_event(e)
        elif e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
            self.set_search_focus(self._search_hit(e.pos))
            self.ui.click(e.pos)
        elif self.search_focused and e.type in (pygame.TEXTINPUT, pygame.KEYDOWN):
            self._handle_search_event(e)        # swallow typing so hotkeys (1-3) don't fire
        elif e.type == pygame.MOUSEWHEEL:
            if self.tab == "roster":
                self.ui.roster_scroll -= e.y * 40
            elif self.tab == "team":
                self.ui.team_scroll -= e.y * 40
        elif e.type == pygame.KEYDOWN and self.tab == "battle" and self.battle:
            idx = {pygame.K_1: 0, pygame.K_2: 1, pygame.K_3: 2}.get(e.key)
            if idx is not None and idx < len(self.battle.players):
                self.battle.cast(self.battle.players[idx])

    def update(self, dt):
        self.toast_t = max(0, self.toast_t - dt)
        self.flash_t = max(0, self.flash_t - dt)
        self.sanitize_team()
        if self.battle and not self.admin_modal_active:    # battle is paused behind the admin panel
            self.battle.update(dt)
            self._apply_rewards()

    def run(self):
        while self.running:
            dt = min(self.clock.tick(FPS) / 1000, 0.05)
            for e in pygame.event.get():
                self.handle_event(e)
            self.update(dt)
            self.ui.draw()
            pygame.display.flip()
        pygame.quit()
        sys.exit()