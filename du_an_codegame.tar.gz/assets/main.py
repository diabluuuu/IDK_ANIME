#!/usr/bin/env python3
"""ETERNAL SUMMONERS - entry point for Pygbag / Web."""
import asyncio
import sys
import pygame
from game import Game

# Override lại hàm run() của Game để tích hợp asyncio.sleep(0)
async def main():
    game = Game()
    while game.running:
        dt = min(game.clock.tick(60) / 1000, 0.05)
        for e in pygame.event.get():
            game.handle_event(e)
        game.update(dt)
        game.ui.draw()
        pygame.display.flip()
        
        # Nhường frame cho trình duyệt render (BẮT BUỘC VỚI PYGBAG)
        await asyncio.sleep(0)

    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    asyncio.run(main())