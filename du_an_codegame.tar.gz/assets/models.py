"""models.py - Skill, Template, Character data model and the gacha roller."""
import random

from config import *


class Skill:
    def __init__(self, name, cooldown, mult, target, color, dmg_type, charge_hits=0):
        self.name, self.cooldown, self.mult = name, cooldown, mult
        self.target, self.color, self.dmg_type = target, color, dmg_type
        self.charge_hits = int(charge_hits or 0)   # > 0: skill is charged by landed basic attacks, no cooldown

    @property
    def aoe(self):
        return self.target == "aoe"

    @property
    def heal(self):
        """Support skill: `mult` is the fraction of Max HP restored to every living ally."""
        return self.target == "heal"

    def brief(self):
        """Short one-line label used on the battle skill buttons."""
        if self.heal:
            return f"Heal {int(round(self.mult * 100))}% HP  Team  CD {self.cooldown}s"
        when = f"Every {self.charge_hits} hits" if self.charge_hits else f"CD {self.cooldown}s"
        return f"x{self.mult:.1f} {'AOE' if self.aoe else 'Single'}  {when}"

    def describe(self):
        if self.heal:
            return (f"{self.name}: heals all allies for {int(round(self.mult * 100))}% of Max HP, "
                    f"CD {self.cooldown}s")
        tgt = "all enemies" if self.aoe else "single target"
        if self.charge_hits:
            return f"{self.name}: x{self.mult:.1f} {self.dmg_type} dmg, {tgt}, after {self.charge_hits} basic hits"
        return f"{self.name}: x{self.mult:.1f} {self.dmg_type} dmg, {tgt}, CD {self.cooldown}s"


class Passive:
    def __init__(self, key, name, desc, chance=1.0):
        self.key, self.name, self.desc, self.chance = key, name, desc, chance


SASUKE_PASSIVE = Passive(
    "atk_speed", "Battle Rhythm",
    "15% chance to gain +15% ATK SPD on basic attack.", 0.15)
NARUTO_EVO_PASSIVE = Passive(
    "shadow_clone", "Shadow Clone",
    "10% chance to summon a Shadow Clone in front to launch ranged kunai attacks. Lasts up to 15s.", 0.10)
AMATERASU_PASSIVE = Passive(
    "amaterasu", "Amaterasu",
    "Every 3rd basic attack on the same target triggers Amaterasu black flames, burning 5 times for extra damage.", 1.0)
CHAKRA_CATALYST_PASSIVE = Passive(
    "chakra_catalyst", "Chakra Catalyst",
    "Every 15s in combat, pulses healing chakra to reduce active skill cooldowns of all allies by 10%.", 1.0)
SAKURA_EVO_PASSIVE = CHAKRA_CATALYST_PASSIVE
KURAMA_CLOAK_PASSIVE = Passive(
    "kurama_cloak", "Kurama's Cloak",
    f"{int(KURAMA_WARD_INTERVAL)}s into battle, wraps allies in Kurama's chakra cloak: "
    f"-{int(round(KURAMA_WARD_REDUCTION * 100))}% damage taken for {int(KURAMA_WARD_DURATION)}s. "
    f"Repeats every {int(KURAMA_WARD_INTERVAL)}s.", 1.0)


class Template:
    def __init__(self, name, rarity, dmg_type, color, evo_name, evo_color, skill=None, evo_rarity=None,
                 passive=None, evo_passive=None, evo2_name=None, evo2_color=None, evo2_rarity=None,
                 evo2_skill=None, evo2_passive=None, melee=False, evo_skill=None,
                 evo2_melee=False, evo2_mult=None, evo2_level_cap=None):
        self.name, self.rarity, self.dmg_type = name, rarity, dmg_type
        self.melee = melee   # True: basic attack = dash + punch instead of a ranged hit
        self.color, self.evo_name, self.evo_color = color, evo_name, evo_color
        self.skill = skill
        self.evo_skill = evo_skill
        self.evo_rarity = evo_rarity or rarity
        self.passive = passive
        self.evo_passive = evo_passive
        # Evolution Tier 2 (Legendary)
        self.evo2_name = evo2_name
        self.evo2_color = evo2_color
        self.evo2_rarity = evo2_rarity
        self.evo2_skill = evo2_skill
        self.evo2_passive = evo2_passive
        self.evo2_melee = evo2_melee            # True: Tier 2 form attacks with a dash + punch
        self.evo2_mult = evo2_mult              # optional {"hp","atk","df"} multipliers for Tier 2
        self.evo2_level_cap = evo2_level_cap    # optional level cap for Tier 2


TEMPLATES = [
    Template("Village Militia", "Common", "Physical", (150, 150, 160), "Veteran Guard", (210, 200, 120)),
    Template("Apprentice Mage", "Common", "Magic", (90, 130, 200), "Adept Mage", (130, 190, 255)),
    Template("Forest Scout", "Common", "Physical", (90, 160, 90), "Ranger Captain", (150, 230, 120)),
    Template("Hedge Witch", "Common", "Magic", (160, 100, 160), "Moon Witch", (220, 150, 255)),
    Template("Iron Knight", "Rare", "Physical", (120, 140, 175), "Steel Paladin", (200, 220, 255)),
    Template("Naruto", "Rare", "Physical", (255, 140, 0), "Sage Naruto", (255, 200, 50),
             (None, "Rasen Shuriken", 7, 3.2, "aoe"), evo_rarity="Epic",
             evo_passive=NARUTO_EVO_PASSIVE,
             # Tier 2 (Nine-Tails Chakra Naruto): melee dash attacks, 5-hit charged Rasengan, team damage-reduction aura
             evo2_name=NARUTO_EVO2_NAME, evo2_color=KURAMA_COLOR, evo2_rarity="Legendary",
             evo2_skill=(KURAMA_SKILL_NAME, 0, KURAMA_RASENGAN_MULT, "single", KURAMA_SKILL_HITS),
             evo2_passive=KURAMA_CLOAK_PASSIVE, evo2_melee=True,
             evo2_mult=NARUTO_EVO2_MULT, evo2_level_cap=NARUTO_EVO2_LEVEL_CAP),
    Template("Sasuke", "Rare", "Physical", (60, 100, 220), "Curse Mark Sasuke", (130, 60, 200),
             (None, "Fire Ball", 6, 2.8, "aoe"), evo_rarity="Epic",
             passive=SASUKE_PASSIVE, evo_passive=SASUKE_PASSIVE,
             evo2_name="Taka Sasuke", evo2_color=(220, 50, 80), evo2_rarity="Legendary",
             evo2_skill=("Chidori", 8, 3.8, "aoe"), evo2_passive=AMATERASU_PASSIVE),
    Template("Fire Sorcerer", "Rare", "Magic", (210, 100, 60), "Inferno Sorcerer", (255, 150, 60)),
    Template("Shadow Rogue", "Rare", "Physical", (80, 80, 120), "Night Assassin", (150, 90, 230)),
    Template("Frost Archer", "Rare", "Physical", (110, 190, 220), "Blizzard Archer", (190, 245, 255)),
    Template("Flame Ronin", "Epic", "Physical", (200, 70, 60), "Blaze Demon Ronin", (255, 120, 30),
             ("Crimson Slash", "Inferno Slash", 6, 2.4, "single")),
    Template("Storm Mage", "Epic", "Magic", (80, 120, 230), "Tempest Archmage", (120, 220, 255),
             ("Chain Lightning", "Thunder Judgment", 8, 1.6, "aoe")),
    Template("Jade Dragoon", "Epic", "Physical", (60, 170, 130), "Jade Dragon Lord", (90, 255, 180),
             ("Dragon Dive", "Dragon Cataclysm", 7, 2.6, "single")),
    Template("Sakura", "Epic", "Physical", (230, 100, 150), "Chakra Surge Sakura", (255, 140, 195),
             ("Healing Jutsu", "Chakra Surge Heal", 10, 0.20, "heal"), evo_rarity="Legendary",
             evo_passive=CHAKRA_CATALYST_PASSIVE, melee=True,
             evo_skill=("Chakra Surge Heal", 8, 0.35, "heal")),
    Template("Kitsune Prince", "Legendary", "Magic", (240, 150, 50), "Nine-Tailed Fury", (255, 80, 30),
             ("Spirit Fire Barrage", "Nine-Tail Cataclysm", 9, 2.0, "aoe")),
    Template("Celestial Valkyrie", "Legendary", "Physical", (240, 220, 140), "Ascended Valkyrie", (255, 250, 200),
             ("Heaven's Spear", "Divine Judgment", 9, 3.5, "single")),
    Template("Void Emperor", "Legendary", "Magic", (120, 60, 180), "Void Sovereign", (200, 90, 255),
             ("Abyss Collapse", "Event Horizon", 10, 2.4, "aoe")),
]
BY_RARITY = {r: [t for t in TEMPLATES if t.rarity == r] for r in RARITIES}
BY_NAME = {t.name: t for t in TEMPLATES}


class Character:
    _next_id = 1

    def __init__(self, tpl):
        self.uid = Character._next_id
        Character._next_id += 1
        self.tpl = tpl
        self.level = 1
        self.evo_stage = 0  # 0: Base, 1: Evo Tier 1 (Epic), 2: Evo Tier 2 (Legendary)

    @property
    def evolved(self):
        return self.evo_stage > 0

    @property
    def name(self):
        if self.evo_stage == 2:
            return self.tpl.evo2_name or self.tpl.evo_name
        elif self.evo_stage == 1:
            return self.tpl.evo_name
        return self.tpl.name

    @property
    def rarity(self):
        if self.evo_stage == 2:
            return self.tpl.evo2_rarity or self.tpl.evo_rarity
        elif self.evo_stage == 1:
            return self.tpl.evo_rarity
        return self.tpl.rarity

    @property
    def color(self):
        if self.evo_stage == 2:
            return self.tpl.evo2_color or self.tpl.evo_color
        elif self.evo_stage == 1:
            return self.tpl.evo_color
        return self.tpl.color

    @property
    def level_cap(self):
        if self.evo_stage == 2 and self.tpl.evo2_level_cap:
            return self.tpl.evo2_level_cap
        return EVOLVED_LEVEL_CAP if self.evolved else LEVEL_CAP

    @property
    def melee(self):
        """True when the basic attack is a dash + punch (Sakura always, Nine-Tails Chakra Naruto at Tier 2)."""
        return bool(self.tpl.melee or (self.evo_stage == 2 and self.tpl.evo2_melee))

    @property
    def has_skill(self):
        return self.skill is not None

    @property
    def passive(self):
        if self.evo_stage == 2:
            return self.tpl.evo2_passive
        elif self.evo_stage == 1:
            return self.tpl.evo_passive
        return self.tpl.passive

    @property
    def has_passive(self):
        return self.passive is not None

    def rarity_for_stage(self, stage):
        t = self.tpl
        if stage >= 2:
            return t.evo2_rarity or t.evo_rarity
        if stage == 1:
            return t.evo_rarity
        return t.rarity

    @property
    def max_evo_stage(self):
        return 2 if self.tpl.evo2_name else 1

    def stats(self, level=None, evo_stage=None):
        lv = self.level if level is None else level
        stg = self.evo_stage if evo_stage is None else evo_stage
        hp, atk, df = RARITY_STATS[self.rarity_for_stage(stg)]
        g = 1 + 0.12 * (lv - 1)
        if stg == 1:
            hp_m = EVO_MULT.get("hp", 1.8)
            atk_m = EVO_MULT.get("atk", 1.8)
            df_m = EVO_MULT.get("df", 1.8)
            return (int(hp * g * hp_m), int(atk * g * atk_m), int(df * g * df_m))
        elif stg == 2:
            m = self.tpl.evo2_mult or {}
            hp_m = m.get("hp", EVO2_MULT_DEFAULT)
            atk_m = m.get("atk", EVO2_MULT_DEFAULT)
            df_m = m.get("df", EVO2_MULT_DEFAULT)
            return (int(hp * g * hp_m), int(atk * g * atk_m), int(df * g * df_m))
        return (int(hp * g), int(atk * g), int(df * g))

    def skill_for_stage(self, stage):
        if stage == 2 and self.tpl.evo2_skill:
            # (name, cooldown, mult, target[, charge_hits]) - the optional 5th value makes it a charge skill
            name, cd, mult, target, *extra = self.tpl.evo2_skill
            return Skill(name, cd, mult, target, self.tpl.evo2_color, self.tpl.dmg_type,
                         charge_hits=extra[0] if extra else 0)
        elif stage == 1:
            if getattr(self.tpl, "evo_skill", None):
                name, cd, mult, target = self.tpl.evo_skill
                return Skill(name, cd, mult, target, self.tpl.evo_color, self.tpl.dmg_type)
            s = self.tpl.skill
            if s and s[1]:
                return Skill(s[1], s[2], s[3], s[4], self.tpl.evo_color, self.tpl.dmg_type)
        elif stage == 0:
            s = self.tpl.skill
            if s and s[0]:
                return Skill(s[0], s[2], s[3], s[4], self.tpl.color, self.tpl.dmg_type)
        return None

    @property
    def skill(self):
        return self.skill_for_stage(self.evo_stage)

    def level_cost(self):
        return 10 * self.level, 25 * self.level

    def evo_cost(self):
        if self.tpl.name == "Naruto":
            if self.evo_stage == 1:      # Sage Naruto -> Nine-Tails Chakra Naruto
                return dict(NARUTO_EVO2_COST)
            return {"duplicates": 2, "gold": 2000, "chakra": 10}
        if self.tpl.name == "Sasuke":
            if self.evo_stage == 0:
                return {"duplicates": 2, "gold": 2500, "chakra": 15, "black_chakra": 0}
            elif self.evo_stage == 1:
                return {"duplicates": 2, "gold": 7000, "chakra": 20, "black_chakra": 1}
        if self.tpl.name == "Sakura":
            return {"gold": 2500, "chakra": 15}
        return {"stones": EVO_STONES[self.rarity], "gold": EVO_GOLD[self.rarity]}


class GachaSystem:
    def roll_rarity(self):
        return random.choices(RARITIES, weights=[RARITY_RATE[r] for r in RARITIES])[0]

    def pull(self, n):
        return [Character(random.choice(BY_RARITY[self.roll_rarity()])) for _ in range(n)]