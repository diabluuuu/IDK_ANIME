"""ui.py - UIManager: tabs, buttons, hit-testing and all screen drawing.

Visual theme: obsidian panels, amber/gold trim with corner accents, chakra-blue + ember highlights.
Everything here is presentation only: game state is read, never changed, and every clickable region
is still registered through self.hit() exactly as before.
"""
import math
import random

import pygame

from config import *
from drawing import (font, txt, txt_fit, fit_text, panel, overlay, hp_bar, shade, mix, draw_hero, draw_enemy, assets,
                     draw_punch, draw_heal_pulse, _stone_tint_surface,
                     draw_magma_shot, draw_super_magma_shot, draw_roushi_cast, draw_burn_status,
                     draw_kurama_aura, draw_kurama_cast, draw_naruto_rasengan, draw_naruto_attack,
                     draw_han_cast, draw_han_steam_shot,
                     backdrop, gradient_surface, button_face, tab_face, draw_glow, radial_glow, corner_accents,
                     divider, star_row, draw_star, badge, section_title, dashed_rect, scrollbar,
                     draw_coin, draw_gem, draw_exp_icon, draw_seal)
from battle import slot_ys, stage_drop_table


class UIManager:
    TABS = [("gacha", "Summon"), ("roster", "Roster"), ("team", "Team"), ("battle", "Battle")]

    def __init__(self, game, screen):
        self.g, self.screen = game, screen
        self.hits = []
        self.roster_scroll = self.team_scroll = 0
        self.selected = None
        self.search_rect = None     # set each frame by draw_search_box() (None = not visible)
        self.bag_scroll = 0

    def hit(self, rect, action, clip=None):
        self.hits.append((pygame.Rect(rect), action, clip))

    def click(self, pos):
        for rect, action, clip in reversed(self.hits):
            if rect.collidepoint(pos) and (clip is None or clip.collidepoint(pos)):
                action()
                return

    # ------------------------------------------------------------------ building blocks
    def major(self, rect, border=AMBER_DEEP):
        """Main content panel: obsidian body, amber border, soft ember glow, corner accents."""
        panel(self.screen, rect, PANEL, border, 14, 2, glow=(AMBER_DEEP, 7, 44), corners=AMBER)

    def inset(self, rect, border=(78, 62, 44)):
        """Recessed sub-panel inside a major panel."""
        panel(self.screen, rect, PANEL_DEEP, border, 10, 1, shadow=False)

    def modal_panel(self, rect, border=AMBER):
        panel(self.screen, rect, (26, 24, 34), border, 16, 3, glow=(AMBER_DEEP, 12, 100), corners=AMBER)

    def button(self, rect, label, action, enabled=True, color=BTN_CHAKRA, size=20, sub=None):
        s = self.screen
        rect = pygame.Rect(rect)
        hover = enabled and rect.collidepoint(pygame.mouse.get_pos())
        pressed = hover and pygame.mouse.get_pressed()[0]
        radius = 12 if rect.h >= 40 else (10 if rect.h >= 28 else 7)
        state = "d" if not enabled else ("p" if pressed else ("h" if hover else "n"))
        if hover and not pressed:
            draw_glow(s, rect, radius, color, 7, 110)
        s.blit(button_face(rect.w, rect.h, color, radius, state), rect.topleft)
        tc = TEXT if enabled else (112, 110, 126)
        dy = 1 if pressed else 0
        max_w = rect.w - 14
        if sub:
            txt_fit(s, label, size, tc, (rect.centerx, rect.centery - 9 + dy), max_w, "center", True, 11, enabled)
            txt_fit(s, sub, size - 5, shade(tc, 0.85), (rect.centerx, rect.centery + 12 + dy), max_w, "center",
                    False, 9)
        else:
            txt_fit(s, label, size, tc, (rect.centerx, rect.centery + dy), max_w, "center", True, 11, enabled)
        if enabled:
            self.hit(rect, action)

    def _tab(self, rect, label, active, enabled, action):
        s = self.screen
        hover = enabled and rect.collidepoint(pygame.mouse.get_pos())
        state = "a" if active else ("h" if hover else ("n" if enabled else "d"))
        if active:
            draw_glow(s, rect, 11, AMBER_DEEP, 9, 120)
        s.blit(tab_face(rect.w, rect.h, state), rect.topleft)
        col = (40, 22, 4) if active else (TEXT if hover else (DIM if enabled else (84, 82, 98)))
        txt(s, label, 19, col, rect.center, "center", True)
        if enabled:
            self.hit(rect, action)

    @staticmethod
    def _num(n):
        return f"{n:,}" if n < 1000000 else f"{n / 1000000:.2f}M"

    def _chip(self, rect, kind, value, color):
        """Currency pill for the top bar: icon + amount."""
        s = self.screen
        panel(s, rect, (18, 18, 26), shade(color, 0.62), rect.h // 2, 2, shadow=False)
        ix, iy = rect.x + 17, rect.centery
        if kind == "gold":
            draw_coin(s, ix, iy, 9)
        elif kind == "gems":
            draw_gem(s, ix, iy, 9)
        else:
            draw_exp_icon(s, ix, iy, 10)
        txt_fit(s, self._num(value), 16, color, (rect.right - 12, rect.centery), rect.w - 46, "midright", True, 11)

    def filtered(self, chars):
        q = self.g.search_text.strip().lower()
        return [c for c in chars if q in c.name.lower()] if q else chars

    def count_label(self, shown):
        total = len(self.g.roster)
        return f"{shown}/{total}" if self.g.search_text.strip() else f"{total}"

    def draw_search_box(self, rect, text=None):
        g, s = self.g, self.screen
        text = g.search_text if text is None else text
        rect = pygame.Rect(rect)
        self.search_rect = rect
        focus = g.search_focused
        panel(s, rect, (12, 12, 18), AMBER if focus else (96, 76, 48), 10, 2 if focus else 1, shadow=False,
              glow=(AMBER_DEEP, 6, 90) if focus else None)
        mx, my = rect.x + 16, rect.centery - 1                  # magnifier icon
        icol = AMBER if focus else (150, 128, 96)
        pygame.draw.circle(s, icol, (mx, my), 6, 2)
        pygame.draw.line(s, icol, (mx + 4, my + 4), (mx + 9, my + 9), 2)
        xr = pygame.Rect(rect.right - 28, rect.y + 4, 24, rect.h - 8)
        self.button(xr, "X", lambda: g.set_search_text(""), enabled=bool(text), color=(120, 56, 64), size=13)
        left = rect.x + 30
        avail = xr.x - left - 8
        f = font(16)
        shown = text
        while shown and f.size(shown)[0] > avail:
            shown = shown[1:]                       # keep the tail visible while typing
        blink = int(pygame.time.get_ticks() / 500) % 2 == 0
        if shown:
            r = txt(s, shown, 16, TEXT, (left, rect.centery), "midleft")
            if focus and blink:
                pygame.draw.line(s, AMBER, (r.right + 2, rect.centery - 8), (r.right + 2, rect.centery + 8), 2)
        elif focus:
            if blink:
                pygame.draw.line(s, AMBER, (left + 1, rect.centery - 8), (left + 1, rect.centery + 8), 2)
        else:
            txt(s, "Type to search...", 16, (110, 104, 122), (left, rect.centery), "midleft")

    # ------------------------------------------------------------------ frame
    def draw(self):
        self.hits = []
        self.search_rect = None
        s = self.screen
        s.blit(backdrop(), (0, 0))
        g = self.g
        locked = g.battle is not None and g.battle.state == "fighting"
        self._draw_top_bar(locked)
        getattr(self, "draw_" + g.tab)()
        if g.admin_modal_active:
            self.draw_admin_modal()
        if g.bag_open:
            self.draw_bag_modal()
        if g.toast_t > 0:
            msg = str(g.toast_msg)
            r = pygame.Rect(0, 0, min(W - 40, font(22, True).size(msg)[0] + 48), 42)
            r.center = (W // 2, H - 32)
            panel(s, r, (22, 20, 28), AMBER, 21, 2, glow=(AMBER_DEEP, 9, 100), shadow=False)
            txt_fit(s, msg, 22, TEXT, r.center, r.w - 40, "center", True, 13)
        if g.flash_t > 0:
            overlay(s, pygame.Rect(0, 0, W, H), (*g.flash_color, int(190 * g.flash_t)))

    def _draw_top_bar(self, locked):
        g, s = self.g, self.screen
        s.blit(gradient_surface(W, 56, (34, 26, 30), (15, 14, 21), 0), (0, 0))
        pygame.draw.line(s, AMBER_DEEP, (0, 55), (W, 55), 2)
        for i, (key, label) in enumerate(self.TABS):
            r = pygame.Rect(20 + i * 150, 8, 140, 40)
            self._tab(r, label, g.tab == key, not locked or key == "battle", lambda k=key: g.set_tab(k))
        for i, (val, col, kind) in enumerate([(g.gold, GOLD_C, "gold"), (g.gems, GEM_C, "gems"),
                                              (g.exp, EXP_C, "exp")]):
            self._chip(pygame.Rect(636 + i * 112, 12, 104, 32), kind, val, col)
        self.button((980, 8, 100, 40), "Bag", g.open_bag, True, BTN_BRONZE, 17, sub=f"{g.bag_total():,} items")

    # ------------------------------------------------------------------ admin
    def draw_admin_modal(self):
        g, s = self.g, self.screen
        self.hits = []
        overlay(s, pygame.Rect(0, 0, W, H), (0, 0, 0, 175))
        cx = W // 2
        if g.admin_prompt_open:
            box = pygame.Rect(cx - 210, 90, 420, 520)
            self.modal_panel(box)
            txt(s, "Admin Passcode", 28, AMBER_SOFT, (cx, box.y + 36), "center", True, shadow=True)
            txt(s, "Enter Admin Passcode", 14, DIM, (cx, box.y + 66), "center")
            n = len(ADMIN_PASSCODE)
            x0 = cx - (n * 46 + (n - 1) * 8) // 2
            for i in range(n):
                slot = pygame.Rect(x0 + i * 54, box.y + 90, 46, 56)
                filled = i < len(g.admin_input_code)
                panel(s, slot, (12, 12, 18), AMBER if filled else (84, 68, 48), 8, 2, shadow=False)
                if filled:
                    pygame.draw.circle(s, AMBER_SOFT, slot.center, 8)
            keys = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "C", "0", "<"]
            for i, k in enumerate(keys):
                r = pygame.Rect(cx - 145 + (i % 3) * 100, box.y + 172 + (i // 3) * 66, 90, 56)
                if k == "C":
                    self.button(r, "Clear", g.admin_clear, True, BTN_DANGER, 18)
                elif k == "<":
                    self.button(r, "Del", g.admin_backspace, True, BTN_BRONZE, 18)
                else:
                    self.button(r, k, lambda d=k: g.admin_press_digit(d), True, BTN_NEUTRAL, 24)
            self.button((cx - 185, box.bottom - 70, 170, 50), "Cancel", g.close_admin, True, BTN_DANGER, 20)
            self.button((cx + 15, box.bottom - 70, 170, 50), "Enter", g.admin_submit, True, BTN_GOOD, 20)
            self.button((box.right - 46, box.y + 10, 36, 32), "X", g.close_admin, True, BTN_DANGER, 16)
            return
        box = pygame.Rect(cx - 270, 70, 540, 540)
        self.modal_panel(box, GOLD_C)
        txt(s, "ADMIN SYSTEM PANEL", 32, GOLD_C, (cx, box.y + 38), "center", True, shadow=True)
        txt(s, f"Developer cheat menu  (+{ADMIN_GRANT:,} per claim)", 14, DIM, (cx, box.y + 68), "center")
        stats = [("Gold", g.gold, GOLD_C), ("Gems", g.gems, GEM_C), ("EXP", g.exp, EXP_C)]
        stats += [(ITEMS[k]["short"], getattr(g, k), ITEMS[k]["color"]) for k in ITEMS]
        cols = 4
        step = (box.w - 60) // cols
        for i, (lab, val, col) in enumerate(stats):
            txt(s, f"{lab}: {val:,}", 13, col,
                (box.x + 30 + (i % cols) * step, box.y + 92 + (i // cols) * 16), "topleft", True)
        bw = box.w - 80
        self.button((box.x + 40, box.y + 146, bw, 42), "Claim +10k Gems & Gold", lambda: g.admin_claim("currency"),
                    True, BTN_CHAKRA, 20)
        self.button((box.x + 40, box.y + 194, bw, 42), "Claim +10k All Materials", lambda: g.admin_claim("materials"),
                    True, BTN_GOOD, 20)
        self.button((box.x + 40, box.y + 242, bw, 42), "Claim ALL (+10k Everything)", lambda: g.admin_claim("all"),
                    True, BTN_PRIMARY, 20)
        divider(s, box.x + 40, box.right - 40, box.y + 296)
        tm = g.current_map
        txt(s, "Stage Cheat - " + (f"{tm['name']}  (Unlocked: Max Stage {g.max_stage})" if tm else "All maps"),
            14, TEXT, (box.x + 40, box.y + 308), "topleft", True)
        ry = box.y + 330
        tgt = g.admin_stage_target
        self.button((box.x + 40, ry, 44, 32), "-10", lambda: g.admin_change_target(-10), tgt > 1, BTN_NEUTRAL, 15)
        self.button((box.x + 88, ry, 44, 32), "-1", lambda: g.admin_change_target(-1), tgt > 1, BTN_NEUTRAL, 15)
        txt(s, f"Target: {tgt}", 17, GOLD_C, (box.x + 222, ry + 16), "center", True)
        self.button((box.x + 312, ry, 44, 32), "+1", lambda: g.admin_change_target(1), True, BTN_NEUTRAL, 15)
        self.button((box.x + 360, ry, 44, 32), "+10", lambda: g.admin_change_target(10), True, BTN_NEUTRAL, 15)
        self.button((box.x + 412, ry, 88, 32), "Set Max", g.admin_set_max_stage, True, BTN_GOOD, 15)
        ry2 = box.y + 370
        self.button((box.x + 40, ry2, 218, 38), "Skip Stage", g.admin_skip_stage, True, BTN_PRIMARY, 17)
        self.button((box.x + 282, ry2, 218, 38), "Instant Win Battle", g.admin_instant_win,
                    g.battle is not None and g.battle.state == "fighting", BTN_DANGER, 17)
        divider(s, box.x + 40, box.right - 40, box.y + 418)
        self.button((box.x + 40, box.y + 428, box.w - 80, 42), "Give All Characters",
                    g.admin_give_all_characters, True, BTN_VIOLET, 20)
        self.button((box.centerx - 90, box.bottom - 60, 180, 46), "Close", g.close_admin, True, BTN_DANGER, 20)
        self.button((box.right - 46, box.y + 10, 36, 32), "X", g.close_admin, True, BTN_DANGER, 16)

    def draw_item_icon(self, key, cx, cy, r):
        s = self.screen
        cx, cy = int(cx), int(cy)
        img = assets.get_item_image(key, size=int(r * 2))
        if img:
            s.blit(img, img.get_rect(center=(cx, cy)))
            return

        col = ITEMS[key]["color"]
        if key == "stones":
            pts = [(cx, cy - r), (cx + r * 0.8, cy - r * 0.2), (cx, cy + r), (cx - r * 0.8, cy - r * 0.2)]
            pygame.draw.polygon(s, col, pts)
            pygame.draw.polygon(s, shade(col, 1.45), [(cx, cy - r), (cx + r * 0.8, cy - r * 0.2), (cx, cy - r * 0.2)])
            pygame.draw.polygon(s, shade(col, 0.6), pts, 2)
        elif key == "chakra":
            for k, f in enumerate((1.0, 0.68, 0.36)):
                pygame.draw.circle(s, shade(col, 0.7 + 0.3 * k), (cx, cy), max(2, int(r * f)), 0 if k == 2 else 3)
        elif key == "naruto_cloak":
            pts = [(cx - r * 0.5, cy - r), (cx + r * 0.5, cy - r), (cx + r, cy + r), (cx - r, cy + r)]
            pygame.draw.polygon(s, col, pts)
            pygame.draw.polygon(s, shade(col, 0.6), pts, 2)
            pygame.draw.rect(s, shade(col, 1.4), (cx - r * 0.5, cy - r, r, r * 0.3), border_radius=3)
            pygame.draw.line(s, shade(col, 0.6), (cx, cy - r * 0.7), (cx, cy + r), 2)
        elif key == "black_chakra":
            for k in range(8):
                a = k * math.pi / 4
                pygame.draw.line(s, col, (cx, cy), (cx + math.cos(a) * r, cy + math.sin(a) * r), 3)
            pygame.draw.circle(s, (20, 14, 24), (cx, cy), int(r * 0.62))
            pygame.draw.circle(s, col, (cx, cy), int(r * 0.62), 3)
        elif key == "shukaku":
            pygame.draw.circle(s, col, (cx, cy + int(r * 0.2)), int(r * 0.75))
            pygame.draw.circle(s, shade(col, 1.3), (cx, cy - int(r * 0.4)), int(r * 0.45))
            pygame.draw.circle(s, shade(col, 0.6), (cx, cy + int(r * 0.2)), int(r * 0.75), 2)
        elif key == "matatabi":
            for k in range(5):
                a = k * math.pi / 3 - math.pi / 2
                pygame.draw.line(s, col, (cx, cy), (cx + int(math.cos(a) * r), cy + int(math.sin(a) * r)), 3)
            pygame.draw.circle(s, (20, 30, 60), (cx, cy), int(r * 0.6))
            pygame.draw.circle(s, col, (cx, cy), int(r * 0.6), 2)
        elif key == "isobu":
            # Three-Tailed turtle shell fallback shape
            pygame.draw.ellipse(s, shade(col, 0.75), (cx - int(r * 0.85), cy - int(r * 0.65), int(r * 1.7), int(r * 1.3)))
            pygame.draw.ellipse(s, col, (cx - int(r * 0.65), cy - int(r * 0.45), int(r * 1.3), int(r * 0.9)))
            pygame.draw.ellipse(s, shade(col, 1.35), (cx - int(r * 0.85), cy - int(r * 0.65), int(r * 1.7), int(r * 1.3)), 2)
            for k in (-1, 0, 1):
                tx = cx + int(k * r * 0.45)
                pygame.draw.line(s, shade(col, 1.3), (tx, cy + int(r * 0.4)), (tx + int(k * r * 0.2), cy + int(r * 0.95)), 3)
        else:
            pygame.draw.circle(s, col, (cx, cy), r)

    def draw_bag_modal(self):
        g, s = self.g, self.screen
        self.hits = []
        overlay(s, pygame.Rect(0, 0, W, H), (0, 0, 0, 175))
        self.hit(pygame.Rect(0, 0, W, H), g.close_bag)          # click outside the window = close
        box = pygame.Rect(100, 64, 900, 580)
        self.modal_panel(box)
        self.hit(box, lambda: None)                              # clicks inside never reach "close"
        tr = txt(s, "Inventory", 30, AMBER_SOFT, (box.x + 24, box.y + 14), "topleft", True, shadow=True)
        owned = g.owned_items()
        txt(s, f"{len(owned)} item types  |  {g.bag_total():,} items total", 14, DIM, (tr.right + 18, tr.centery), "midleft")
        self.button((box.right - 46, box.y + 10, 36, 32), "X", g.close_bag, True, BTN_DANGER, 16)
        self.draw_search_box((box.x + 24, box.y + 62, 380, 34), g.bag_search)

        q = g.bag_search.strip().lower()
        items = [(k, n) for k, n in owned if q in ITEMS[k]["name"].lower()]
        area = pygame.Rect(box.x + 24, box.y + 110, 560, 446)
        panel(s, area.inflate(8, 8), PANEL_DEEP, (96, 76, 48), 12, 2)
        cols, cw, chh = 4, 136, 124
        rows = math.ceil(len(items) / cols)
        self.bag_scroll = max(0, min(self.bag_scroll, max(0, rows * (chh + 6) - area.h + 6)))
        sel_key = g.bag_selected if g.bag_selected in dict(owned) else (owned[0][0] if owned else None)
        s.set_clip(area)
        for i, (key, qty) in enumerate(items):
            row, col = divmod(i, cols)
            r = pygame.Rect(area.x + 6 + col * cw, area.y + 6 + row * (chh + 6) - self.bag_scroll, cw - 6, chh)
            if not r.colliderect(area):
                continue
            it = ITEMS[key]
            chosen = key == sel_key
            panel(s, r, mix((20, 20, 28), it["color"], 0.2 if chosen else 0.07),
                  it["color"] if chosen else shade(it["color"], 0.6), 10, 3 if chosen else 2, shadow=False)
            self.draw_item_icon(key, r.centerx, r.y + 42, 26)
            txt(s, self._fit(it["name"], 16), 14, TEXT, (r.centerx, r.y + 84), "center", True)
            txt(s, f"x{qty:,}", 16, it["color"], (r.centerx, r.y + 106), "center", True)
            self.hit(r, lambda k=key: g.select_bag_item(k), area)
        if not items:
            txt(s, "No items match your search" if owned else "Your bag is empty", 18, DIM, area.center, "center")
        s.set_clip(None)
        scrollbar(s, area, rows * (chh + 6) + 6, self.bag_scroll)

        dp = pygame.Rect(box.x + 610, box.y + 62, 266, 494)
        panel(s, dp, (20, 20, 28), (96, 76, 48), 12, 2)
        if sel_key is None:
            txt(s, "Select an item to see details", 16, DIM, dp.center, "center")
            return
        it, qty = ITEMS[sel_key], dict(owned)[sel_key]
        icon_bg = pygame.Rect(0, 0, 120, 120)
        icon_bg.center = (dp.centerx, dp.y + 84)
        panel(s, icon_bg, (12, 12, 18), it["color"], 14, 3, glow=(it["color"], 10, 100), shadow=False)
        self.draw_item_icon(sel_key, icon_bg.centerx, icon_bg.centery, 44)
        txt(s, it["name"], 24, it["color"], (dp.centerx, dp.y + 170), "center", True, shadow=True)
        rc = RARITY_COLOR.get(it["rarity"], it["color"])
        badge(s, it["rarity"], 14, rc, (dp.centerx, dp.y + 200), "center")
        txt(s, f"Owned: x{qty:,}", 20, TEXT, (dp.centerx, dp.y + 234), "center", True)
        divider(s, dp.x + 20, dp.right - 20, dp.y + 254)
        txt(s, "Description", 14, DIM, (dp.x + 16, dp.y + 268), "topleft", True)
        for i, line in enumerate(self._wrap(it["desc"], 15, dp.w - 32, 8)):
            txt(s, line, 15, TEXT, (dp.x + 16, dp.y + 292 + i * 20))

    def card(self, rect, ch, t, selected=False, tag=None, small=False, skill_tag=False):
        """Character card: rarity-coloured glow frame, lit portrait well, star row and a name plate."""
        s = self.screen
        rect = pygame.Rect(rect)
        rc = RARITY_COLOR[ch.rarity]
        tier = RARITIES.index(ch.rarity)                         # 0 Common .. 3 Legendary
        gap = 5 if small else 7                                  # keep halos inside the gap between cards
        if selected:
            draw_glow(s, rect, 12, CHAKRA, gap, 140)
        elif tier >= 1:
            pulse = 0.7 + 0.3 * math.sin(t * 4.0) if tier == 3 else 1.0
            draw_glow(s, rect, 12, rc, gap, (70, 100, 135)[tier - 1], pulse)
        body = mix((14, 14, 20), rc, 0.16)
        if selected:
            body = mix(body, CHAKRA, 0.2)
        border = rc if tier >= 1 else (132, 134, 146)
        panel(s, rect, body, border, 12, 3 if tier >= 2 else 2, shadow=False)

        head, foot = (24, 40) if small else (28, 47)
        well = pygame.Rect(rect.x + 6, rect.y + head, rect.w - 12, rect.h - head - foot - 4)
        panel(s, well, mix((8, 8, 12), rc, 0.08), shade(rc, 0.45), 8, 1, shadow=False)
        prev = s.get_clip()
        s.set_clip(well.clip(prev))
        glow = radial_glow(int(max(well.w, well.h) * 0.62), rc, 95 if tier else 60)
        s.blit(glow, (well.centerx - glow.get_width() // 2, well.centery - glow.get_height() // 2 + 4))
        size = 22 if small else 40
        draw_hero(s, ch.tpl, ch.evo_stage, rect.centerx, rect.y + (rect.h * 0.45), size, t, stars=False, aura=False)
        s.set_clip(prev)

        star_row(s, tier + 1, rect.centerx, rect.y + (13 if small else 15), 4.5 if small else 5.5,
                 shade(rc, 1.15) if tier else (190, 192, 202))
        if skill_tag and ch.has_skill:
            badge(s, "Active skill", 11, (255, 235, 140), (rect.centerx, well.bottom - 4), "midbottom", 7, 1)

        plate = pygame.Rect(rect.x + 4, rect.bottom - foot - 3, rect.w - 8, foot)
        panel(s, plate, (10, 10, 15), shade(rc, 0.45), 8, 1, shadow=False)
        txt_fit(s, ch.name, 13 if small else 15, TEXT, (rect.centerx, plate.y + (14 if small else 16)),
                rect.w - 20, "center", True, 10)
        txt(s, f"Lv.{ch.level}  {ch.rarity}" if small else ch.rarity, 12 if small else 13, rc,
            (rect.centerx, plate.bottom - (12 if small else 14)), "center", True)
        if tier >= 2:
            corner_accents(s, rect, rc, 9, 2, 4)
        if tag:
            badge(s, tag, 13, CHAKRA, (rect.x + 7, rect.y + 6), "topleft", 7, 1)

    def draw_gacha(self):
        g, s = self.g, self.screen
        t = pygame.time.get_ticks() / 1000
        lp = pygame.Rect(20, 70, 330, 620)
        self.major(lp)
        txt(s, "Summon Portal", 28, AMBER_SOFT, (lp.centerx, 100), "center", True, shadow=True)
        divider(s, lp.x + 30, lp.right - 30, 122)

        bal = pygame.Rect(40, 138, 290, 38)                       # gem balance
        self.inset(bal)
        draw_gem(s, bal.x + 24, bal.centery, 10)
        txt(s, "Gems", 16, DIM, (bal.x + 44, bal.centery), "midleft", True)
        txt(s, f"{g.gems:,}", 22, GEM_C, (bal.right - 16, bal.centery), "midright", True)

        self.button((40, 192, 290, 64), "Summon x1", g.do_pull_1, g.gems >= SINGLE_COST, BTN_CHAKRA, 22,
                    f"{SINGLE_COST} Gems")
        self.button((40, 268, 290, 64), "Summon x10", g.do_pull_10, g.gems >= MULTI_COST, BTN_PRIMARY, 22,
                    f"{MULTI_COST} Gems")

        dr = pygame.Rect(40, 350, 290, 158)                       # drop rates
        self.inset(dr)
        txt(s, "Drop Rates", 18, TEXT, (dr.x + 16, dr.y + 10), "topleft", True)
        top_rate = max(RARITY_RATE.values())
        for i, r in enumerate(RARITIES):
            y = dr.y + 50 + i * 27
            col = RARITY_COLOR[r]
            draw_star(s, dr.x + 22, y, 6, col, shade(col, 0.45))
            txt(s, r, 16, col, (dr.x + 36, y), "midleft", True)
            hp_bar(s, dr.x + 148, y - 4, 80, 8, RARITY_RATE[r] / top_rate, col)
            txt(s, f"{RARITY_RATE[r]}%", 16, col, (dr.right - 14, y), "midright", True)
        txt(s, "Common/Rare: basic attacks only.", 15, DIM, (40, 524))
        txt(s, "Epic/Legendary: castable skills!", 15, (220, 200, 255), (40, 546))
        txt(s, f"Total pulls: {g.total_pulls}", 16, DIM, (40, 580))
        self.button((40, 630, 290, 40), "Admin System", g.open_admin, True, BTN_NEUTRAL, 17)

        rp = pygame.Rect(370, 70, 710, 620)
        self.major(rp)
        txt(s, "Summon Results", 24, AMBER_SOFT, (rp.centerx, 98), "center", True, shadow=True)
        divider(s, rp.x + 40, rp.right - 40, 120)
        res = g.last_pull
        if not res:
            draw_seal(s, rp.centerx, rp.centery - 20, 112, t)
            txt(s, "Press a summon button to begin!", 22, DIM, (rp.centerx, rp.centery + 130), "center")
            return
        elapsed = pygame.time.get_ticks() / 1000 - g.pull_time
        rows = math.ceil(len(res) / 5)
        for idx, ch in enumerate(res):
            row, col = divmod(idx, 5)
            n_in_row = min(5, len(res) - row * 5)
            x0 = rp.centerx - (n_in_row * 136 - 8) / 2
            r = pygame.Rect(int(x0 + col * 136), 135 + row * 215 + (110 if rows == 1 else 0) - (55 if rows == 1 else 0), 128, 195)
            age = elapsed - idx * 0.15
            if age >= 0:
                self.card(r, ch, t, skill_tag=True)
                if age < 0.3:                                    # reveal flash in the card's rarity colour
                    a = int(150 * (1 - age / 0.3)) // 25 * 25
                    if a > 0:
                        overlay(s, r, (*RARITY_COLOR[ch.rarity], a), 12)
            else:
                panel(s, r, (16, 16, 24), (84, 70, 52), 12, 2, shadow=False)
                dashed_rect(s, r, (70, 58, 44), 8, 6, 1, 8)
                txt(s, "?", 50, (120, 98, 66), r.center, "center", True)

    @staticmethod
    def _wrap(text, size, width, max_lines=5):
        f, lines, cur = font(size), [], ""
        for word in text.split():
            test = (cur + " " + word).strip()
            if f.size(test)[0] <= width or not cur:
                cur = test
            else:
                lines.append(cur)
                cur = word
        if cur:
            lines.append(cur)
        if len(lines) > max_lines:
            lines = lines[:max_lines]
            lines[-1] = lines[-1].rstrip(". ") + "..."
        return lines

    def draw_passive_box(self, ch, rect):
        s = self.screen
        panel(s, rect, (16, 20, 30), (46, 96, 128), 10, 1, shadow=False)
        txt(s, "Passive skill", 12, CHAKRA, (rect.x + 10, rect.y + 7), "topleft", True)
        p = ch.passive
        if p:
            txt_fit(s, p.name, 15, (255, 235, 140), (rect.x + 10, rect.y + 25), rect.w - 20, "topleft", True, 11)
            for i, line in enumerate(self._wrap(p.desc, 13, rect.w - 20)):
                txt(s, line, 13, TEXT, (rect.x + 10, rect.y + 47 + i * 14))
            return
        txt(s, "No passive skill", 15, DIM, (rect.x + 10, rect.y + 30), "topleft", True)

    def _req(self, x, y, w, text, ok, size=13):
        """One requirement line with a status dot (filled green = met, hollow red = missing)."""
        s = self.screen
        col = GOOD if ok else BAD
        if ok:
            pygame.draw.circle(s, col, (x + 5, y + 8), 5)
        else:
            pygame.draw.circle(s, col, (x + 5, y + 8), 5, 2)
        txt_fit(s, text, size, col, (x + 17, y), w - 17, "topleft", False, 10)

    def draw_roster(self):
        g, s = self.g, self.screen
        t = pygame.time.get_ticks() / 1000
        all_chars = sorted(g.roster, key=lambda c: (-RARITIES.index(c.rarity), -c.level, c.name))
        chars = self.filtered(all_chars)
        sel = g.get_char(self.selected) or (chars or all_chars or [None])[0]
        self.selected = sel.uid if sel else None
        area = pygame.Rect(20, 110, 410, 580)
        tr = section_title(s, f"Collection ({self.count_label(len(chars))})", 20, 76, 20)
        self.draw_search_box((tr.right + 14, 70, area.right - tr.right - 14, 32))
        panel(s, area.inflate(8, 8), PANEL_DEEP, (96, 76, 48), 12, 2)
        self.roster_scroll = max(0, min(self.roster_scroll, max(0, len(chars) * 64 - area.h)))
        s.set_clip(area)
        for i, ch in enumerate(chars):
            r = pygame.Rect(area.x + 4, area.y + 4 + i * 64 - self.roster_scroll, area.w - 8, 60)
            if not r.colliderect(area):
                continue
            rc = RARITY_COLOR[ch.rarity]
            chosen = ch is sel
            panel(s, r, mix((20, 20, 28), AMBER, 0.16) if chosen else (22, 22, 30),
                  AMBER if chosen else shade(rc, 0.55), 10, 2, shadow=False)
            pygame.draw.rect(s, rc, (r.x + 4, r.y + 10, 4, r.h - 20), border_radius=2)       # rarity edge
            pc = (r.x + 42, r.centery)
            pygame.draw.circle(s, (12, 12, 18), pc, 24)
            s.set_clip(pygame.Rect(pc[0] - 24, pc[1] - 24, 48, 48).clip(area))
            draw_hero(s, ch.tpl, ch.evo_stage, pc[0], pc[1] + 2, 22, t, stars=False, aura=False)
            s.set_clip(area)
            pygame.draw.circle(s, shade(rc, 0.85), pc, 24, 2)
            txt_fit(s, ch.name, 17, TEXT, (r.x + 78, r.y + 9), r.w - 78 - 84, "topleft", True, 12)
            txt(s, f"{ch.rarity}   Lv.{ch.level}", 15, rc, (r.x + 78, r.y + 33))
            if ch.uid in g.team:
                badge(s, "TEAM", 12, CHAKRA, (r.right - 10, r.y + 7), "topright", 7, 1)
            if ch.evolved:
                badge(s, "AWAKENED", 11, EMBER, (r.right - 10, r.y + 32), "topright", 7, 1)
            self.hit(r, lambda u=ch.uid: setattr(self, "selected", u), area)
        if not chars and g.roster:
            txt(s, "No characters match your search", 18, DIM, area.center, "center")
        s.set_clip(None)
        scrollbar(s, area, len(chars) * 64, self.roster_scroll)

        dp = pygame.Rect(450, 70, 630, 620)
        self.major(dp)
        if not sel:
            txt(s, "No characters yet.", 24, DIM, dp.center, "center")
            return
        ch = sel
        rc = RARITY_COLOR[ch.rarity]
        # portrait stage
        stage = pygame.Rect(468, 84, 152, 172)
        panel(s, stage, mix((8, 8, 12), rc, 0.08), shade(rc, 0.6), 12, 2, glow=(rc, 8, 80), shadow=False)
        prev = s.get_clip()
        s.set_clip(stage.inflate(-4, -4).clip(prev))
        lg = radial_glow(100, ch.color if ch.evolved else rc, 105)
        s.blit(lg, (stage.centerx - 100, stage.centery - 100 + 8))
        draw_hero(s, ch.tpl, ch.evo_stage, stage.centerx, stage.centery + 20, 70, t, stars=False, aura=False)
        s.set_clip(prev)
        star_row(s, RARITIES.index(ch.rarity) + 1, stage.centerx, stage.y + 18, 7, shade(rc, 1.15))
        corner_accents(s, stage, rc, 10, 2, 5)
        # identity
        txt_fit(s, ch.name, 30, ch.color if ch.evolved else TEXT, (650, 92), 410, "topleft", True, 20, True)
        rb = badge(s, ch.rarity, 13, rc, (650, 138), "topleft", 8, 3)
        dmg_col = (255, 140, 80) if ch.tpl.dmg_type == "Physical" else (CHAKRA if ch.tpl.dmg_type == "Magic" else DIM)
        badge(s, ch.tpl.dmg_type, 13, dmg_col, (rb.right + 6, 138), "topleft", 8, 3)
        txt(s, f"Level {ch.level} / {ch.level_cap}", 18, TEXT, (650, 168), "topleft", True)
        hp_bar(s, 650, 192, 170, 8, ch.level / max(1, ch.level_cap), AMBER_DEEP)
        txt(s, "Form: " + (f"Evo Tier {ch.evo_stage}" if ch.evolved else "Base"), 15,
            EMBER if ch.evolved else DIM, (650, 204))
        self.draw_passive_box(ch, pygame.Rect(840, 134, 222, 124))
        self.button((650, 226, 170, 32), "Remove from Team" if ch.uid in g.team else "Add to Team",
                    lambda: g.toggle_team(ch.uid), True, BTN_NEUTRAL, 14)
        # stat table
        cur, nxt = ch.stats(), ch.stats(level=min(ch.level + 1, ch.level_cap))
        evo = ch.stats(evo_stage=ch.evo_stage + 1)
        tb = pygame.Rect(470, 266, 590, 104)
        self.inset(tb)
        for x, lab in ((488, "Stat"), (620, "Now"), (720, "Next Lv"),
                       (840, "Next Evo Tier" if ch.evo_stage < ch.max_evo_stage else "")):
            txt(s, lab, 14, DIM, (x, tb.y + 8), "topleft", True)
        divider(s, tb.x + 14, tb.right - 14, tb.y + 29, (150, 100, 50), False)
        for i, (lab, lc) in enumerate((("HP", GOOD), ("ATK", EMBER), ("DEF", CHAKRA))):
            y = tb.y + 36 + i * 22
            txt(s, lab, 18, lc, (488, y), "topleft", True)
            txt(s, cur[i], 18, TEXT, (620, y), "topleft", True)
            r = txt(s, nxt[i], 18, GOOD if nxt[i] > cur[i] else DIM, (720, y), "topleft", True)
            if nxt[i] > cur[i]:
                txt(s, f"+{nxt[i] - cur[i]}", 13, GOOD, (r.right + 6, y + 4))
            if ch.evo_stage < ch.max_evo_stage:
                txt(s, evo[i], 18, (255, 170, 90), (840, y), "topleft", True)
        # active skill
        sb = pygame.Rect(470, 380, 590, 92)
        panel(s, sb, (28, 24, 22), (130, 100, 40), 10, 1, shadow=False)
        if ch.has_skill:
            pygame.draw.rect(s, (255, 235, 140), (sb.x + 5, sb.y + 10, 4, sb.h - 20), border_radius=2)
            txt(s, "Active skill", 14, (255, 235, 140), (sb.x + 18, sb.y + 8), "topleft", True)
            txt_fit(s, ch.skill.describe(), 15, TEXT, (sb.x + 18, sb.y + 30), sb.w - 36)
            nk = ch.skill_for_stage(ch.evo_stage + 1) if ch.evo_stage < ch.max_evo_stage else None
            if nk:
                txt_fit(s, "Next Evo: " + nk.describe(), 15, (255, 170, 90), (sb.x + 18, sb.y + 56), sb.w - 36)
        else:
            txt(s, "No active skill", 17, DIM, (sb.x + 18, sb.y + 12), "topleft", True)

        # level up
        lb = pygame.Rect(470, 488, 290, 192)
        self.inset(lb)
        txt(s, "Level Up", 20, AMBER_SOFT, (lb.x + 14, lb.y + 10), "topleft", True)
        need_exp, need_gold = ch.level_cost()
        at_cap = ch.level >= ch.level_cap
        if at_cap:
            txt(s, "Max level for this form.", 14, DIM, (lb.x + 14, lb.y + 54))
        else:
            self._req(lb.x + 14, lb.y + 52, lb.w - 28, f"EXP : {g.exp} / {need_exp}", g.exp >= need_exp, 17)
            self._req(lb.x + 14, lb.y + 80, lb.w - 28, f"Gold: {g.gold} / {need_gold}", g.gold >= need_gold, 17)
        self.button((lb.x + 12, lb.bottom - 62, lb.w - 24, 48), "Level Up",
                    lambda: g.level_up(ch), not at_cap and g.exp >= need_exp and g.gold >= need_gold, BTN_GOOD, 20)

        # evolve / awaken
        eb = pygame.Rect(775, 488, 285, 192)
        self.inset(eb)
        txt(s, "Evolve / Awaken", 20, (255, 170, 90), (eb.x + 14, eb.y + 10), "topleft", True)
        if ch.evo_stage >= ch.max_evo_stage:
            txt(s, "Max Evolution Reached!", 16, GOOD, (eb.x + 14, eb.y + 60), "topleft", True)
            self.button((eb.x + 12, eb.bottom - 62, eb.w - 24, 48), "Evolved", lambda: None, False, BTN_PRIMARY, 20)
        else:
            ok_lv = ch.level >= EVO_MIN_LEVEL
            cost = ch.evo_cost()
            if ch.tpl.name == "Sasuke" and ch.evo_stage == 1:
                dupes = g.get_sasuke_duplicates(ch.uid, 1)
                ok_d, ok_g, ok_c = len(dupes) >= 2, g.gold >= 7000, g.chakra >= 20
                ok_bc = g.black_chakra >= 1
                reqs = [(f"Level: {ch.level}/{EVO_MIN_LEVEL} | Sasuke Epic: {len(dupes)}/2", ok_lv and ok_d),
                        (f"Gold: {g.gold}/7000 | Chakra: {g.chakra}/20", ok_g and ok_c),
                        (f"Black Chakra: {g.black_chakra}/1", ok_bc)]
                can_evo = ok_lv and ok_d and ok_g and ok_c and ok_bc
            elif ch.tpl.name == "Sasuke" and ch.evo_stage == 0:
                dupes = g.get_sasuke_duplicates(ch.uid, 0)
                ok_d, ok_g, ok_c = len(dupes) >= 2, g.gold >= 2500, g.chakra >= 15
                reqs = [(f"Level: {ch.level}/{EVO_MIN_LEVEL} | Sasuke: {len(dupes)}/2", ok_lv and ok_d),
                        (f"Gold: {g.gold}/2500 | Chakra: {g.chakra}/15", ok_g and ok_c)]
                can_evo = ok_lv and ok_d and ok_g and ok_c
            elif ch.tpl.name == "Naruto" and ch.evo_stage == 1:       # Sage Naruto -> Kurama Link Naruto
                dupes = g.get_naruto_duplicates(ch.uid, NARUTO_EVO2_DUPLICATE_STAGE)
                ok_d, ok_g = len(dupes) >= cost["duplicates"], g.gold >= cost["gold"]
                ok_c, ok_bc, ok_nc = (g.chakra >= cost["chakra"], g.black_chakra >= cost["black_chakra"],
                                      g.naruto_cloak >= cost["naruto_cloak"])
                reqs = [(f"Level: {ch.level}/{EVO_MIN_LEVEL} | Sage Naruto (Epic): {len(dupes)}/{cost['duplicates']}",
                         ok_lv and ok_d),
                        (f"Gold: {g.gold}/{cost['gold']} | Chakra: {g.chakra}/{cost['chakra']}", ok_g and ok_c),
                        (f"Black Chakra: {g.black_chakra}/{cost['black_chakra']} | "
                         f"Naruto Cloak: {g.naruto_cloak}/{cost['naruto_cloak']}", ok_bc and ok_nc)]
                can_evo = ok_lv and ok_d and ok_g and ok_c and ok_bc and ok_nc
            elif ch.tpl.name == "Naruto":
                dupes = g.get_naruto_duplicates(ch.uid)
                ok_d, ok_g, ok_c = len(dupes) >= 2, g.gold >= 2000, g.chakra >= 10
                reqs = [(f"Level: {ch.level}/{EVO_MIN_LEVEL} | Naruto: {len(dupes)}/2", ok_lv and ok_d),
                        (f"Gold: {g.gold}/2000 | Chakra: {g.chakra}/10", ok_g and ok_c)]
                can_evo = ok_lv and ok_d and ok_g and ok_c
            elif ch.tpl.name == "Sakura":
                ok_g, ok_c = g.gold >= cost["gold"], g.chakra >= cost["chakra"]
                reqs = [(f"Level: {ch.level}/{EVO_MIN_LEVEL}", ok_lv),
                        (f"Gold: {g.gold}/{cost['gold']} | Chakra: {g.chakra}/{cost['chakra']}", ok_g and ok_c)]
                can_evo = ok_lv and ok_g and ok_c
            else:
                stones, gold = cost["stones"], cost["gold"]
                ok_s, ok_g = g.stones >= stones, g.gold >= gold
                reqs = [(f"Level: {ch.level}/{EVO_MIN_LEVEL} | Stones: {g.stones}/{stones}", ok_lv and ok_s),
                        (f"Gold: {g.gold}/{gold}", ok_g)]
                can_evo = ok_lv and ok_s and ok_g
            for i, (text, ok) in enumerate(reqs):
                self._req(eb.x + 14, eb.y + 42 + i * 24, eb.w - 28, text, ok)

            target_name = ch.tpl.evo2_name if ch.evo_stage == 1 else ch.tpl.evo_name
            self.button((eb.x + 12, eb.bottom - 62, eb.w - 24, 48), f"Evolve -> {target_name}",
                        lambda: g.evolve(ch), can_evo, BTN_PRIMARY, 15)

    def draw_team(self):
        g, s = self.g, self.screen
        t = pygame.time.get_ticks() / 1000
        tr = section_title(s, f"Active Battle Team ({len(g.team)}/{TEAM_SIZE})", 20, 74, 20)
        txt(s, "click a slot to remove, click a card below to add", 15, DIM, (tr.right + 14, 78))
        for i in range(TEAM_SIZE):
            r = pygame.Rect(20 + i * 355, 108, 340, 150)
            ch = g.get_char(g.team[i]) if i < len(g.team) else None
            if ch:
                rc = RARITY_COLOR[ch.rarity]
                panel(s, r, mix((16, 16, 24), rc, 0.14), rc, 14, 3, glow=(rc, 8, 70), corners=rc)
                stage = pygame.Rect(r.x + 12, r.y + 12, 118, 126)
                panel(s, stage, mix((8, 8, 12), rc, 0.08), shade(rc, 0.5), 10, 1, shadow=False)
                prev = s.get_clip()
                s.set_clip(stage.clip(prev))
                lg = radial_glow(78, rc, 100)
                s.blit(lg, (stage.centerx - 78, stage.centery - 78 + 6))
                draw_hero(s, ch.tpl, ch.evo_stage, stage.centerx, stage.centery + 6, 46, t, stars=False, aura=False)
                s.set_clip(prev)
                star_row(s, RARITIES.index(ch.rarity) + 1, stage.centerx, stage.y + 14, 5, shade(rc, 1.15))
                badge(s, f"Slot {i + 1}", 12, CHAKRA, (stage.x + 6, stage.bottom - 6), "bottomleft", 7, 1)
                txt_fit(s, ch.name, 20, TEXT, (r.x + 142, r.y + 14), r.right - 14 - (r.x + 142), "topleft", True, 13, True)
                txt(s, f"{ch.rarity}  Lv.{ch.level}", 16, rc, (r.x + 142, r.y + 42), "topleft", True)
                hp, atk, df = ch.stats()
                x = r.x + 142
                for lab, val, lc in (("HP", hp, GOOD), ("ATK", atk, EMBER), ("DEF", df, CHAKRA)):
                    rr = txt(s, f"{lab} {val}", 14, lc, (x, r.y + 69), "topleft", True)
                    x = rr.right + 9
                txt_fit(s, ("Skill: " + ch.skill.name) if ch.has_skill else "Basic attacks only", 15,
                        (255, 235, 140) if ch.has_skill else DIM, (r.x + 142, r.y + 94), r.right - 14 - (r.x + 142))
                txt(s, "Click to remove", 13, DIM, (r.x + 142, r.y + 124))
                self.hit(r, lambda u=ch.uid: g.toggle_team(u))
            else:
                panel(s, r, (16, 16, 24), (70, 58, 44), 14, 2)
                dashed_rect(s, r, (84, 70, 52), 10, 7, 2, 8)
                pygame.draw.line(s, (96, 80, 58), (r.centerx - 12, r.centery - 18), (r.centerx + 12, r.centery - 18), 3)
                pygame.draw.line(s, (96, 80, 58), (r.centerx, r.centery - 30), (r.centerx, r.centery - 6), 3)
                txt(s, f"Empty Slot {i + 1}", 20, (110, 100, 120), (r.centerx, r.centery + 16), "center", True)
        chars = self.filtered(sorted(g.roster, key=lambda c: (-RARITIES.index(c.rarity), -c.level, c.name)))
        area = pygame.Rect(20, 300, 1060, 390)
        tr = section_title(s, f"Roster ({self.count_label(len(chars))})", 20, 268, 20)
        self.draw_search_box((tr.right + 14, 264, 300, 30))
        panel(s, area.inflate(8, 8), PANEL_DEEP, (96, 76, 48), 12, 2)
        cols, cw, chh = 8, 130, 128
        rows = math.ceil(len(chars) / cols)
        self.team_scroll = max(0, min(self.team_scroll, max(0, rows * (chh + 6) - area.h + 6)))
        s.set_clip(area)
        for i, ch in enumerate(chars):
            row, col = divmod(i, cols)
            r = pygame.Rect(area.x + 6 + col * cw, area.y + 6 + row * (chh + 6) - self.team_scroll, cw - 6, chh)
            if not r.colliderect(area):
                continue
            in_team = ch.uid in g.team
            self.card(r, ch, t, selected=in_team, tag=f"#{g.team.index(ch.uid) + 1}" if in_team else None, small=True)
            self.hit(r, lambda u=ch.uid: g.toggle_team(u), area)
        if not chars and g.roster:
            txt(s, "No characters match your search", 20, DIM, area.center, "center")
        s.set_clip(None)
        scrollbar(s, area, rows * (chh + 6) + 6, self.team_scroll)

    @staticmethod
    def _fit(text, n):
        return text if len(text) <= n else text[:n - 1] + "."

    def draw_stage_selector(self, info, m):
        """[<<] [<] Stage X (Unlocked: Max Stage Y) [>] [>>] [Latest] + stage type banner."""
        g, s = self.g, self.screen
        y = info.y + 70
        can_dec, can_inc = g.stage > 1, g.stage < g.max_stage
        self.button((info.x + 16, y, 40, 30), "<<", lambda: g.change_stage(-10), can_dec, BTN_NEUTRAL, 16)
        self.button((info.x + 62, y, 40, 30), "<", lambda: g.change_stage(-1), can_dec, BTN_NEUTRAL, 16)
        txt_fit(s, f"Stage {g.stage} (Unlocked: Max Stage {g.max_stage})", 16, TEXT, (info.x + 112, y + 15), 278,
                "midleft", True, 12)
        self.button((info.x + 400, y, 40, 30), ">", lambda: g.change_stage(1), can_inc, BTN_NEUTRAL, 16)
        self.button((info.x + 446, y, 40, 30), ">>", lambda: g.change_stage(10), can_inc, BTN_NEUTRAL, 16)
        self.button((info.x + 494, y, 100, 30), "Latest", lambda: g.set_stage(g.max_stage), can_inc, BTN_GOOD, 15)
        by = info.y + 104
        if is_boss_stage(g.stage):
            cx, cy = info.x + 28, by + 10
            pygame.draw.polygon(s, GOLD_C, [(cx - 11, cy + 8), (cx - 11, cy - 6), (cx - 5, cy), (cx, cy - 9),
                                            (cx + 5, cy), (cx + 11, cy - 6), (cx + 11, cy + 8)])
            txt(s, f"STAGE {g.stage} - SOLO BOSS!", 17, (255, 110, 90), (info.x + 46, by), "topleft", True)
            txt(s, "1 wave, 1 boss, no minions", 14, DIM, (info.x + 330, by + 2))
        else:
            txt(s, f"Normal stage: {MAX_WAVES} waves, boss on the last wave. "
                   f"Next Solo Boss: Stage {(g.stage // BOSS_STAGE_INTERVAL + 1) * BOSS_STAGE_INTERVAL}",
                14, DIM, (info.x + 16, by + 2))

    def draw_map_select(self, arena, t):
        g, s = self.g, self.screen
        txt(s, "Select Map", 22, AMBER_SOFT, (arena.x + 20, arena.y + 12), "topleft", True, shadow=True)
        for i, m in enumerate(MAPS[:3]):
            r = pygame.Rect(arena.x + 20 + i * 340, arena.y + 44, 330, 84)
            sel = g.selected_map == m["id"]
            hover = r.collidepoint(pygame.mouse.get_pos())
            panel(s, r, mix(PANEL_DEEP, m["bg"], 0.95 if hover else 0.75), m["accent"] if sel else (96, 76, 48), 12,
                  3 if sel else 2, glow=(m["accent"], 9, 110) if sel else None, shadow=False)
            pygame.draw.rect(s, m["accent"], (r.x + 5, r.y + 12, 4, r.h - 24), border_radius=2)
            txt_fit(s, f"Map {i + 1}: {m['name']}", 20, TEXT, (r.x + 20, r.y + 9), r.w - 130, "topleft", True, 14)
            ms = g.map_stage[m["id"]]
            txt(s, f"Stage {ms['selected_stage']}  (Max Stage {ms['max_unlocked_stage']})", 15, m["accent"],
                (r.x + 20, r.y + 36))
            names = []
            for d in m["drops"]:
                n = ITEMS[d["item"]]["short"]
                if n not in names:
                    names.append(n)
            txt_fit(s, "Drops: " + ", ".join(names), 14, DIM, (r.x + 20, r.y + 58), r.w - 34, "topleft", False, 12)
            if sel:
                badge(s, "SELECTED", 12, m["accent"], (r.right - 12, r.y + 10), "topright", 7, 1)
            self.hit(r, lambda mid=m["id"]: g.select_map(mid))
        info = pygame.Rect(arena.x + 20, arena.y + 146, 690, 240)
        panel(s, info, (14, 14, 20), (96, 76, 48), 12, 2, shadow=False)
        m = g.current_map
        if m is None:
            txt(s, "Choose a map above to see its description and drop list.", 18, DIM, info.center, "center")
        else:
            txt(s, m["name"], 26, m["accent"], (info.x + 16, info.y + 10), "topleft", True, shadow=True)
            txt_fit(s, m["desc"], 15, DIM, (info.x + 16, info.y + 46), info.w - 32, "topleft", False, 12)
            self.draw_stage_selector(info, m)
            boss = is_boss_stage(g.stage)
            txt(s, f"Drop List - Stage {g.stage}" + ("  (boss bonus!)" if boss else "  (rolled when you win)"),
                16, (255, 130, 100) if boss else TEXT, (info.x + 16, info.y + 126), "topleft", True)
            drop_rows = stage_drop_table(m, g.stage)
            row_h = max(16, min(22, (info.h - 152 - 8) // max(1, len(drop_rows))))     # always ends 8px above the border
            for i, d in enumerate(drop_rows):
                it = ITEMS[d["item"]]
                y = info.y + 152 + i * row_h
                if i % 2 == 0:
                    overlay(s, pygame.Rect(info.x + 8, y - 2, info.w - 16, row_h), (255, 255, 255, 10), 6)
                lo, hi = d["lo"], d["hi"]
                qty = f"x{lo}" if lo == hi else f"x{lo}-{hi}"
                pct = d["chance"] * 100
                txt(s, f"[{it['rarity']}]", 15, it["color"], (info.x + 16, y), "topleft", True)
                txt(s, it["name"] + (f" ({d['note']})" if d["note"] else ""), 16, it["color"], (info.x + 120, y))
                txt(s, f"{pct:.1f}%" if pct < 10 else f"{round(pct)}%", 16, (255, 130, 100) if d["boosted"] else TEXT,
                    (info.x + 360, y), "topleft", d["boosted"])
                txt(s, qty, 16, (255, 130, 100) if d["boosted"] else TEXT, (info.x + 440, y), "topleft", d["boosted"])
                txt(s, f"Owned: {getattr(g, d['item'])}", 15, DIM, (info.right - 16, y), "topright")
        tp = pygame.Rect(arena.x + 740, arena.y + 146, 300, 150)
        panel(s, tp, (14, 14, 20), (96, 76, 48), 12, 2, shadow=False)
        txt(s, "Your Team", 16, AMBER_SOFT, (tp.x + 12, tp.y + 8), "topleft", True)
        team = g.team_chars()
        if not team:
            txt(s, "Team is empty - go to the Team tab!", 15, BAD, tp.center, "center")
        for i, ch in enumerate(team):
            cx = tp.x + 52 + i * 98
            rc = RARITY_COLOR[ch.rarity]
            pygame.draw.circle(s, (10, 10, 16), (cx, tp.y + 78), 38)
            prev = s.get_clip()
            s.set_clip(pygame.Rect(cx - 38, tp.y + 40, 76, 76).clip(prev))
            draw_hero(s, ch.tpl, ch.evo_stage, cx, tp.y + 78, 28, t, stars=False, aura=False)
            s.set_clip(prev)
            pygame.draw.circle(s, shade(rc, 0.85), (cx, tp.y + 78), 38, 2)
            txt(s, self._fit(ch.name, 13), 12, TEXT, (cx, tp.y + 124), "center", True)
            txt(s, f"Lv.{ch.level}", 12, rc, (cx, tp.y + 138), "center")
        if m is None:
            self.button((tp.x, tp.bottom + 14, tp.w, 66), "Select a Map", lambda: None, False, BTN_PRIMARY, 22)
        else:
            self.button((tp.x, tp.bottom + 14, tp.w, 66), "Start Battle", g.start_battle, bool(team),
                        BTN_PRIMARY, 24, sub=f"{m['name']} - Stage {g.stage}" + (" (BOSS)" if is_boss_stage(g.stage) else ""))

    @staticmethod
    def _ward_strength(u):
        """0..1 opacity factor of Kurama's aura: quick fade-in, fade-out over the last second."""
        fade_in = (KURAMA_WARD_DURATION - u.ward_timer) / 0.4 + 0.15
        return max(0.0, min(1.0, u.ward_timer / 1.0, fade_in))

    def draw_battle(self):
        g, s = self.g, self.screen
        b = g.battle
        t = pygame.time.get_ticks() / 1000
        arena = pygame.Rect(20, 62, 1060, 400)
        theme = b.map if b else (g.current_map or DEFAULT_THEME)
        panel(s, arena, theme["bg"], (150, 104, 52), 12, 2, flat=True, glow=(AMBER_DEEP, 6, 40), shadow=False)
        if b:
            pygame.draw.rect(s, theme["floor"], (arena.x + 2, 395, arena.w - 4, 65))
            for i in range(8):
                pygame.draw.line(s, theme["line"], (arena.x + i * 150, 395), (arena.x + i * 150 - 60, 460), 1)
        corner_accents(s, arena, AMBER, 14, 2, 4)
        ox = oy = 0
        if b and b.shake > 0:
            ox, oy = random.randint(-5, 5), random.randint(-5, 5)
        s.set_clip(arena)
        if b is None:
            self.draw_map_select(arena, t)
            s.set_clip(None)
        else:
            if b.boss_stage:
                title, tcol = f"{b.map['name']}  -  Stage {b.stage}  -  SOLO BOSS!", (255, 120, 90)
            else:
                title, tcol = f"{b.map['name']}  -  Stage {b.stage}   Wave {min(b.wave, b.max_waves)}/{b.max_waves}", TEXT
            overlay(s, pygame.Rect(arena.centerx - font(22, True).size(title)[0] // 2 - 18, 68,
                                   font(22, True).size(title)[0] + 36, 30), (0, 0, 0, 120), 15)
            txt(s, title, 22, tcol, (arena.centerx, 83), "center", True, shadow=True)
            for u in b.enemies + b.players:
                stunned = getattr(u, "stun_timer", 0.0) > 0
                dash = b.dash_pos(u)
                if dash:                       # Melee dash-attack (Sakura or Yagura Karatachi)
                    px, py = dash[0], dash[1] + (0.0 if stunned else math.sin(b.time * 3 + u.y) * 1.5)
                else:
                    if u.is_player:
                        px = u.x + math.sin(min(u.lunge, 0.25) / 0.25 * math.pi) * 40 * (1 if u.lunge else 0)
                    else:
                        px = u.x - math.sin(min(u.lunge, 0.25) / 0.25 * math.pi) * 40 * (1 if u.lunge else 0)
                    py = u.y + (0.0 if stunned else math.sin(b.time * 3 + u.y) * 3)
                px, py = px + ox, py + oy
                if not u.alive:
                    if u.is_player:
                        draw_hero(s, u.tpl, u.evo_stage, px, py, 50, b.time)
                        overlay(s, pygame.Rect(px - 50, py - 55, 100, 120), (0, 0, 0, 170))
                        txt(s, "KO", 26, BAD, (px, py), "center", True)
                    continue
                if u.is_player:
                    # Kurama Link Naruto: naruto_attack.png plays as his body while he dashes in, punches, returns
                    if not (dash and u.kurama and not stunned and NARUTO_ATTACK_SHEET_MODE == "body"
                            and draw_naruto_attack(s, px, py, dash[2])):
                        draw_hero(s, u.tpl, u.evo_stage, px, py, 56, b.time, stunned=stunned)
                    if u.ward_timer > 0:       # Kurama's Cloak: faded chakra aura around every ally
                        draw_kurama_aura(s, px, py, 56, b.time, self._ward_strength(u))
                    if stunned:
                        overlay(s, pygame.Rect(px - 38, py - 46, 76, 94), (160, 160, 175, 85), 24)
                else:
                    draw_enemy(s, u.name, u.color, px, py, 70 if u.boss else 46, u.boss, b.time,
                               world_boss=u.world_boss, shield_timer=u.shield_timer,
                               is_miniboss=bool(u.miniboss))
                if u.flash > 0:
                    overlay(s, pygame.Rect(px - 40, py - 45, 80, 100), (255, 255, 255, 120), 30)
                bw = 100 if u.boss else 84
                top = py - (78 if u.is_player else (66 if u.boss else 48))
                if u.shield_timer > 0:
                    txt(s, f"SAND SHIELD {u.shield_timer:.1f}s (-25% DMG)", 12, (235, 195, 95), (px, top - 28), "center", True)
                if u.is_player and u.ward_timer > 0:
                    txt(s, f"KURAMA WARD {u.ward_timer:.1f}s (-{int(round(u.ward_pct * 100))}% DMG)", 12,
                        KURAMA_COLOR, (px, top - 28), "center", True)
                txt(s, u.name, 13, (185, 185, 195) if stunned else TEXT, (px, top - 14), "center", True, shadow=True)
                bar_col = (165, 165, 180) if stunned else ((80, 220, 110) if u.is_player else (230, 80, 80))
                hp_bar(s, px - bw // 2, top, bw, 9, u.hp / u.max_hp, bar_col)
                if getattr(u, "burn", None):
                    draw_burn_status(s, px, py, b.time, 50)
                    txt(s, f"BURN x{u.burn['ticks']}", 12, BURN_COLOR, (px, top + 12), "midtop", True)
                if getattr(u, "han_user", False) and u.def_stacks > 0:
                    txt(s, f"STEAM ARMOR x{u.def_stacks}  DEF {u.df}", 12, HAN_DEF_COLOR,
                        (px, top - 28), "center", True)
                if stunned:
                    txt(s, f"[STUN {u.stun_timer:.1f}s]", 12, (200, 200, 215), (px + bw // 2 + 6, top + 4), "midleft", True)
            for c in b.clones:
                if not c.alive:
                    continue
                c_stunned = getattr(c, "stun_timer", 0.0) > 0
                px = c.x + math.sin(min(c.lunge, 0.25) / 0.25 * math.pi) * 40 * (1 if c.lunge else 0) + ox
                py = c.y + (0.0 if c_stunned else math.sin(b.time * 3 + c.y + 1) * 3) + oy
                cimg = assets.get_shadow_clone_image(int(44 * 1.7), 0.0 if c_stunned else b.time)
                if cimg:
                    if c_stunned:
                        cimg = _stone_tint_surface(cimg)
                    s.blit(cimg, cimg.get_rect(center=(int(px), int(py))))
                else:
                    draw_hero(s, c.tpl, 0, px, py, 44, b.time, stunned=c_stunned)
                if c.ward_timer > 0:
                    draw_kurama_aura(s, px, py, 44, b.time, self._ward_strength(c))
                if c.flash > 0:
                    overlay(s, pygame.Rect(px - 32, py - 38, 64, 84), (255, 255, 255, 120), 24)
                top = py - 66
                txt(s, f"{c.name} {max(0, c.life):.0f}s", 12, (180, 180, 190) if c_stunned else (150, 200, 255), (px, top - 13), "center", True)
                hp_bar(s, px - 30, top, 60, 6, c.hp / c.max_hp, (165, 165, 180) if c_stunned else (120, 180, 255))
                if getattr(c, "burn", None):
                    draw_burn_status(s, px, py, b.time, 44)
                    txt(s, f"BURN x{c.burn['ticks']}", 11, BURN_COLOR, (px, top + 9), "midtop", True)
                if c_stunned:
                    txt(s, "[STUN]", 11, (200, 200, 215), (px + 34, top + 3), "midleft", True)
            for e in b.fx:
                if "delay" in e and e["delay"] > 0:
                    continue
                f = e["life"] / e["dur"]
                if e["t"] == "kunai":
                    cur_x = e["tx"] - (e["tx"] - e["x"]) * f
                    cur_y = e["ty"] - (e["ty"] - e["y"]) * f
                    k_img = assets.get_kunai_image(size=28)
                    if k_img:
                        s.blit(k_img, k_img.get_rect(center=(int(cur_x), int(cur_y))))
                    else:
                        pygame.draw.circle(s, (220, 220, 220), (int(cur_x), int(cur_y)), 5)
                elif e["t"] == "rasen_shuriken":
                    cur_x = e["tx"] - (e["tx"] - e["x"]) * f
                    cur_y = e["ty"] - (e["ty"] - e["y"]) * f
                    rs_img = assets.get_rasen_shuriken_frame(time_sec=t, size=75)
                    if rs_img:
                        s.blit(rs_img, rs_img.get_rect(center=(int(cur_x), int(cur_y))))
                    else:
                        pygame.draw.circle(s, (100, 200, 255), (int(cur_x), int(cur_y)), 18)
                elif e["t"] == "fire_ball":
                    cur_x = e["tx"] - (e["tx"] - e["x"]) * f
                    cur_y = e["ty"] - (e["ty"] - e["y"]) * f
                    fb_img = assets.get_fire_ball_frame(time_sec=t, size=70)
                    if fb_img:
                        s.blit(fb_img, fb_img.get_rect(center=(int(cur_x), int(cur_y))))
                    else:
                        pygame.draw.circle(s, (255, 100, 30), (int(cur_x), int(cur_y)), 20)
                elif e["t"] == "chidori":
                    cur_x = e["tx"] - (e["tx"] - e["x"]) * f
                    cur_y = e["ty"] - (e["ty"] - e["y"]) * f
                    cd_img = assets.get_chidori_image(size=85)
                    if cd_img:
                        s.blit(cd_img, cd_img.get_rect(center=(int(cur_x), int(cur_y))))
                    else:
                        pygame.draw.circle(s, (120, 220, 255), (int(cur_x), int(cur_y)), 24)
                elif e["t"] == "amaterasu_burn":
                    ama_img = assets.get_amaterasu_frame(time_sec=t, size=65)
                    if ama_img:
                        s.blit(ama_img, ama_img.get_rect(center=(int(e["x"]), int(e["y"]))))
                    else:
                        pygame.draw.circle(s, (180, 40, 220), (int(e["x"]), int(e["y"])), 18)
                elif e["t"] == "sand_hand":
                    progress = 1.0 - f
                    anim_t = 0.0 if progress < 0.5 else 0.1
                    sh_img = assets.get_enemy_skill_sheet_frame("sand_hand.png", num_frames=2, time_sec=anim_t, size=90)
                    rise_y = int((1.0 - min(1.0, progress * 2.2)) * 26)
                    cx, cy = int(e["x"] + ox), int(e["y"] + oy + rise_y)
                    if sh_img is not None:
                        s.blit(sh_img, sh_img.get_rect(center=(cx, cy)))
                    else:
                        base_y = int(e["y"] + oy + 36)
                        for k, dx in enumerate((-24, -8, 8, 24)):
                            claw_h = int((56 + (10 if k in (1, 2) else 0)) * min(1.0, progress * 1.8))
                            grip = int((10 if progress >= 0.5 else 0) * (-1 if dx > 0 else 1))
                            pts = [
                                (cx + dx - 7, base_y),
                                (cx + dx + 7, base_y),
                                (cx + dx + grip, base_y - claw_h),
                            ]
                            pygame.draw.polygon(s, (215, 175, 80), pts)
                            pygame.draw.polygon(s, (245, 215, 125), pts, 2)
                        pygame.draw.ellipse(s, (185, 145, 60), (cx - 34, base_y - 8, 68, 16))
                elif e["t"] == "nii_basic_attack":
                    progress = 1.0 - f
                    frame_idx = min(3, int(progress * 4))
                    atk_img = assets.get_nii_attack_frame(frame_idx=frame_idx, size=95)
                    cx, cy = int(e["x"] + ox), int(e["y"] + oy)
                    if atk_img is not None:
                        s.blit(atk_img, atk_img.get_rect(center=(cx, cy)))
                    else:
                        pygame.draw.circle(s, (80, 160, 255), (cx, cy), 22)
                elif e["t"] == "nii_slash_animation":
                    progress = 1.0 - f
                    frame_idx = min(3, int(progress * 4))
                    anim_img = assets.get_blue_slash_animation_frame(frame_idx=frame_idx, size=115)
                    cx, cy = int(e["x"] + ox), int(e["y"] + oy)
                    if anim_img is not None:
                        s.blit(anim_img, anim_img.get_rect(center=(cx, cy)))
                    else:
                        pygame.draw.circle(s, (80, 190, 255), (cx, cy), 30)
                elif e["t"] == "blue_slash":
                    cur_x = e["tx"] - (e["tx"] - e["x"]) * f
                    cur_y = e["ty"] - (e["ty"] - e["y"]) * f
                    progress = 1.0 - f
                    frame_idx = min(1, int(progress * 2))
                    bs_img = assets.get_blue_slash_projectile_frame(frame_idx=frame_idx, size=75)
                    if bs_img:
                        s.blit(bs_img, bs_img.get_rect(center=(int(cur_x), int(cur_y))))
                    else:
                        pygame.draw.circle(s, (80, 180, 255), (int(cur_x), int(cur_y)), 18)
                elif e["t"] == "enemy_skill":
                    cur_x = e["tx"] - (e["tx"] - e["x"]) * f
                    cur_y = e["ty"] - (e["ty"] - e["y"]) * f
                    es_img = assets.get_enemy_skill_image(e["img_name"], size=35)
                    if es_img:
                        s.blit(es_img, es_img.get_rect(center=(int(cur_x), int(cur_y))))
                    else:
                        pygame.draw.circle(s, (255, 100, 50), (int(cur_x), int(cur_y)), 8)
                elif e["t"] == "magma_shot":
                    cur_x = e["tx"] - (e["tx"] - e["x"]) * f
                    cur_y = e["ty"] - (e["ty"] - e["y"]) * f
                    draw_magma_shot(s, cur_x, cur_y, e["tx"], e["ty"], 46, t)
                elif e["t"] == "super_magma_shot":
                    cur_x = e["tx"] - (e["tx"] - e["x"]) * f
                    cur_y = e["ty"] - (e["ty"] - e["y"]) * f
                    draw_super_magma_shot(s, cur_x, cur_y, e["tx"], e["ty"], 96, t)
                elif e["t"] == "roushi_cast":
                    draw_roushi_cast(s, e["x"] + ox, e["y"] + oy, 1.0 - f, 150)
                elif e["t"] == "han_steam_shot":
                    cur_x = e["tx"] - (e["tx"] - e["x"]) * f
                    cur_y = e["ty"] - (e["ty"] - e["y"]) * f
                    draw_han_steam_shot(s, cur_x + ox, cur_y + oy, e["tx"] + ox, e["ty"] + oy, 64, t)
                elif e["t"] == "han_cast":
                    draw_han_cast(s, e["x"] + ox, e["y"] + oy, 1.0 - f, 150)
                elif e["t"] == "kurama_cast":
                    draw_kurama_cast(s, e["x"] + ox, e["y"] + oy, 1.0 - f, 150)
                elif e["t"] == "naruto_rasengan":
                    cur_x = e["tx"] - (e["tx"] - e["x"]) * f
                    cur_y = e["ty"] - (e["ty"] - e["y"]) * f
                    draw_naruto_rasengan(s, cur_x + ox, cur_y + oy, e["tx"] + ox, e["ty"] + oy, 90, t)
                elif e["t"] == "heal_pulse":
                    draw_heal_pulse(s, e["x"] + ox, e["y"] + oy, f, 60)
                elif e["t"] == "beam":
                    pygame.draw.line(s, e["c"], e["a"], e["b"], max(1, int(e["w"] * f)))
                    pygame.draw.circle(s, shade(e["c"], 1.4), (int(e["b"][0]), int(e["b"][1])), max(2, int(e["w"] * f)))
                elif e["t"] == "ring":
                    pygame.draw.circle(s, e["c"], (int(e["x"]), int(e["y"])), max(2, int(e["r"] * (1 - f))), max(1, int(e["w"] * f)))
                elif e["t"] == "spark":
                    pygame.draw.circle(s, e["c"], (int(e["x"]), int(e["y"])), max(1, int(4 * f)))
            for u in b.players:                # melee punch impact on the target during the strike
                dash = b.dash_pos(u)
                if dash and 0.30 <= dash[2] < 0.65 and u.punch_tgt is not None:
                    if u.kurama:               # Naruto: sheet is his body (default) or the impact effect
                        if NARUTO_ATTACK_SHEET_MODE == "impact":
                            draw_naruto_attack(s, u.punch_tgt.x - 30 + ox, u.punch_tgt.y + oy, dash[2], 90)
                        continue
                    idx = min(2, int((dash[2] - 0.30) / 0.35 * 3))      # Sakura: frames 0-2 during the strike
                    draw_punch(s, u.punch_tgt.x - 30 + ox, u.punch_tgt.y + oy, idx, 80)
            for p in b.popups:
                txt(s, p["text"], p["size"], p["color"], (p["x"] + ox, p["y"] + oy), "center", True, shadow=True)
            if b.wave_delay > 0:
                txt(s, "Next wave incoming...", 24, (255, 220, 140), (arena.centerx, 262), "center", True, shadow=True)
            s.set_clip(None)


        units = b.players if b else None
        team = g.team_chars()
        for i in range(TEAM_SIZE):
            r = pygame.Rect(20 + i * 262, 474, 252, 158)
            if units is not None and i < len(units):
                u = units[i]
                ch, name, hp, mhp = u.char, u.name, u.hp, u.max_hp
            elif units is None and i < len(team):
                ch = team[i]
                name, hp = ch.name, ch.stats()[0]
                mhp = hp
            else:
                panel(s, r, (18, 18, 26), (70, 58, 44), 12, 2)
                txt(s, "Empty slot", 17, (96, 92, 112), r.center, "center")
                continue
            rc = RARITY_COLOR[ch.rarity]
            panel(s, r, PANEL, shade(rc, 0.7), 12, 2)
            pygame.draw.rect(s, rc, (r.x + 3, r.y + 12, 4, 40), border_radius=2)             # rarity edge
            txt_fit(s, name, 17, rc, (r.x + 14, r.y + 8), r.w - 100, "topleft", True, 12, True)
            txt(s, f"Lv.{ch.level}  [{i + 1}]", 14, DIM, (r.right - 10, r.y + 10), "topright")
            frac = hp / mhp
            hp_bar(s, r.x + 10, r.y + 36, r.w - 20, 14, frac,
                   (80, 220, 110) if frac > 0.5 else ((240, 170, 60) if frac > 0.25 else (235, 80, 80)))
            txt(s, f"{int(hp)}/{mhp}", 12, TEXT, (r.centerx, r.y + 43), "center", True, shadow=True)
            br = pygame.Rect(r.x + 10, r.y + 62, r.w - 20, 84)
            if ch.has_skill:
                sk = ch.skill
                ready = units is not None and b.skill_ready(units[i])
                can = units is not None and b.can_cast(units[i])
                if ready:
                    draw_glow(s, br, 10, sk.color, 8, 130, 0.65 + 0.35 * math.sin(pygame.time.get_ticks() / 180))
                panel(s, br, shade(sk.color, 0.5) if ready else (28, 28, 38), sk.color if ready else (84, 80, 96), 10,
                      3 if ready else 2, shadow=False)
                txt(s, sk.name, 16, TEXT, (br.centerx, br.y + 16), "center", True, shadow=True)
                txt(s, sk.brief(), 13, DIM if not ready else (225, 220, 210), (br.centerx, br.y + 40), "center")
                if units is not None:
                    u = units[i]
                    if not u.alive:
                        overlay(s, br, (0, 0, 0, 190), 10)
                        txt(s, "KO", 20, BAD, br.center, "center", True)
                    elif getattr(u, "stun_timer", 0.0) > 0:
                        overlay(s, br, (60, 60, 70, 195), 10)
                        txt(s, f"STUNNED {u.stun_timer:.1f}s", 18, (200, 200, 215), br.center, "center", True)
                    elif sk.charge_hits and u.skill_charge < sk.charge_hits:      # 5-hit charge skill
                        fh = int(br.h * (1 - u.skill_charge / sk.charge_hits))
                        overlay(s, pygame.Rect(br.x, br.y, br.w, fh), (0, 0, 0, 185), 10)
                        txt(s, f"CHARGE {u.skill_charge}/{sk.charge_hits}", 20, KURAMA_COLOR, br.center, "center", True)
                    elif u.cd > 0:
                        fh = int(br.h * min(1, u.cd / sk.cooldown))
                        overlay(s, pygame.Rect(br.x, br.y, br.w, fh), (0, 0, 0, 185), 10)
                        txt(s, f"{u.cd:.1f}s", 22, TEXT, br.center, "center", True)
                    else:
                        txt(s, "READY - CLICK!", 15, (255, 240, 120), (br.centerx, br.bottom - 14), "center", True)
                    if can:
                        self.hit(br, lambda uu=u: b.cast(uu))
                else:
                    txt(s, "Active skill ready", 14, (255, 235, 140), (br.centerx, br.bottom - 14), "center")
            else:
                panel(s, br, (22, 22, 30), (60, 62, 80), 10, 2, shadow=False)
                if units is not None and getattr(units[i], "stun_timer", 0.0) > 0:
                    overlay(s, br, (60, 60, 70, 195), 10)
                    txt(s, f"STUNNED {units[i].stun_timer:.1f}s", 18, (200, 200, 215), br.center, "center", True)
                else:
                    txt(s, "No skill", 16, (120, 118, 140), (br.centerx, br.centery - 8), "center", True)
                    txt(s, f"{ch.rarity}: basic attacks only", 13, (120, 118, 140), (br.centerx, br.centery + 14), "center")

        if b:
            self.button((20, 645, 150, 44), "AUTO: ON" if b.auto else "AUTO: OFF", lambda: setattr(b, "auto", not b.auto),
                        b.state == "fighting", BTN_GOOD if b.auto else BTN_DANGER, 17)
            self.button((185, 645, 150, 44), f"Speed x{b.speed}", lambda: setattr(b, "speed", 3 - b.speed),
                        b.state == "fighting", BTN_CHAKRA, 17)
            self.button((350, 645, 150, 44), "Retreat", g.retreat, b.state == "fighting", BTN_DANGER, 17)
            self.button((515, 645, 110, 44), "Admin", g.open_admin, b.state == "fighting", BTN_NEUTRAL, 17)
        else:
            txt(s, "Tip: Skills can be cast manually (click / keys 1-3) or automatically.", 15, DIM, (20, 656))
        lp = pygame.Rect(808, 474, 272, 216)
        panel(s, lp, (16, 16, 24), (96, 76, 48), 12, 2)
        txt(s, "Battle Log", 15, AMBER_SOFT, (lp.x + 12, lp.y + 7), "topleft", True)
        divider(s, lp.x + 12, lp.right - 12, lp.y + 27, (150, 100, 50), False)
        if b:
            for i, (m, c) in enumerate(b.log[-8:]):
                txt_fit(s, m, 14, c, (lp.x + 12, lp.y + 34 + i *21), lp.w - 24, "topleft", False, 11)

        if b and b.state in ("victory", "defeat"):
            overlay(s, pygame.Rect(0, 0, W, H), (0, 0, 0, 150))
            rp = pygame.Rect(W // 2 - 230, 150, 460, 380)
            win = b.state == "victory"
            accent = GOLD_C if win else BAD
            panel(s, rp, (26, 24, 34), accent, 16, 3, glow=(accent, 14, 110), corners=accent)
            if win:
                txt(s, "VICTORY!", 44, GOLD_C, (rp.centerx, rp.y + 40), "center", True, shadow=True)
                txt(s, f"{b.map['name']} - Stage {b.stage} cleared" + (" (Solo Boss)" if b.boss_stage else ""), 16, DIM,
                    (rp.centerx, rp.y + 76), "center")
                divider(s, rp.x + 50, rp.right - 50, rp.y + 94, GOLD_C)
                rw = b.rewards
                lines = [(f"Gold  +{rw['gold']}", GOLD_C), (f"Gems  +{rw['gems']}", GEM_C),
                         (f"EXP   +{rw['exp']}", EXP_C)]
                for key, amt in rw["drops"].items():
                    info = ITEMS[key]
                    tag = "" if info["rarity"] == "Common" else f" [{info['rarity']}]"
                    lines.append((f"{info['name']}{tag}  +{amt}", info["color"]))
                if not rw["drops"]:
                    lines.append(("No materials dropped this time", DIM))
                line_h = max(22, min(30, (rp.h - 66 - 112 - 20) // max(1, len(lines))))   # stays clear of the buttons
                for i, (l, c) in enumerate(lines):
                    ry = rp.y + 112 + i * line_h
                    if i % 2 == 0:
                        overlay(s, pygame.Rect(rp.x + 36, ry - line_h // 2, rp.w - 72, line_h - 2), (255, 255, 255, 12), 8)
                    txt_fit(s, l, 22, c, (rp.centerx, ry), rp.w - 90, "center", True, 14)
            else:
                txt(s, "DEFEAT", 44, BAD, (rp.centerx, rp.y + 44), "center", True, shadow=True)
                divider(s, rp.x + 50, rp.right - 50, rp.y + 84, BAD)
                txt(s, "Level up / evolve your heroes and try again.", 17, DIM, (rp.centerx, rp.y + 120), "center")
            if b.state == "victory":
                by = rp.bottom - 66
                self.button((rp.x + 16, by, 136, 50), "Continue", g.finish_battle, True, BTN_CHAKRA, 18)
                self.button((rp.x + 162, by, 136, 50), "Replay Stage", lambda: g.finish_battle("replay"), True, BTN_GOOD, 18)
                self.button((rp.x + 308, by, 136, 50), "Next Stage", lambda: g.finish_battle("next"), True, BTN_PRIMARY, 18)
            else:
                by = rp.bottom - 66
                self.button((rp.centerx - 100, by, 200, 50), "Continue", g.finish_battle, True, BTN_CHAKRA, 20)
