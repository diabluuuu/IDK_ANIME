"""ui.py - UIManager: modern dark-obsidian & chakra-amber ninja RPG interface."""
import math
import random

import pygame

from config import *
from drawing import (
    font, txt, panel, overlay, hp_bar, shade, blend, gradient_rect, glow_rect,
    draw_corner_accents, draw_backdrop, draw_star_polygon, draw_pedestal,
    draw_hero, draw_enemy, assets,
    draw_punch, draw_heal_pulse, _stone_tint_surface,
    draw_magma_shot, draw_super_magma_shot, draw_roushi_cast, draw_burn_status,
    draw_kurama_aura, draw_kurama_cast, draw_naruto_rasengan, draw_naruto_attack,
    draw_han_cast, draw_han_steam_shot, draw_bullet_han,
    draw_danzo_wind, draw_kakuzu_fire, draw_kimimaro_bone_shot, draw_kimimaro_bones,
    draw_kisame_slash, draw_kisame_wave,
)
from battle import slot_ys, stage_drop_table


class UIManager:
    TABS = [("gacha", "Summon"), ("roster", "Roster"), ("team", "Team"), ("battle", "Battle")]

    def __init__(self, game, screen):
        self.g, self.screen = game, screen
        self.hits = []
        self.roster_scroll = self.team_scroll = 0
        self.selected = None
        self.search_rect = None     # set each frame by draw_search_box() (None = not visible)
        self.bag_scroll = 0

    def hit(self, rect, action, clip=None):
        self.hits.append((pygame.Rect(rect), action, clip))

    def click(self, pos):
        for rect, action, clip in reversed(self.hits):
            if rect.collidepoint(pos) and (clip is None or clip.collidepoint(pos)):
                action()
                return

    def button(self, rect, label, action, enabled=True, color=CHAKRA_DEEP, size=20, sub=None,
               radius=11, glow=False, active=False):
        """Modern gradient RPG button with rounded corners (10-12px), specular top sheen, and hover glow."""
        rect = pygame.Rect(rect)
        s = self.screen
        hover = rect.collidepoint(pygame.mouse.get_pos()) and enabled

        if not enabled:
            top_c, bot_c = (36, 38, 48), (24, 26, 34)
            border_c = (62, 65, 80)
            tc = (112, 116, 132)
            sub_tc = (92, 96, 112)
        else:
            base = shade(color, 1.18) if hover else color
            top_c = shade(base, 1.24)
            bot_c = shade(base, 0.72)
            border_c = PANEL_BORDER_GLOW if (hover or active or glow) else shade(base, 1.48)
            tc = TEXT
            sub_tc = CHAKRA_GOLD if sub else TEXT

        # Soft drop shadow
        if rect.h >= 28:
            overlay(s, rect.move(0, 3), (0, 0, 0, 105), radius=radius)

        if enabled and (hover or active or glow):
            glow_rect(s, rect, border_c, radius=radius, spread=5 if hover else 4, alpha=72 if hover else 48)

        gradient_rect(s, rect, top_c, bot_c, radius=radius)

        # Inner top specular highlight
        if rect.w > 16 and rect.h > 18:
            shine = pygame.Rect(rect.x + 3, rect.y + 2, rect.w - 6, max(2, rect.h // 4))
            overlay(s, shine, (255, 255, 255, 28 if enabled else 10), radius=max(2, radius - 3))

        pygame.draw.rect(s, border_c, rect, 2, border_radius=radius)

        if active:
            ind = pygame.Rect(rect.x + 16, rect.bottom - 4, max(12, rect.w - 32), 3)
            pygame.draw.rect(s, CHAKRA_GOLD, ind, border_radius=2)

        if sub:
            txt(s, label, size, tc, (rect.centerx, rect.centery - 8), "center", True)
            txt(s, sub, max(11, size - 6), sub_tc, (rect.centerx, rect.centery + 12), "center", True)
        else:
            txt(s, label, size, tc, rect.center, "center", True)

        if enabled:
            self.hit(rect, action)

    def _draw_currency_pill(self, rect, kind, label, value, color):
        """Draws a high-contrast obsidian currency badge with a vector icon in the top header."""
        rect = pygame.Rect(rect)
        s = self.screen
        gradient_rect(s, rect, (26, 28, 40), (14, 16, 24), radius=10)
        pygame.draw.rect(s, PANEL_BORDER_SUBTLE, rect, 1, border_radius=10)
        icx, icy = rect.x + 16, rect.centery
        if kind == "gold":
            pygame.draw.circle(s, GOLD_C, (icx, icy), 7)
            pygame.draw.circle(s, (255, 240, 150), (icx, icy), 5, 1)
            pygame.draw.circle(s, (120, 80, 15), (icx, icy), 7, 1)
        elif kind == "gems":
            pts = [(icx, icy - 8), (icx + 7, icy), (icx, icy + 8), (icx - 7, icy)]
            pygame.draw.polygon(s, GEM_C, pts)
            pygame.draw.polygon(s, (190, 245, 255), [(icx, icy - 8), (icx + 7, icy), (icx, icy)])
            pygame.draw.polygon(s, (20, 90, 130), pts, 1)
        else:
            pygame.draw.circle(s, EXP_C, (icx, icy), 7)
            pygame.draw.circle(s, (210, 255, 225), (icx - 2, icy - 2), 3)
            pygame.draw.circle(s, (25, 110, 65), (icx, icy), 7, 1)
        txt(s, label, 11, DIM, (icx + 12, rect.y + 5), "topleft", True, shadow=False)
        txt(s, f"{value:,}", 14, color, (icx + 12, rect.bottom - 5), "bottomleft", True)

    def _draw_scrollbar(self, area, scroll, content_h):
        """Draws a sleek dark-amber scrollbar along the right edge of a scrollable list/grid."""
        if content_h <= area.h:
            return
        s = self.screen
        track = pygame.Rect(area.right - 5, area.y + 4, 4, area.h - 8)
        pygame.draw.rect(s, (16, 18, 26), track, border_radius=2)
        thumb_h = max(28, int(track.h * (area.h / content_h)))
        max_scroll = max(1, content_h - area.h)
        frac = max(0.0, min(1.0, scroll / max_scroll))
        thumb_y = track.y + int((track.h - thumb_h) * frac)
        thumb = pygame.Rect(track.x, thumb_y, track.w, thumb_h)
        pygame.draw.rect(s, PANEL_BORDER_GLOW, thumb, border_radius=2)

    def _draw_summon_circle(self, cx, cy, r, t, active_glow=False):
        """Draws an ornate rotating ninja chakra seal behind the Summon Portal stage."""
        s = self.screen
        box = int(r * 2.4)
        seal = pygame.Surface((box, box), pygame.SRCALPHA)
        mc = box // 2
        col = CHAKRA_ORANGE if not active_glow else CHAKRA_GOLD
        a_base = 42 if active_glow else 26
        pygame.draw.circle(seal, (*col, a_base), (mc, mc), r, 2)
        pygame.draw.circle(seal, (*col, a_base + 12), (mc, mc), int(r * 0.82), 1)
        pygame.draw.circle(seal, (*NEON_BLUE, a_base), (mc, mc), int(r * 0.56), 1)
        # Rotating 8-point ninja seal spokes
        for k in range(8):
            ang = t * 0.35 + k * (math.tau / 8)
            x1 = mc + int(math.cos(ang) * r * 0.56)
            y1 = mc + int(math.sin(ang) * r * 0.56)
            x2 = mc + int(math.cos(ang) * r * 0.98)
            y2 = mc + int(math.sin(ang) * r * 0.98)
            pygame.draw.line(seal, (*col, a_base + 10), (x1, y1), (x2, y2), 2)
            ang2 = -t * 0.5 + k * (math.tau / 8)
            px = mc + int(math.cos(ang2) * r * 0.82)
            py = mc + int(math.sin(ang2) * r * 0.82)
            pygame.draw.circle(seal, (*CHAKRA_GOLD, a_base + 24), (px, py), 4)
        s.blit(seal, (int(cx) - mc, int(cy) - mc))

    def filtered(self, chars):
        q = self.g.search_text.strip().lower()
        return [c for c in chars if q in c.name.lower()] if q else chars

    def count_label(self, shown):
        total = len(self.g.roster)
        return f"{shown}/{total}" if self.g.search_text.strip() else f"{total}"

    def draw_search_box(self, rect, text=None):
        g, s = self.g, self.screen
        text = g.search_text if text is None else text
        rect = pygame.Rect(rect)
        self.search_rect = rect
        focused = g.search_focused
        border_c = PANEL_BORDER_GLOW if focused else PANEL_BORDER_SUBTLE
        if focused:
            glow_rect(s, rect, PANEL_BORDER_GLOW, radius=10, spread=4, alpha=55)
        panel(s, rect, PANEL_DARK, border_c, 10, 2 if focused else 1, corners=False)

        # Magnifying glass icon
        gx, gy = rect.x + 14, rect.centery - 1
        pygame.draw.circle(s, CHAKRA_GOLD if focused else DIM, (gx, gy), 5, 2)
        pygame.draw.line(s, CHAKRA_GOLD if focused else DIM, (gx + 4, gy + 4), (gx + 8, gy + 8), 2)

        xr = pygame.Rect(rect.right - 28, rect.y + 4, 24, rect.h - 8)
        self.button(xr, "X", lambda: g.set_search_text(""), enabled=bool(text),
                    color=(140, 52, 52), size=12, radius=7)
        avail = xr.x - (rect.x + 28) - 10
        f = font(15)
        shown = text
        while shown and f.size(shown)[0] > avail:
            shown = shown[1:]                       # keep the tail visible while typing
        tx = rect.x + 28
        if shown:
            r = txt(s, shown, 15, TEXT, (tx, rect.centery), "midleft", shadow=False)
            if focused and int(pygame.time.get_ticks() / 500) % 2 == 0:
                pygame.draw.line(s, CHAKRA_GOLD, (r.right + 2, rect.centery - 8), (r.right + 2, rect.centery + 8), 2)
        elif focused:
            if int(pygame.time.get_ticks() / 500) % 2 == 0:
                pygame.draw.line(s, CHAKRA_GOLD, (tx + 1, rect.centery - 8), (tx + 1, rect.centery + 8), 2)
        else:
            txt(s, "Search shinobi / items...", 14, (110, 115, 136), (tx, rect.centery), "midleft", shadow=False)

    def draw(self):
        self.hits = []
        self.search_rect = None
        g = self.g
        s = self.screen
        t = pygame.time.get_ticks() / 1000
        draw_backdrop(s, t)

        # Top navigation dock
        header_r = pygame.Rect(0, 0, W, 56)
        gradient_rect(s, header_r, (26, 24, 34), (14, 15, 22), radius=0)
        pygame.draw.line(s, PANEL_BORDER, (0, 55), (W, 55), 2)
        pygame.draw.line(s, PANEL_BORDER_GLOW, (20, 55), (600, 55), 2)

        locked = g.battle is not None and g.battle.state == "fighting"
        for i, (key, label) in enumerate(self.TABS):
            r = pygame.Rect(20 + i * 144, 8, 134, 40)
            active = g.tab == key
            self.button(
                r,
                label.upper(),
                lambda k=key: g.set_tab(k),
                enabled=not locked or key == "battle",
                color=CHAKRA_DEEP if active else (38, 41, 56),
                size=16,
                radius=11,
                glow=active,
                active=active,
            )

        # Sleek currency pills in top bar
        currencies = [
            ("gold", "GOLD", g.gold, GOLD_C),
            ("gems", "GEMS", g.gems, GEM_C),
            ("exp",  "EXP",  g.exp,  EXP_C),
        ]
        for i, (kind, lab, val, col) in enumerate(currencies):
            self._draw_currency_pill((604 + i * 122, 9, 114, 38), kind, lab, val, col)

        self.button((976, 8, 104, 40), "BAG", g.open_bag, True, (155, 82, 24), 16,
                    sub=f"{g.bag_total():,} items", radius=11)

        getattr(self, "draw_" + g.tab)()
        if g.admin_modal_active:
            self.draw_admin_modal()
        if g.bag_open:
            self.draw_bag_modal()
        if g.toast_t > 0:
            r = txt(s, g.toast_msg, 20, TEXT, (W // 2, H - 30), "center", True)
            bg = r.inflate(36, 18)
            glow_rect(s, bg, PANEL_BORDER_GLOW, radius=12, spread=5, alpha=80)
            panel(s, bg, (24, 22, 32), PANEL_BORDER_GLOW, 12, 2, corners=False)
            txt(s, g.toast_msg, 20, CHAKRA_GOLD, (W // 2, H - 30), "center", True)
        if g.flash_t > 0:
            overlay(s, pygame.Rect(0, 0, W, H), (*g.flash_color, int(190 * g.flash_t)))

    def draw_admin_modal(self):
        g, s = self.g, self.screen
        self.hits = []
        overlay(s, pygame.Rect(0, 0, W, H), (4, 6, 12, 195))
        cx = W // 2
        if g.admin_prompt_open:
            box = pygame.Rect(cx - 210, 90, 420, 520)
            panel(s, box, PANEL, PANEL_BORDER_GLOW, 14, 2, glow=CHAKRA_ORANGE, corners=True)
            txt(s, "ADMIN ACCESS", 26, CHAKRA_GOLD, (cx, box.y + 36), "center", True)
            txt(s, "Enter 6-Digit Security Passcode", 14, DIM, (cx, box.y + 64), "center")
            n = len(ADMIN_PASSCODE)
            x0 = cx - (n * 46 + (n - 1) * 8) // 2
            for i in range(n):
                slot = pygame.Rect(x0 + i * 54, box.y + 92, 46, 54)
                filled = i < len(g.admin_input_code)
                panel(s, slot, PANEL_DARK, PANEL_BORDER_GLOW if filled else PANEL_BORDER_SUBTLE, 10, 2, corners=False)
                if filled:
                    pygame.draw.circle(s, CHAKRA_ORANGE, slot.center, 8)
                    pygame.draw.circle(s, CHAKRA_GOLD, slot.center, 4)
            keys = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "C", "0", "<"]
            for i, k in enumerate(keys):
                r = pygame.Rect(cx - 145 + (i % 3) * 100, box.y + 172 + (i // 3) * 66, 90, 56)
                if k == "C":
                    self.button(r, "Clear", g.admin_clear, True, (130, 50, 50), 18, radius=10)
                elif k == "<":
                    self.button(r, "Del", g.admin_backspace, True, (140, 85, 35), 18, radius=10)
                else:
                    self.button(r, k, lambda d=k: g.admin_press_digit(d), True, (44, 48, 68), 24, radius=10)
            self.button((cx - 185, box.bottom - 68, 175, 48), "Cancel", g.close_admin, True, (120, 48, 48), 19, radius=11)
            self.button((cx + 10, box.bottom - 68, 175, 48), "Unlock", g.admin_submit, True, (45, 145, 85), 19, radius=11, glow=True)
            self.button((box.right - 46, box.y + 12, 34, 32), "X", g.close_admin, True, (130, 48, 48), 15, radius=8)
            return

        box = pygame.Rect(cx - 275, 66, 550, 552)
        panel(s, box, PANEL, GOLD_C, 14, 2, glow=CHAKRA_ORANGE, corners=True)
        txt(s, "ADMIN COMMAND CONSOLE", 28, GOLD_C, (cx, box.y + 34), "center", True)
        txt(s, f"Developer testing tools  •  +{ADMIN_GRANT:,} per resource grant", 13, DIM, (cx, box.y + 62), "center")

        stat_well = pygame.Rect(box.x + 24, box.y + 80, box.w - 48, 58)
        panel(s, stat_well, PANEL_DARK, PANEL_BORDER_SUBTLE, 9, 1, corners=False)
        stats = [("Gold", g.gold, GOLD_C), ("Gems", g.gems, GEM_C), ("EXP", g.exp, EXP_C)]
        stats += [(ITEMS[k]["short"], getattr(g, k), ITEMS[k]["color"]) for k in ITEMS]
        cols = 4
        step = (stat_well.w - 24) // cols
        for i, (lab, val, col) in enumerate(stats):
            txt(s, f"{lab}: {val:,}", 11, col,
                (stat_well.x + 12 + (i % cols) * step, stat_well.y + 7 + (i // cols) * 13), "topleft", True, shadow=False)

        bw = box.w - 64
        self.button((box.x + 32, box.y + 148, bw, 40), "Grant +10,000 Gems & Gold", lambda: g.admin_claim("currency"),
                    True, NEON_BLUE_DEEP, 18, radius=10)
        self.button((box.x + 32, box.y + 194, bw, 40), "Grant +10,000 All Awakening Materials", lambda: g.admin_claim("materials"),
                    True, (45, 130, 80), 18, radius=10)
        self.button((box.x + 32, box.y + 240, bw, 40), "Grant ALL (+10,000 Everything)", lambda: g.admin_claim("all"),
                    True, CHAKRA_DEEP, 18, radius=10, glow=True)

        pygame.draw.line(s, PANEL_BORDER_SUBTLE, (box.x + 32, box.y + 292), (box.right - 32, box.y + 292), 1)
        tm = g.current_map
        txt(s, "Stage Progression — " + (f"{tm['name']}  (Max Stage {g.max_stage})" if tm else "All Maps"),
            14, CHAKRA_GOLD, (box.x + 32, box.y + 300), "topleft", True)
        ry = box.y + 324
        tgt = g.admin_stage_target
        self.button((box.x + 32, ry, 46, 34), "-10", lambda: g.admin_change_target(-10), tgt > 1, (52, 58, 82), 14, radius=8)
        self.button((box.x + 82, ry, 44, 34), "-1", lambda: g.admin_change_target(-1), tgt > 1, (52, 58, 82), 14, radius=8)
        target_pill = pygame.Rect(box.x + 132, ry, 174, 34)
        panel(s, target_pill, PANEL_DARK, PANEL_BORDER_SUBTLE, 8, 1, corners=False)
        txt(s, f"Target Stage: {tgt}", 15, GOLD_C, target_pill.center, "center", True)
        self.button((box.x + 312, ry, 44, 34), "+1", lambda: g.admin_change_target(1), True, (52, 58, 82), 14, radius=8)
        self.button((box.x + 360, ry, 46, 34), "+10", lambda: g.admin_change_target(10), True, (52, 58, 82), 14, radius=8)
        self.button((box.x + 412, ry, 106, 34), "Set Max", g.admin_set_max_stage, True, (45, 130, 80), 15, radius=8)

        ry2 = box.y + 368
        self.button((box.x + 32, ry2, 236, 38), "Skip Current Stage", g.admin_skip_stage, True, (165, 95, 30), 16, radius=10)
        self.button((box.x + 282, ry2, 236, 38), "Instant Win Battle", g.admin_instant_win,
                    g.battle is not None and g.battle.state == "fighting", (175, 55, 55), 16, radius=10)

        pygame.draw.line(s, PANEL_BORDER_SUBTLE, (box.x + 32, box.y + 416), (box.right - 32, box.y + 416), 1)
        self.button((box.x + 32, box.y + 426, bw, 42), "Unlock All Characters & Evolutions",
                    g.admin_give_all_characters, True, (135, 60, 160), 18, radius=10)
        self.button((box.centerx - 95, box.bottom - 62, 190, 46), "Close Console", g.close_admin, True, (125, 50, 50), 18, radius=11)
        self.button((box.right - 46, box.y + 12, 34, 32), "X", g.close_admin, True, (130, 48, 48), 15, radius=8)

    def draw_item_icon(self, key, cx, cy, r):
        s = self.screen
        cx, cy = int(cx), int(cy)
        img = assets.get_item_image(key, size=int(r * 2))
        if img:
            s.blit(img, img.get_rect(center=(cx, cy)))
            return

        col = ITEMS[key]["color"]
        if key == "stones":
            pts = [(cx, cy - r), (cx + r * 0.8, cy - r * 0.2), (cx, cy + r), (cx - r * 0.8, cy - r * 0.2)]
            pygame.draw.polygon(s, col, pts)
            pygame.draw.polygon(s, shade(col, 1.45), [(cx, cy - r), (cx + r * 0.8, cy - r * 0.2), (cx, cy - r * 0.2)])
            pygame.draw.polygon(s, shade(col, 0.6), pts, 2)
        elif key == "chakra":
            for k, f in enumerate((1.0, 0.68, 0.36)):
                pygame.draw.circle(s, shade(col, 0.7 + 0.3 * k), (cx, cy), max(2, int(r * f)), 0 if k == 2 else 3)
        elif key == "naruto_cloak":
            pts = [(cx - r * 0.5, cy - r), (cx + r * 0.5, cy - r), (cx + r, cy + r), (cx - r, cy + r)]
            pygame.draw.polygon(s, col, pts)
            pygame.draw.polygon(s, shade(col, 0.6), pts, 2)
            pygame.draw.rect(s, shade(col, 1.4), (cx - r * 0.5, cy - r, r, r * 0.3), border_radius=3)
            pygame.draw.line(s, shade(col, 0.6), (cx, cy - r * 0.7), (cx, cy + r), 2)
        elif key == "black_chakra":
            for k in range(8):
                a = k * math.pi / 4
                pygame.draw.line(s, col, (cx, cy), (cx + math.cos(a) * r, cy + math.sin(a) * r), 3)
            pygame.draw.circle(s, (20, 14, 24), (cx, cy), int(r * 0.62))
            pygame.draw.circle(s, col, (cx, cy), int(r * 0.62), 3)
        elif key == "shukaku":
            pygame.draw.circle(s, col, (cx, cy + int(r * 0.2)), int(r * 0.75))
            pygame.draw.circle(s, shade(col, 1.3), (cx, cy - int(r * 0.4)), int(r * 0.45))
            pygame.draw.circle(s, shade(col, 0.6), (cx, cy + int(r * 0.2)), int(r * 0.75), 2)
        elif key == "matatabi":
            for k in range(5):
                a = k * math.pi / 3 - math.pi / 2
                pygame.draw.line(s, col, (cx, cy), (cx + int(math.cos(a) * r), cy + int(math.sin(a) * r)), 3)
            pygame.draw.circle(s, (20, 30, 60), (cx, cy), int(r * 0.6))
            pygame.draw.circle(s, col, (cx, cy), int(r * 0.6), 2)
        elif key == "isobu":
            pygame.draw.ellipse(s, shade(col, 0.75), (cx - int(r * 0.85), cy - int(r * 0.65), int(r * 1.7), int(r * 1.3)))
            pygame.draw.ellipse(s, col, (cx - int(r * 0.65), cy - int(r * 0.45), int(r * 1.3), int(r * 0.9)))
            pygame.draw.ellipse(s, shade(col, 1.35), (cx - int(r * 0.85), cy - int(r * 0.65), int(r * 1.7), int(r * 1.3)), 2)
            for k in (-1, 0, 1):
                tx = cx + int(k * r * 0.45)
                pygame.draw.line(s, shade(col, 1.3), (tx, cy + int(r * 0.4)), (tx + int(k * r * 0.2), cy + int(r * 0.95)), 3)
        elif key == "kokuo":
            for k in range(5):
                a = -math.pi * 0.85 + k * (math.pi * 0.7 / 4)
                pygame.draw.line(s, shade(col, 1.15), (cx, cy),
                                 (cx + int(math.cos(a) * r * 0.95), cy + int(math.sin(a) * r * 0.95)), 3)
            pygame.draw.circle(s, col, (cx, cy + int(r * 0.15)), int(r * 0.58))
            pygame.draw.circle(s, (245, 250, 255), (cx, cy + int(r * 0.15)), int(r * 0.36))
            pygame.draw.circle(s, shade(col, 0.65), (cx, cy + int(r * 0.15)), int(r * 0.58), 2)
        elif key == "sharingan_base":
            pygame.draw.circle(s, (225, 35, 50), (cx, cy), int(r * 0.88))
            pygame.draw.circle(s, (30, 10, 15), (cx, cy), int(r * 0.88), 2)
            pygame.draw.circle(s, (45, 10, 15), (cx, cy), int(r * 0.55), 1)
            pygame.draw.circle(s, (15, 15, 20), (cx, cy), max(2, int(r * 0.24)))
            for k in range(3):
                ang = k * (math.tau / 3) - math.pi / 2
                tx = cx + int(math.cos(ang) * r * 0.54)
                ty = cy + int(math.sin(ang) * r * 0.54)
                pygame.draw.circle(s, (15, 15, 20), (tx, ty), max(2, int(r * 0.15)))
        else:
            pygame.draw.circle(s, col, (cx, cy), r)

    def draw_bag_modal(self):
        g, s = self.g, self.screen
        self.hits = []
        overlay(s, pygame.Rect(0, 0, W, H), (4, 6, 12, 195))
        self.hit(pygame.Rect(0, 0, W, H), g.close_bag)          # click outside the window = close
        box = pygame.Rect(90, 62, 920, 584)
        panel(s, box, PANEL, PANEL_BORDER_GLOW, 14, 2, glow=CHAKRA_ORANGE, corners=True)
        self.hit(box, lambda: None)                              # clicks inside never reach "close"
        tr = txt(s, "SHINOBI INVENTORY", 26, CHAKRA_GOLD, (box.x + 24, box.y + 16), "topleft", True)
        owned = g.owned_items()
        txt(s, f"{len(owned)} item types  •  {g.bag_total():,} total materials", 14, DIM, (tr.right + 18, tr.centery), "midleft")
        self.button((box.right - 48, box.y + 12, 36, 32), "X", g.close_bag, True, (135, 48, 48), 16, radius=9)
        self.draw_search_box((box.x + 24, box.y + 58, 390, 34), g.bag_search)

        q = g.bag_search.strip().lower()
        items = [(k, n) for k, n in owned if q in ITEMS[k]["name"].lower()]
        area = pygame.Rect(box.x + 24, box.y + 104, 572, 456)
        panel(s, area.inflate(8, 8), PANEL_DARK, PANEL_BORDER_SUBTLE, 12, 2, corners=False)
        cols, cw, chh = 4, 138, 126
        rows = math.ceil(len(items) / cols)
        content_h = rows * (chh + 8)
        self.bag_scroll = max(0, min(self.bag_scroll, max(0, content_h - area.h + 8)))
        sel_key = g.bag_selected if g.bag_selected in dict(owned) else (owned[0][0] if owned else None)
        s.set_clip(area)
        for i, (key, qty) in enumerate(items):
            row, col = divmod(i, cols)
            r = pygame.Rect(area.x + 8 + col * cw, area.y + 8 + row * (chh + 8) - self.bag_scroll, cw - 8, chh)
            if not r.colliderect(area):
                continue
            it = ITEMS[key]
            rc = RARITY_COLOR.get(it["rarity"], it["color"])
            chosen = key == sel_key
            if chosen:
                glow_rect(s, r, it["color"], radius=11, spread=4, alpha=65)
            panel(s, r, (42, 36, 48) if chosen else PANEL_ALT, it["color"] if chosen else rc,
                  11, 2 if chosen else 1, corners=chosen)
            well = pygame.Rect(r.x + 12, r.y + 10, r.w - 24, 62)
            gradient_rect(s, well, PANEL_DARK, shade(it["color"], 0.22), radius=8)
            pygame.draw.rect(s, shade(it["color"], 0.65), well, 1, border_radius=8)
            self.draw_item_icon(key, well.centerx, well.centery, 24)
            txt(s, self._fit(it["name"], 16), 13, TEXT, (r.centerx, r.y + 84), "center", True)
            txt(s, f"x{qty:,}", 15, it["color"], (r.centerx, r.y + 106), "center", True)
            self.hit(r, lambda k=key: g.select_bag_item(k), area)
        if not items:
            txt(s, "No items match your search" if owned else "Your inventory bag is empty", 18, DIM, area.center, "center")
        s.set_clip(None)
        self._draw_scrollbar(area, self.bag_scroll, content_h)

        dp = pygame.Rect(box.x + 614, box.y + 58, 282, 502)
        panel(s, dp, PANEL_ALT, PANEL_BORDER, 12, 2, corners=True)
        if sel_key is None:
            txt(s, "Select an item to inspect", 16, DIM, dp.center, "center")
            return
        it, qty = ITEMS[sel_key], dict(owned)[sel_key]
        rc = RARITY_COLOR.get(it["rarity"], it["color"])
        icon_bg = pygame.Rect(0, 0, 124, 124)
        icon_bg.center = (dp.centerx, dp.y + 86)
        glow_rect(s, icon_bg, it["color"], radius=14, spread=6, alpha=65)
        panel(s, icon_bg, PANEL_DARK, it["color"], 14, 2, corners=True)
        self.draw_item_icon(sel_key, icon_bg.centerx, icon_bg.centery, 46)
        txt(s, it["name"], 22, it["color"], (dp.centerx, dp.y + 172), "center", True)

        badge_r = pygame.Rect(0, 0, 118, 24)
        badge_r.center = (dp.centerx, dp.y + 202)
        panel(s, badge_r, RARITY_BG.get(it["rarity"], PANEL_DARK), rc, 8, 1, corners=False)
        txt(s, it["rarity"].upper(), 12, rc, badge_r.center, "center", True)

        txt(s, f"Owned:  x{qty:,}", 18, TEXT, (dp.centerx, dp.y + 236), "center", True)
        pygame.draw.line(s, PANEL_BORDER_SUBTLE, (dp.x + 18, dp.y + 258), (dp.right - 18, dp.y + 258), 1)
        txt(s, "ITEM LORE & SOURCE", 12, CHAKRA_GOLD, (dp.x + 18, dp.y + 270), "topleft", True)
        for i, line in enumerate(self._wrap(it["desc"], 14, dp.w - 36, 9)):
            txt(s, line, 14, TEXT, (dp.x + 18, dp.y + 294 + i * 20), shadow=False)

    def card(self, rect, ch, t, selected=False, tag=None, small=False):
        """High-end Gacha character card with rarity glow frame, recessed portrait stage, and star row."""
        s = self.screen
        rect = pygame.Rect(rect)
        rc = RARITY_COLOR[ch.rarity]
        rbg = RARITY_BG.get(ch.rarity, PANEL_ALT)
        hover = rect.collidepoint(pygame.mouse.get_pos())

        if selected:
            glow_rect(s, rect, GOOD, radius=12, spread=5, alpha=80)
        elif ch.rarity in ("Legendary", "Epic") or hover:
            glow_rect(s, rect, rc, radius=12, spread=4, alpha=60 if hover else 42)

        top_fill = blend(rbg, (55, 65, 55), 0.35) if selected else shade(rbg, 1.18 if hover else 1.0)
        bot_fill = (16, 18, 26)
        panel(s, rect, top_fill, GOOD if selected else rc, 12, 3 if selected else 2,
              corners=not small, grad_bottom=bot_fill)

        # Inner recessed portrait window
        pad = 6 if small else 8
        footer_h = 38 if small else 50
        port_r = pygame.Rect(rect.x + pad, rect.y + pad, rect.w - pad * 2, rect.h - footer_h - pad)
        gradient_rect(s, port_r, (14, 16, 24), shade(rbg, 0.75), radius=8)
        pygame.draw.rect(s, shade(rc, 0.55), port_r, 1, border_radius=8)

        size = 22 if small else 38
        hero_cy = port_r.centery + (4 if small else 8)
        if not small:
            draw_pedestal(s, port_r.centerx, port_r.bottom - 14, rx=30, ry=9, color=rc, t=t)
        draw_hero(s, ch.tpl, ch.evo_stage, port_r.centerx, hero_cy, size, t)

        # Compact star row for small cards (draw_hero only draws stars when size >= 34)
        if small:
            k = RARITIES.index(ch.rarity) + 1
            for idx in range(k):
                sx = rect.centerx + (idx - (k - 1) / 2) * 9
                draw_star_polygon(s, sx, port_r.y + 8, 3.2, rc)

        # Name and rarity/level footer
        name_y = rect.bottom - (26 if small else 34)
        sub_y = rect.bottom - (11 if small else 15)
        max_chars = 13 if small else 15
        txt(s, self._fit(ch.name, max_chars), 13 if small else 14, TEXT, (rect.centerx, name_y), "center", True)
        txt(s, f"Lv.{ch.level} • {ch.rarity}" if small else f"Lv.{ch.level}  {ch.rarity.upper()}",
            11 if small else 12, rc, (rect.centerx, sub_y), "center", True)

        if tag:
            tag_r = pygame.Rect(rect.x + 5, rect.y + 5, 30 if small else 42, 18)
            gradient_rect(s, tag_r, (35, 140, 80), (20, 85, 50), radius=6)
            pygame.draw.rect(s, GOOD, tag_r, 1, border_radius=6)
            txt(s, tag, 11, TEXT, tag_r.center, "center", True)

    def draw_gacha(self):
        g, s = self.g, self.screen
        t = pygame.time.get_ticks() / 1000

        # Left Summon Control Panel
        lp = pygame.Rect(20, 70, 330, 616)
        panel(s, lp, PANEL, PANEL_BORDER, 14, 2, glow=CHAKRA_ORANGE, corners=True)

        # Header banner inside left panel
        hdr = pygame.Rect(lp.x + 14, lp.y + 14, lp.w - 28, 78)
        gradient_rect(s, hdr, (44, 28, 22), (22, 18, 26), radius=10)
        pygame.draw.rect(s, PANEL_BORDER_GLOW, hdr, 1, border_radius=10)
        txt(s, "SUMMON PORTAL", 24, CHAKRA_GOLD, (hdr.centerx, hdr.y + 26), "center", True)

        gem_pill = pygame.Rect(hdr.centerx - 92, hdr.y + 44, 184, 26)
        panel(s, gem_pill, PANEL_DARK, PANEL_BORDER_SUBTLE, 8, 1, corners=False)
        pts = [(gem_pill.x + 16, gem_pill.centery - 6), (gem_pill.x + 22, gem_pill.centery),
               (gem_pill.x + 16, gem_pill.centery + 6), (gem_pill.x + 10, gem_pill.centery)]
        pygame.draw.polygon(s, GEM_C, pts)
        txt(s, f"Gems: {g.gems:,}", 15, GEM_C, (gem_pill.centerx + 8, gem_pill.centery), "center", True)

        # Primary Summon Action Buttons (10-12px rounded corners + gradient + glow)
        self.button(
            (38, 108, 294, 62),
            "SUMMON x1",
            g.do_pull_1,
            g.gems >= SINGLE_COST,
            NEON_BLUE_DEEP,
            21,
            f"{SINGLE_COST} Gems  •  Single Call",
            radius=12,
            glow=g.gems >= SINGLE_COST,
        )
        self.button(
            (38, 182, 294, 66),
            "SUMMON x10",
            g.do_pull_10,
            g.gems >= MULTI_COST,
            CHAKRA_DEEP,
            22,
            f"{MULTI_COST} Gems  •  10% Bonus Value!",
            radius=12,
            glow=g.gems >= MULTI_COST,
        )

        # Drop Rates Card
        rates_box = pygame.Rect(38, 264, 294, 174)
        panel(s, rates_box, PANEL_DARK, PANEL_BORDER_SUBTLE, 11, 1, corners=False)
        txt(s, "SHINOBI DROP RATES", 14, CHAKRA_GOLD, (rates_box.x + 14, rates_box.y + 10), "topleft", True)
        pygame.draw.line(s, PANEL_BORDER_SUBTLE, (rates_box.x + 14, rates_box.y + 30), (rates_box.right - 14, rates_box.y + 30), 1)
        for i, r in enumerate(RARITIES):
            ry = rates_box.y + 42 + i * 32
            rc = RARITY_COLOR[r]
            rate_pct = RARITY_RATE[r]
            draw_star_polygon(s, rates_box.x + 20, ry + 8, 5.5, rc)
            txt(s, r, 15, rc, (rates_box.x + 34, ry), "topleft", True)
            bar_w = 110
            bar_x = rates_box.x + 124
            hp_bar(s, bar_x, ry + 4, bar_w, 9, rate_pct / 50.0, rc)
            txt(s, f"{rate_pct}%", 15, rc, (rates_box.right - 14, ry), "topright", True)

        # Tier Info & Summon Counter Box (cleanly fills the space above Admin button)
        info_box = pygame.Rect(38, 450, 294, 142)
        panel(s, info_box, PANEL_DARK, PANEL_BORDER_SUBTLE, 11, 1, corners=False)
        txt(s, "SCROLL ARCHIVE", 13, NEON_BLUE, (info_box.x + 14, info_box.y + 10), "topleft", True)
        txt(s, "• Common / Rare: Basic Arts", 13, DIM, (info_box.x + 14, info_box.y + 34), shadow=False)
        txt(s, "• Epic / Legendary: Active Jutsu!", 13, CHAKRA_GOLD, (info_box.x + 14, info_box.y + 54), shadow=False)
        txt(s, "• Awaken heroes in Roster for Tier 2", 13, DIM, (info_box.x + 14, info_box.y + 74), shadow=False)
        pygame.draw.line(s, PANEL_BORDER_SUBTLE, (info_box.x + 14, info_box.y + 98), (info_box.right - 14, info_box.y + 98), 1)
        txt(s, "Total Summons Performed:", 14, DIM, (info_box.x + 14, info_box.y + 110), "topleft", True)
        txt(s, f"{g.total_pulls:,}", 16, CHAKRA_ORANGE, (info_box.right - 14, info_box.y + 109), "topright", True)

        # Release layout: Admin System button sits cleanly at the bottom (demo gem button removed)
        self.button((38, 608, 294, 54), "Admin Console", g.open_admin, True, (56, 46, 74), 18,
                    sub="Developer Passcode Required", radius=11)

        # Right Summon Results Stage
        rp = pygame.Rect(368, 70, 712, 616)
        panel(s, rp, PANEL, PANEL_BORDER, 14, 2, corners=True)
        res = g.last_pull
        self._draw_summon_circle(rp.centerx, rp.centery + 18, 210, t, active_glow=bool(res))

        hdr_r = pygame.Rect(rp.x + 18, rp.y + 14, rp.w - 36, 44)
        gradient_rect(s, hdr_r, (38, 28, 24), (20, 18, 28), radius=10)
        pygame.draw.rect(s, PANEL_BORDER_SUBTLE, hdr_r, 1, border_radius=10)
        txt(s, "SUMMONING ALTAR RESULTS", 22, CHAKRA_GOLD, hdr_r.center, "center", True)

        if not res:
            txt(s, "THE SUMMONING SEAL AWAITS", 24, CHAKRA_GOLD, (rp.centerx, rp.centery - 10), "center", True)
            txt(s, "Channel your Gems on the left to summon Shinobi to your roster.", 15, DIM,
                (rp.centerx, rp.centery + 22), "center")
            return

        elapsed = pygame.time.get_ticks() / 1000 - g.pull_time
        rows = math.ceil(len(res) / 5)
        for idx, ch in enumerate(res):
            row, col = divmod(idx, 5)
            n_in_row = min(5, len(res) - row * 5)
            x0 = rp.centerx - (n_in_row * 136 - 8) / 2
            y_base = 136 + row * 222 + (95 if rows == 1 else 0)
            r = pygame.Rect(int(x0 + col * 136), y_base, 128, 202)
            if elapsed >= idx * 0.15:
                if ch.rarity == "Legendary":
                    pulse = int(6 + 4 * math.sin(t * 6))
                    glow_rect(s, r.inflate(pulse, pulse), GOLD_C, radius=14, spread=6, alpha=95)
                self.card(r, ch, t)
                if ch.has_skill:
                    sk_pill = pygame.Rect(r.centerx - 48, r.y - 10, 96, 18)
                    gradient_rect(s, sk_pill, CHAKRA_ORANGE, CHAKRA_DEEP, radius=6)
                    pygame.draw.rect(s, CHAKRA_GOLD, sk_pill, 1, border_radius=6)
                    txt(s, "ACTIVE JUTSU", 10, TEXT, sk_pill.center, "center", True)
            else:
                panel(s, r, PANEL_DARK, PANEL_BORDER_GLOW, 12, 2, corners=True)
                self._draw_summon_circle(r.centerx, r.centery, 36, t * 3, active_glow=True)
                txt(s, "?", 44, CHAKRA_GOLD, r.center, "center", True)

    @staticmethod
    def _wrap(text, size, width, max_lines=5):
        f, lines, cur = font(size), [], ""
        for word in text.split():
            test = (cur + " " + word).strip()
            if f.size(test)[0] <= width or not cur:
                cur = test
            else:
                lines.append(cur)
                cur = word
        if cur:
            lines.append(cur)
        if len(lines) > max_lines:
            lines = lines[:max_lines]
            lines[-1] = lines[-1].rstrip(". ") + "..."
        return lines

    def draw_passive_box(self, ch, rect):
        s = self.screen
        rect = pygame.Rect(rect)
        panel(s, rect, PANEL_DARK, PANEL_BORDER_SUBTLE, 10, 1, corners=False)
        hdr = pygame.Rect(rect.x + 2, rect.y + 2, rect.w - 4, 22)
        gradient_rect(s, hdr, (24, 52, 74), (16, 28, 42), radius=8)
        txt(s, "PASSIVE TRAIT", 11, NEON_BLUE, (rect.x + 10, rect.y + 6), "topleft", True)
        p = ch.passive
        if p:
            txt(s, p.name, 14, CHAKRA_GOLD, (rect.x + 10, rect.y + 27), "topleft", True)
            for i, line in enumerate(self._wrap(p.desc, 12, rect.w - 20, 4)):
                txt(s, line, 12, TEXT, (rect.x + 10, rect.y + 47 + i * 15), shadow=False)
            return
        txt(s, "No innate passive", 14, DIM, (rect.x + 10, rect.y + 38), "topleft", True)

    def draw_roster(self):
        g, s = self.g, self.screen
        t = pygame.time.get_ticks() / 1000
        all_chars = sorted(g.roster, key=lambda c: (-RARITIES.index(c.rarity), -c.level, c.name))
        chars = self.filtered(all_chars)
        sel = g.get_char(self.selected) or (chars or all_chars or [None])[0]
        self.selected = sel.uid if sel else None

        # Left Collection List
        area = pygame.Rect(20, 110, 410, 574)
        tr = txt(s, f"SHINOBI ROSTER ({self.count_label(len(chars))})", 18, CHAKRA_GOLD, (20, 76), "topleft", True)
        self.draw_search_box((tr.right + 12, 70, area.right - tr.right - 12, 32))
        panel(s, area.inflate(8, 8), PANEL, PANEL_BORDER, 12, 2, corners=True)

        content_h = len(chars) * 66
        self.roster_scroll = max(0, min(self.roster_scroll, max(0, content_h - area.h)))
        s.set_clip(area)
        for i, ch in enumerate(chars):
            r = pygame.Rect(area.x + 6, area.y + 4 + i * 66 - self.roster_scroll, area.w - 16, 60)
            if not r.colliderect(area):
                continue
            rc = RARITY_COLOR[ch.rarity]
            is_sel = ch is sel
            row_fill = (52, 38, 30) if is_sel else PANEL_ALT
            row_border = PANEL_BORDER_GLOW if is_sel else PANEL_BORDER_SUBTLE
            panel(s, r, row_fill, row_border, 10, 2 if is_sel else 1, corners=False)

            # Left rarity accent bar
            pygame.draw.rect(s, rc, (r.x + 2, r.y + 6, 5, r.h - 12), border_radius=3)

            # Portrait frame
            p_box = pygame.Rect(r.x + 14, r.y + 6, 48, 48)
            gradient_rect(s, p_box, PANEL_DARK, RARITY_BG.get(ch.rarity, PANEL_DARK), radius=8)
            pygame.draw.rect(s, rc, p_box, 1, border_radius=8)
            draw_hero(s, ch.tpl, ch.evo_stage, p_box.centerx, p_box.centery + 2, 21, t)

            txt(s, ch.name, 16, TEXT, (r.x + 72, r.y + 9), "topleft", True)
            txt(s, f"{ch.rarity}  •  Lv.{ch.level}/{ch.level_cap}", 13, rc, (r.x + 72, r.y + 33))

            if ch.uid in g.team:
                t_pill = pygame.Rect(r.right - 66, r.y + 8, 56, 20)
                gradient_rect(s, t_pill, (30, 120, 70), (18, 75, 45), radius=6)
                pygame.draw.rect(s, GOOD, t_pill, 1, border_radius=6)
                txt(s, "SQUAD", 11, TEXT, t_pill.center, "center", True)
            if ch.evolved:
                a_pill = pygame.Rect(r.right - 84, r.y + 32, 74, 18)
                gradient_rect(s, a_pill, CHAKRA_DEEP, (110, 40, 10), radius=5)
                pygame.draw.rect(s, CHAKRA_GOLD, a_pill, 1, border_radius=5)
                txt(s, f"TIER {ch.evo_stage}", 10, CHAKRA_GOLD, a_pill.center, "center", True)
            self.hit(r, lambda u=ch.uid: setattr(self, "selected", u), area)
        if not chars and g.roster:
            txt(s, "No shinobi match your search", 18, DIM, area.center, "center")
        s.set_clip(None)
        self._draw_scrollbar(area, self.roster_scroll, content_h)

        # Right Character Inspector Panel
        dp = pygame.Rect(448, 70, 632, 616)
        panel(s, dp, PANEL, PANEL_BORDER, 14, 2, corners=True)
        if not sel:
            txt(s, "No characters in roster yet.", 24, DIM, dp.center, "center")
            return
        ch = sel
        rc = RARITY_COLOR[ch.rarity]

        # Hero Spotlight Stage
        stage_box = pygame.Rect(dp.x + 18, dp.y + 18, 168, 228)
        panel(s, stage_box, PANEL_DARK, rc, 12, 2, glow=rc if ch.rarity in ("Epic", "Legendary") else None, corners=True)
        draw_pedestal(s, stage_box.centerx, stage_box.bottom - 34, rx=54, ry=16, color=rc, t=t)
        draw_hero(s, ch.tpl, ch.evo_stage, stage_box.centerx, stage_box.centery + 8, 72, t)

        # Hero Header Info & Badges
        hx = dp.x + 202
        txt(s, ch.name, 26, ch.color if ch.evolved else TEXT, (hx, dp.y + 18), "topleft", True)

        rar_pill = pygame.Rect(hx, dp.y + 56, 98, 24)
        panel(s, rar_pill, RARITY_BG.get(ch.rarity, PANEL_DARK), rc, 7, 1, corners=False)
        txt(s, ch.rarity.upper(), 12, rc, rar_pill.center, "center", True)

        dmg_col = (255, 145, 75) if ch.tpl.dmg_type == "Physical" else NEON_BLUE
        dmg_pill = pygame.Rect(rar_pill.right + 8, dp.y + 56, 98, 24)
        panel(s, dmg_pill, PANEL_DARK, dmg_col, 7, 1, corners=False)
        txt(s, ch.tpl.dmg_type.upper(), 12, dmg_col, dmg_pill.center, "center", True)

        txt(s, f"Level {ch.level} / {ch.level_cap}", 16, TEXT, (hx, dp.y + 90), "topleft", True)
        hp_bar(s, hx, dp.y + 114, 200, 8, ch.level / max(1, ch.level_cap), CHAKRA_ORANGE)

        form_txt = f"Awakened Tier {ch.evo_stage}" if ch.evolved else "Base Shinobi Form"
        txt(s, f"Form: {form_txt}", 14, CHAKRA_GOLD if ch.evolved else DIM, (hx, dp.y + 130), "topleft", True)

        in_team = ch.uid in g.team
        self.button(
            (hx, dp.y + 158, 200, 36),
            "Remove from Squad" if in_team else "Deploy to Squad",
            lambda: g.toggle_team(ch.uid),
            True,
            (145, 52, 52) if in_team else (38, 125, 80),
            15,
            radius=10,
        )

        # Passive Box on top-right
        self.draw_passive_box(ch, pygame.Rect(dp.right - 224, dp.y + 56, 206, 138))

        # Stat Comparison Table
        stat_box = pygame.Rect(dp.x + 18, dp.y + 256, dp.w - 36, 114)
        panel(s, stat_box, PANEL_DARK, PANEL_BORDER_SUBTLE, 10, 1, corners=False)
        cur, nxt = ch.stats(), ch.stats(level=min(ch.level + 1, ch.level_cap))
        evo = ch.stats(evo_stage=ch.evo_stage + 1)
        txt(s, "COMBAT ATTRIBUTE", 12, CHAKRA_GOLD, (stat_box.x + 16, stat_box.y + 8), "topleft", True)
        txt(s, "CURRENT", 12, DIM, (stat_box.x + 190, stat_box.y + 8), "topleft", True)
        txt(s, "NEXT LEVEL", 12, DIM, (stat_box.x + 310, stat_box.y + 8), "topleft", True)
        if ch.evo_stage < ch.max_evo_stage:
            txt(s, "NEXT AWAKENING", 12, CHAKRA_ORANGE, (stat_box.x + 440, stat_box.y + 8), "topleft", True)

        stat_meta = [("HP  (Health)", (95, 235, 145)), ("ATK (Attack)", (255, 135, 75)), ("DEF (Defense)", NEON_BLUE)]
        for i, (lab, scol) in enumerate(stat_meta):
            ry = stat_box.y + 30 + i * 26
            if i % 2 == 0:
                overlay(s, pygame.Rect(stat_box.x + 8, ry - 2, stat_box.w - 16, 24), (255, 255, 255, 10), radius=5)
            txt(s, lab, 15, scol, (stat_box.x + 16, ry), "topleft", True)
            txt(s, f"{cur[i]:,}", 16, TEXT, (stat_box.x + 190, ry), "topleft", True)
            txt(s, f"{nxt[i]:,}", 16, GOOD if nxt[i] > cur[i] else DIM, (stat_box.x + 310, ry), "topleft", True)
            if ch.evo_stage < ch.max_evo_stage:
                txt(s, f"{evo[i]:,}", 16, CHAKRA_GOLD, (stat_box.x + 440, ry), "topleft", True)

        # Active Skill Box
        sb = pygame.Rect(dp.x + 18, dp.y + 378, dp.w - 36, 94)
        panel(s, sb, PANEL_DARK, PANEL_BORDER_SUBTLE, 10, 1, corners=False)
        pygame.draw.rect(s, CHAKRA_ORANGE if ch.has_skill else PANEL_BORDER_DIM,
                         (sb.x + 2, sb.y + 6, 5, sb.h - 12), border_radius=3)
        if ch.has_skill:
            txt(s, "ACTIVE JUTSU", 12, CHAKRA_GOLD, (sb.x + 16, sb.y + 8), "topleft", True)
            txt(s, ch.skill.describe(), 15, TEXT, (sb.x + 16, sb.y + 30), "topleft", True)
            nk = ch.skill_for_stage(ch.evo_stage + 1) if ch.evo_stage < ch.max_evo_stage else None
            if nk:
                txt(s, "Awakened Jutsu:  " + nk.describe(), 14, CHAKRA_ORANGE, (sb.x + 16, sb.y + 58))
        else:
            txt(s, "BASIC COMBAT ARTS ONLY", 13, DIM, (sb.x + 16, sb.y + 12), "topleft", True)
            txt(s, "This unit attacks with standard strikes and does not cast an active jutsu.", 14, DIM,
                (sb.x + 16, sb.y + 38), shadow=False)

        # Level Up Card
        lb = pygame.Rect(dp.x + 18, dp.y + 482, 290, 188)
        panel(s, lb, PANEL_ALT, PANEL_BORDER_SUBTLE, 12, 1, corners=True)
        txt(s, "TRAINING / LEVEL UP", 16, GOOD, (lb.x + 14, lb.y + 10), "topleft", True)
        pygame.draw.line(s, PANEL_BORDER_SUBTLE, (lb.x + 14, lb.y + 34), (lb.right - 14, lb.y + 34), 1)
        need_exp, need_gold = ch.level_cost()
        at_cap = ch.level >= ch.level_cap
        if at_cap:
            txt(s, "Max level reached for this form.", 14, CHAKRA_GOLD, (lb.x + 14, lb.y + 64))
        else:
            txt(s, f"EXP Required:   {g.exp:,} / {need_exp:,}", 15, GOOD if g.exp >= need_exp else BAD,
                (lb.x + 14, lb.y + 48), "topleft", True)
            txt(s, f"Gold Required:  {g.gold:,} / {need_gold:,}", 15, GOOD if g.gold >= need_gold else BAD,
                (lb.x + 14, lb.y + 78), "topleft", True)
        can_lvl = not at_cap and g.exp >= need_exp and g.gold >= need_gold
        self.button((lb.x + 14, lb.bottom - 58, lb.w - 28, 46), "Max Level" if at_cap else "Level Up",
                    lambda: g.level_up(ch), can_lvl, (40, 140, 75), 19, radius=11, glow=can_lvl)

        # Evolve / Awaken Card
        eb = pygame.Rect(dp.x + 322, dp.y + 482, 292, 188)
        panel(s, eb, PANEL_ALT, PANEL_BORDER_SUBTLE, 12, 1, corners=True)
        txt(s, "CHAKRA AWAKENING", 16, CHAKRA_ORANGE, (eb.x + 14, eb.y + 10), "topleft", True)
        pygame.draw.line(s, PANEL_BORDER_SUBTLE, (eb.x + 14, eb.y + 34), (eb.right - 14, eb.y + 34), 1)
        if ch.evo_stage >= ch.max_evo_stage:
            txt(s, "Maximum Awakening Reached!", 15, GOOD, (eb.x + 14, eb.y + 64), "topleft", True)
            self.button((eb.x + 14, eb.bottom - 58, eb.w - 28, 46), "Fully Awakened", lambda: None,
                        False, CHAKRA_DEEP, 18, radius=11)
        else:
            ok_lv = ch.level >= EVO_MIN_LEVEL
            cost = ch.evo_cost()
            if ch.tpl.name == "Sasuke" and ch.evo_stage == 1:
                dupes = g.get_sasuke_duplicates(ch.uid, 1)
                ok_d, ok_g, ok_c = len(dupes) >= 2, g.gold >= 7000, g.chakra >= 20
                ok_bc = g.black_chakra >= 1
                txt(s, f"Lv: {ch.level}/{EVO_MIN_LEVEL}  •  CM Sasuke: {len(dupes)}/2", 13,
                    GOOD if (ok_lv and ok_d) else BAD, (eb.x + 14, eb.y + 42), "topleft", True)
                txt(s, f"Gold: {g.gold:,}/7,000  •  Chakra: {g.chakra}/20", 13,
                    GOOD if (ok_g and ok_c) else BAD, (eb.x + 14, eb.y + 64), "topleft", True)
                txt(s, f"Black Chakra: {g.black_chakra}/1", 13,
                    GOOD if ok_bc else BAD, (eb.x + 14, eb.y + 86), "topleft", True)
                can_evo = ok_lv and ok_d and ok_g and ok_c and ok_bc
            elif ch.tpl.name == "Sasuke" and ch.evo_stage == 0:
                dupes = g.get_sasuke_duplicates(ch.uid, 0)
                ok_d, ok_g, ok_c = len(dupes) >= 2, g.gold >= 2500, g.chakra >= 15
                txt(s, f"Lv: {ch.level}/{EVO_MIN_LEVEL}  •  Sasuke Dupes: {len(dupes)}/2", 13,
                    GOOD if (ok_lv and ok_d) else BAD, (eb.x + 14, eb.y + 44), "topleft", True)
                txt(s, f"Gold: {g.gold:,}/2,500  •  Chakra: {g.chakra}/15", 13,
                    GOOD if (ok_g and ok_c) else BAD, (eb.x + 14, eb.y + 68), "topleft", True)
                can_evo = ok_lv and ok_d and ok_g and ok_c
            elif ch.tpl.name == "Naruto" and ch.evo_stage == 1:       # Sage Naruto -> Nine-Tails Chakra Naruto
                dupes = g.get_naruto_duplicates(ch.uid, NARUTO_EVO2_DUPLICATE_STAGE)
                ok_d, ok_g = len(dupes) >= cost["duplicates"], g.gold >= cost["gold"]
                ok_c, ok_bc, ok_nc = (g.chakra >= cost["chakra"], g.black_chakra >= cost["black_chakra"],
                                      g.naruto_cloak >= cost["naruto_cloak"])
                txt(s, f"Lv: {ch.level}/{EVO_MIN_LEVEL}  •  Sage Naruto: {len(dupes)}/{cost['duplicates']}", 12,
                    GOOD if (ok_lv and ok_d) else BAD, (eb.x + 14, eb.y + 42), "topleft", True)
                txt(s, f"Gold: {g.gold:,}/{cost['gold']:,}  •  Chakra: {g.chakra}/{cost['chakra']}", 12,
                    GOOD if (ok_g and ok_c) else BAD, (eb.x + 14, eb.y + 64), "topleft", True)
                txt(s, f"B.Chakra: {g.black_chakra}/{cost['black_chakra']}  •  Cloak: {g.naruto_cloak}/{cost['naruto_cloak']}",
                    12, GOOD if (ok_bc and ok_nc) else BAD, (eb.x + 14, eb.y + 86), "topleft", True)
                can_evo = ok_lv and ok_d and ok_g and ok_c and ok_bc and ok_nc
            elif ch.tpl.name == "Naruto":
                dupes = g.get_naruto_duplicates(ch.uid)
                ok_d, ok_g, ok_c = len(dupes) >= 2, g.gold >= 2000, g.chakra >= 10
                txt(s, f"Lv: {ch.level}/{EVO_MIN_LEVEL}  •  Naruto Dupes: {len(dupes)}/2", 13,
                    GOOD if (ok_lv and ok_d) else BAD, (eb.x + 14, eb.y + 44), "topleft", True)
                txt(s, f"Gold: {g.gold:,}/2,000  •  Chakra: {g.chakra}/10", 13,
                    GOOD if (ok_g and ok_c) else BAD, (eb.x + 14, eb.y + 68), "topleft", True)
                can_evo = ok_lv and ok_d and ok_g and ok_c
            elif ch.tpl.name == "Sakura":
                ok_g, ok_c = g.gold >= cost["gold"], g.chakra >= cost["chakra"]
                txt(s, f"Required Level: {ch.level}/{EVO_MIN_LEVEL}", 13,
                    GOOD if ok_lv else BAD, (eb.x + 14, eb.y + 44), "topleft", True)
                txt(s, f"Gold: {g.gold:,}/{cost['gold']:,}  •  Chakra: {g.chakra}/{cost['chakra']}", 13,
                    GOOD if (ok_g and ok_c) else BAD, (eb.x + 14, eb.y + 68), "topleft", True)
                can_evo = ok_lv and ok_g and ok_c
            else:
                stones, gold = cost["stones"], cost["gold"]
                ok_s, ok_g = g.stones >= stones, g.gold >= gold
                txt(s, f"Lv: {ch.level}/{EVO_MIN_LEVEL}  •  Evo Stones: {g.stones}/{stones}", 13,
                    GOOD if (ok_lv and ok_s) else BAD, (eb.x + 14, eb.y + 44), "topleft", True)
                txt(s, f"Gold Required: {g.gold:,} / {gold:,}", 13,
                    GOOD if ok_g else BAD, (eb.x + 14, eb.y + 68), "topleft", True)
                can_evo = ok_lv and ok_s and ok_g

            target_name = ch.tpl.evo2_name if ch.evo_stage == 1 else ch.tpl.evo_name
            self.button((eb.x + 14, eb.bottom - 58, eb.w - 28, 46), f"Awaken -> {self._fit(target_name, 16)}",
                        lambda: g.evolve(ch), can_evo, CHAKRA_DEEP, 15, radius=11, glow=can_evo)

    def draw_team(self):
        g, s = self.g, self.screen
        t = pygame.time.get_ticks() / 1000
        txt(s, f"ACTIVE STRIKE SQUAD ({len(g.team)}/{TEAM_SIZE})", 20, CHAKRA_GOLD, (20, 72), "topleft", True)
        txt(s, "Click an active slot to bench a unit, or select a Shinobi below to deploy.", 14, DIM, (315, 76))

        for i in range(TEAM_SIZE):
            r = pygame.Rect(20 + i * 356, 104, 348, 154)
            ch = g.get_char(g.team[i]) if i < len(g.team) else None
            if ch:
                rc = RARITY_COLOR[ch.rarity]
                panel(s, r, PANEL_ALT, rc, 13, 2, glow=rc if ch.rarity in ("Epic", "Legendary") else None, corners=True)
                p_stage = pygame.Rect(r.x + 12, r.y + 12, 114, r.h - 24)
                gradient_rect(s, p_stage, PANEL_DARK, RARITY_BG.get(ch.rarity, PANEL_DARK), radius=10)
                pygame.draw.rect(s, shade(rc, 0.7), p_stage, 1, border_radius=10)
                draw_pedestal(s, p_stage.centerx, p_stage.bottom - 18, rx=38, ry=11, color=rc, t=t)
                draw_hero(s, ch.tpl, ch.evo_stage, p_stage.centerx, p_stage.centery + 4, 44, t)

                ix = r.x + 138
                txt(s, self._fit(ch.name, 17), 19, TEXT, (ix, r.y + 14), "topleft", True)
                txt(s, f"{ch.rarity}  •  Lv.{ch.level}", 14, rc, (ix, r.y + 40), "topleft", True)
                hp, atk, df = ch.stats()
                txt(s, f"HP {hp:,}   ATK {atk:,}   DEF {df:,}", 13, TEXT, (ix, r.y + 66))
                sk_txt = f"Jutsu: {ch.skill.name}" if ch.has_skill else "Basic Arts Only"
                txt(s, sk_txt, 13, CHAKRA_GOLD if ch.has_skill else DIM, (ix, r.y + 92), "topleft", True)

                slot_pill = pygame.Rect(ix, r.bottom - 32, 194, 22)
                panel(s, slot_pill, PANEL_DARK, GOOD, 6, 1, corners=False)
                txt(s, f"SQUAD SLOT #{i + 1}  •  CLICK TO BENCH", 10, GOOD, slot_pill.center, "center", True)
                self.hit(r, lambda u=ch.uid: g.toggle_team(u))
            else:
                panel(s, r, PANEL_DARK, PANEL_BORDER_SUBTLE, 13, 2, corners=True)
                pygame.draw.circle(s, (30, 33, 46), (r.centerx, r.centery - 10), 28, 2)
                txt(s, f"EMPTY SQUAD SLOT #{i + 1}", 16, DIM, (r.centerx, r.centery + 26), "center", True)

        chars = self.filtered(sorted(g.roster, key=lambda c: (-RARITIES.index(c.rarity), -c.level, c.name)))
        area = pygame.Rect(20, 302, 1060, 384)
        tr = txt(s, f"AVAILABLE SHINOBI ({self.count_label(len(chars))})", 18, CHAKRA_GOLD, (20, 270), "topleft", True)
        self.draw_search_box((tr.right + 14, 264, 310, 32))
        panel(s, area.inflate(8, 8), PANEL, PANEL_BORDER, 12, 2, corners=True)

        cols, cw, chh = 8, 130, 128
        rows = math.ceil(len(chars) / cols)
        content_h = rows * (chh + 6)
        self.team_scroll = max(0, min(self.team_scroll, max(0, content_h - area.h + 6)))
        s.set_clip(area)
        for i, ch in enumerate(chars):
            row, col = divmod(i, cols)
            r = pygame.Rect(area.x + 8 + col * cw, area.y + 6 + row * (chh + 6) - self.team_scroll, cw - 6, chh)
            if not r.colliderect(area):
                continue
            in_team = ch.uid in g.team
            self.card(r, ch, t, selected=in_team, tag=f"#{g.team.index(ch.uid) + 1}" if in_team else None, small=True)
            self.hit(r, lambda u=ch.uid: g.toggle_team(u), area)
        if not chars and g.roster:
            txt(s, "No shinobi match your search", 20, DIM, area.center, "center")
        s.set_clip(None)
        self._draw_scrollbar(area, self.team_scroll, content_h)

    @staticmethod
    def _fit(text, n):
        return text if len(text) <= n else text[:n - 1] + "."

    def draw_stage_selector(self, info, m):
        """[<<] [<] Stage X (Unlocked: Max Stage Y) [>] [>>] [Latest] + stage type banner."""
        g, s = self.g, self.screen
        y = info.y + 68
        can_dec, can_inc = g.stage > 1, g.stage < g.max_stage
        self.button((info.x + 16, y, 42, 30), "<<", lambda: g.change_stage(-10), can_dec, (52, 58, 82), 14, radius=8)
        self.button((info.x + 64, y, 42, 30), "<", lambda: g.change_stage(-1), can_dec, (52, 58, 82), 14, radius=8)

        st_pill = pygame.Rect(info.x + 114, y, 278, 30)
        panel(s, st_pill, PANEL_DARK, PANEL_BORDER_SUBTLE, 8, 1, corners=False)
        txt(s, f"Stage {g.stage}   (Max Unlocked: {g.max_stage})", 15, CHAKRA_GOLD, st_pill.center, "center", True)

        self.button((info.x + 400, y, 42, 30), ">", lambda: g.change_stage(1), can_inc, (52, 58, 82), 14, radius=8)
        self.button((info.x + 448, y, 42, 30), ">>", lambda: g.change_stage(10), can_inc, (52, 58, 82), 14, radius=8)
        self.button((info.x + 498, y, 98, 30), "Latest", lambda: g.set_stage(g.max_stage), can_inc,
                    (40, 130, 78), 14, radius=8)

        by = info.y + 104
        if is_boss_stage(g.stage):
            cx, cy = info.x + 28, by + 10
            pygame.draw.polygon(s, GOLD_C, [(cx - 11, cy + 8), (cx - 11, cy - 6), (cx - 5, cy), (cx, cy - 9),
                                            (cx + 5, cy), (cx + 11, cy - 6), (cx + 11, cy + 8)])
            txt(s, f"STAGE {g.stage} — WORLD BOSS SHOWDOWN!", 16, (255, 115, 85), (info.x + 46, by), "topleft", True)
            txt(s, "1 Wave • Solo World Boss • Exclusive Drops", 13, CHAKRA_GOLD, (info.x + 365, by + 2))
        else:
            txt(s, f"Standard Mission: {MAX_WAVES} waves (Mini-Boss chance!).  "
                   f"Next World Boss: Stage {(g.stage // BOSS_STAGE_INTERVAL + 1) * BOSS_STAGE_INTERVAL}",
                13, DIM, (info.x + 16, by + 2))

    def draw_map_select(self, arena, t):
        g, s = self.g, self.screen
        txt(s, "SELECT CAMPAIGN REGION", 20, CHAKRA_GOLD, (arena.x + 20, arena.y + 12), "topleft", True)
        for i, m in enumerate(MAPS[:3]):
            r = pygame.Rect(arena.x + 20 + i * 344, arena.y + 42, 332, 88)
            sel = g.selected_map == m["id"]
            hover = r.collidepoint(pygame.mouse.get_pos())
            border_c = m["accent"] if sel else (PANEL_BORDER_GLOW if hover else PANEL_BORDER_SUBTLE)
            if sel:
                glow_rect(s, r, m["accent"], radius=12, spread=5, alpha=70)
            panel(s, r, shade(m["bg"], 1.65 if (sel or hover) else 1.25), border_c, 12, 3 if sel else 2, corners=sel)
            txt(s, f"Region {i + 1}: {m['name']}", 19, TEXT, (r.x + 14, r.y + 9), "topleft", True)
            ms = g.map_stage[m["id"]]
            txt(s, f"Stage {ms['selected_stage']}   •   Max Stage {ms['max_unlocked_stage']}", 14, m["accent"],
                (r.x + 14, r.y + 35), "topleft", True)
            names = []
            for d in m["drops"]:
                n = ITEMS[d["item"]]["short"]
                if n not in names:
                    names.append(n)
            txt(s, "Drops: " + ", ".join(names), 13, DIM, (r.x + 14, r.y + 60))
            if sel:
                badge = pygame.Rect(r.right - 84, r.y + 10, 72, 20)
                panel(s, badge, PANEL_DARK, m["accent"], 6, 1, corners=False)
                txt(s, "ACTIVE", 11, m["accent"], badge.center, "center", True)
            self.hit(r, lambda mid=m["id"]: g.select_map(mid))

        info = pygame.Rect(arena.x + 20, arena.y + 142, 696, 244)
        panel(s, info, PANEL_DARK, PANEL_BORDER_SUBTLE, 12, 2, corners=True)
        m = g.current_map
        if m is None:
            txt(s, "Select a Campaign Region above to inspect stages and drop tables.", 17, DIM, info.center, "center")
        else:
            txt(s, m["name"].upper(), 23, m["accent"], (info.x + 16, info.y + 10), "topleft", True)
            txt(s, m["desc"], 14, DIM, (info.x + 16, info.y + 42))
            self.draw_stage_selector(info, m)
            boss = is_boss_stage(g.stage)
            pygame.draw.line(s, PANEL_BORDER_SUBTLE, (info.x + 16, info.y + 124), (info.right - 16, info.y + 124), 1)
            txt(s, f"STAGE {g.stage} INTEL & REWARD DROPS" + ("  [WORLD BOSS BONUS]" if boss else ""),
                14, (255, 135, 95) if boss else CHAKRA_GOLD, (info.x + 16, info.y + 130), "topleft", True)
            for i, d in enumerate(stage_drop_table(m, g.stage)):
                it = ITEMS[d["item"]]
                y = info.y + 152 + i * 19
                lo, hi = d["lo"], d["hi"]
                qty = f"x{lo}" if lo == hi else f"x{lo}-{hi}"
                pct = d["chance"] * 100
                txt(s, f"[{it['rarity']}]", 13, it["color"], (info.x + 16, y), "topleft", True)
                txt(s, it["name"] + (f" ({d['note']})" if d["note"] else ""), 14, it["color"], (info.x + 118, y))
                txt(s, f"{pct:.1f}%" if pct < 10 else f"{round(pct)}%", 14,
                    (255, 140, 95) if d["boosted"] else TEXT, (info.x + 400, y), "topleft", True)
                txt(s, qty, 14, (255, 140, 95) if d["boosted"] else TEXT, (info.x + 470, y), "topleft", True)
                txt(s, f"Owned: {getattr(g, d['item']):,}", 13, DIM, (info.right - 16, y), "topright")

        tp = pygame.Rect(arena.x + 732, arena.y + 142, 308, 160)
        panel(s, tp, PANEL_DARK, PANEL_BORDER_SUBTLE, 12, 2, corners=True)
        txt(s, "DEPLOYED STRIKE SQUAD", 14, CHAKRA_GOLD, (tp.x + 14, tp.y + 10), "topleft", True)
        team = g.team_chars()
        if not team:
            txt(s, "Squad is empty — assign heroes in Team!", 14, BAD, tp.center, "center")
        for i, ch in enumerate(team):
            cx = tp.x + 54 + i * 100
            draw_pedestal(s, cx, tp.y + 104, rx=28, ry=8, color=RARITY_COLOR[ch.rarity], t=t)
            draw_hero(s, ch.tpl, ch.evo_stage, cx, tp.y + 82, 28, t)
            txt(s, self._fit(ch.name, 13), 12, TEXT, (cx, tp.y + 124), "center", True)
            txt(s, f"Lv.{ch.level}", 11, RARITY_COLOR[ch.rarity], (cx, tp.y + 140), "center", True)
        if m is None:
            self.button((tp.x, tp.bottom + 14, tp.w, 68), "Select a Region", lambda: None,
                        False, (160, 50, 50), 21, radius=12)
        else:
            self.button(
                (tp.x, tp.bottom + 14, tp.w, 68),
                "START BATTLE",
                g.start_battle,
                bool(team),
                CHAKRA_DEEP,
                23,
                sub=f"{m['name']} • Stage {g.stage}" + (" (WORLD BOSS)" if is_boss_stage(g.stage) else ""),
                radius=12,
                glow=bool(team),
            )

    @staticmethod
    def _ward_strength(u):
        """0..1 opacity factor of Kurama's aura: quick fade-in, fade-out over the last second."""
        fade_in = (KURAMA_WARD_DURATION - u.ward_timer) / 0.4 + 0.15
        return max(0.0, min(1.0, u.ward_timer / 1.0, fade_in))

    def draw_battle(self):
        g, s = self.g, self.screen
        b = g.battle
        t = pygame.time.get_ticks() / 1000
        arena = pygame.Rect(20, 64, 1060, 398)
        theme = b.map if b else (g.current_map or DEFAULT_THEME)
        panel(s, arena, theme["bg"], PANEL_BORDER, 14, 2, corners=True)
        if b:
            pygame.draw.rect(s, theme["floor"], (arena.x + 2, 394, arena.w - 4, 66), border_bottom_left_radius=12, border_bottom_right_radius=12)
            pygame.draw.line(s, shade(theme["accent"], 0.65), (arena.x + 4, 394), (arena.right - 4, 394), 2)
            for i in range(8):
                pygame.draw.line(s, theme["line"], (arena.x + i * 150, 394), (arena.x + i * 150 - 60, 460), 1)
        ox = oy = 0
        if b and b.shake > 0:
            ox, oy = random.randint(-5, 5), random.randint(-5, 5)
        s.set_clip(arena)
        if b is None:
            self.draw_map_select(arena, t)
            s.set_clip(None)
        else:
            # Top-center floating battle stage HUD banner
            banner = pygame.Rect(arena.centerx - 240, arena.y + 8, 480, 34)
            panel(s, banner, (16, 18, 28), PANEL_BORDER_GLOW if b.boss_stage else PANEL_BORDER_SUBTLE, 10, 2, corners=False)
            if b.boss_stage:
                txt(s, f"{b.map['name'].upper()}  •  STAGE {b.stage}  —  WORLD BOSS!", 18, (255, 125, 85),
                    banner.center, "center", True)
            else:
                txt(s, f"{b.map['name'].upper()}  •  STAGE {b.stage}   (WAVE {min(b.wave, b.max_waves)}/{b.max_waves})",
                    18, CHAKRA_GOLD, banner.center, "center", True)

            for u in b.enemies + b.players:
                stunned = getattr(u, "stun_timer", 0.0) > 0
                dash = b.dash_pos(u)
                if dash:                       # Melee dash-attack (Sakura, Kurama Naruto, Yagura, Kisame)
                    px, py = dash[0], dash[1] + (0.0 if stunned else math.sin(b.time * 3 + u.y) * 1.5)
                else:
                    if u.is_player:
                        px = u.x + math.sin(min(u.lunge, 0.25) / 0.25 * math.pi) * 40 * (1 if u.lunge else 0)
                    else:
                        px = u.x - math.sin(min(u.lunge, 0.25) / 0.25 * math.pi) * 40 * (1 if u.lunge else 0)
                    py = u.y + (0.0 if stunned else math.sin(b.time * 3 + u.y) * 3)
                px, py = px + ox, py + oy
                if not u.alive:
                    if u.is_player:
                        draw_hero(s, u.tpl, u.evo_stage, px, py, 50, b.time)
                        overlay(s, pygame.Rect(px - 50, py - 55, 100, 120), (0, 0, 0, 170), radius=12)
                        txt(s, "DEFEATED", 18, BAD, (px, py), "center", True)
                    continue
                if u.is_player:
                    if not (dash and u.kurama and not stunned and NARUTO_ATTACK_SHEET_MODE == "body"
                            and draw_naruto_attack(s, px, py, dash[2])):
                        draw_hero(s, u.tpl, u.evo_stage, px, py, 56, b.time, stunned=stunned)
                    if u.ward_timer > 0:
                        draw_kurama_aura(s, px, py, 56, b.time, self._ward_strength(u))
                    if stunned:
                        overlay(s, pygame.Rect(px - 38, py - 46, 76, 94), (160, 160, 175, 85), 24)
                else:
                    draw_enemy(s, u.name, u.color, px, py, 70 if u.boss else 46, u.boss, b.time,
                               world_boss=u.world_boss, shield_timer=u.shield_timer,
                               is_miniboss=bool(u.miniboss))
                if u.flash > 0:
                    overlay(s, pygame.Rect(px - 40, py - 45, 80, 100), (255, 255, 255, 120), 30)
                bw = 104 if u.boss else 86
                top = py - (78 if u.is_player else (66 if u.boss else 48))
                if u.shield_timer > 0:
                    txt(s, f"SAND SHIELD {u.shield_timer:.1f}s (-25% DMG)", 12, (235, 195, 95), (px, top - 28), "center", True)
                if u.is_player and u.ward_timer > 0:
                    txt(s, f"KURAMA WARD {u.ward_timer:.1f}s (-{int(round(u.ward_pct * 100))}% DMG)", 12,
                        KURAMA_COLOR, (px, top - 28), "center", True)
                if getattr(u, "danzo_user", False):
                    txt(s, f"IZANAGI x{u.revives_left}", 12, (245, 80, 95), (px, top - 28), "center", True)
                elif getattr(u, "kimimaro_user", False):
                    txt(s, "BONE ARMOR (-15% DMG)", 12, KIMIMARO_BONE_COLOR, (px, top - 28), "center", True)
                txt(s, u.name, 13, (185, 185, 195) if stunned else TEXT, (px, top - 14), "center", True)
                bar_col = (165, 165, 180) if stunned else ((80, 230, 125) if u.is_player else (240, 80, 80))
                hp_bar(s, px - bw // 2, top, bw, 9, u.hp / u.max_hp, bar_col)
                if getattr(u, "burn", None):
                    draw_burn_status(s, px, py, b.time, 50)
                    txt(s, f"BURN x{u.burn['ticks']}", 12, BURN_COLOR, (px, top + 12), "midtop", True)
                if getattr(u, "han_user", False) and u.def_stacks > 0:
                    txt(s, f"STEAM ARMOR x{u.def_stacks}  DEF {u.df}", 12, HAN_DEF_COLOR,
                        (px, top - 28), "center", True)
                if stunned:
                    txt(s, f"[STUN {u.stun_timer:.1f}s]", 12, (200, 200, 215), (px + bw // 2 + 6, top + 4), "midleft", True)
            for c in b.clones:
                if not c.alive:
                    continue
                c_stunned = getattr(c, "stun_timer", 0.0) > 0
                px = c.x + math.sin(min(c.lunge, 0.25) / 0.25 * math.pi) * 40 * (1 if c.lunge else 0) + ox
                py = c.y + (0.0 if c_stunned else math.sin(b.time * 3 + c.y + 1) * 3) + oy
                cimg = assets.get_shadow_clone_image(int(44 * 1.7), 0.0 if c_stunned else b.time)
                if cimg:
                    if c_stunned:
                        cimg = _stone_tint_surface(cimg)
                    s.blit(cimg, cimg.get_rect(center=(int(px), int(py))))
                else:
                    draw_hero(s, c.tpl, 0, px, py, 44, b.time, stunned=c_stunned)
                if c.ward_timer > 0:
                    draw_kurama_aura(s, px, py, 44, b.time, self._ward_strength(c))
                if c.flash > 0:
                    overlay(s, pygame.Rect(px - 32, py - 38, 64, 84), (255, 255, 255, 120), 24)
                top = py - 66
                txt(s, f"{c.name} {max(0, c.life):.0f}s", 12, (180, 180, 190) if c_stunned else NEON_BLUE, (px, top - 13), "center", True)
                hp_bar(s, px - 30, top, 60, 6, c.hp / c.max_hp, (165, 165, 180) if c_stunned else NEON_BLUE)
                if getattr(c, "burn", None):
                    draw_burn_status(s, px, py, b.time, 44)
                    txt(s, f"BURN x{c.burn['ticks']}", 11, BURN_COLOR, (px, top + 9), "midtop", True)
                if c_stunned:
                    txt(s, "[STUN]", 11, (200, 200, 215), (px + 34, top + 3), "midleft", True)
            for e in b.fx:
                if "delay" in e and e["delay"] > 0:
                    continue
                f = e["life"] / e["dur"]
                if e["t"] == "kunai":
                    cur_x = e["tx"] - (e["tx"] - e["x"]) * f
                    cur_y = e["ty"] - (e["ty"] - e["y"]) * f
                    k_img = assets.get_kunai_image(size=28)
                    if k_img:
                        s.blit(k_img, k_img.get_rect(center=(int(cur_x), int(cur_y))))
                    else:
                        pygame.draw.circle(s, (220, 220, 220), (int(cur_x), int(cur_y)), 5)
                elif e["t"] == "rasen_shuriken":
                    cur_x = e["tx"] - (e["tx"] - e["x"]) * f
                    cur_y = e["ty"] - (e["ty"] - e["y"]) * f
                    rs_img = assets.get_rasen_shuriken_frame(time_sec=t, size=75)
                    if rs_img:
                        s.blit(rs_img, rs_img.get_rect(center=(int(cur_x), int(cur_y))))
                    else:
                        pygame.draw.circle(s, (100, 200, 255), (int(cur_x), int(cur_y)), 18)
                elif e["t"] == "fire_ball":
                    cur_x = e["tx"] - (e["tx"] - e["x"]) * f
                    cur_y = e["ty"] - (e["ty"] - e["y"]) * f
                    fb_img = assets.get_fire_ball_frame(time_sec=t, size=70)
                    if fb_img:
                        s.blit(fb_img, fb_img.get_rect(center=(int(cur_x), int(cur_y))))
                    else:
                        pygame.draw.circle(s, (255, 100, 30), (int(cur_x), int(cur_y)), 20)
                elif e["t"] == "chidori":
                    cur_x = e["tx"] - (e["tx"] - e["x"]) * f
                    cur_y = e["ty"] - (e["ty"] - e["y"]) * f
                    cd_img = assets.get_chidori_image(size=85)
                    if cd_img:
                        s.blit(cd_img, cd_img.get_rect(center=(int(cur_x), int(cur_y))))
                    else:
                        pygame.draw.circle(s, (120, 220, 255), (int(cur_x), int(cur_y)), 24)
                elif e["t"] == "amaterasu_burn":
                    ama_img = assets.get_amaterasu_frame(time_sec=t, size=65)
                    if ama_img:
                        s.blit(ama_img, ama_img.get_rect(center=(int(e["x"]), int(e["y"]))))
                    else:
                        pygame.draw.circle(s, (180, 40, 220), (int(e["x"]), int(e["y"])), 18)
                elif e["t"] == "sand_hand":
                    progress = 1.0 - f
                    anim_t = 0.0 if progress < 0.5 else 0.1
                    sh_img = assets.get_enemy_skill_sheet_frame("sand_hand.png", num_frames=2, time_sec=anim_t, size=90)
                    rise_y = int((1.0 - min(1.0, progress * 2.2)) * 26)
                    cx, cy = int(e["x"] + ox), int(e["y"] + oy + rise_y)
                    if sh_img is not None:
                        s.blit(sh_img, sh_img.get_rect(center=(cx, cy)))
                    else:
                        base_y = int(e["y"] + oy + 36)
                        for k, dx in enumerate((-24, -8, 8, 24)):
                            claw_h = int((56 + (10 if k in (1, 2) else 0)) * min(1.0, progress * 1.8))
                            grip = int((10 if progress >= 0.5 else 0) * (-1 if dx > 0 else 1))
                            pts = [
                                (cx + dx - 7, base_y),
                                (cx + dx + 7, base_y),
                                (cx + dx + grip, base_y - claw_h),
                            ]
                            pygame.draw.polygon(s, (215, 175, 80), pts)
                            pygame.draw.polygon(s, (245, 215, 125), pts, 2)
                        pygame.draw.ellipse(s, (185, 145, 60), (cx - 34, base_y - 8, 68, 16))
                elif e["t"] == "nii_basic_attack":
                    progress = 1.0 - f
                    frame_idx = min(3, int(progress * 4))
                    atk_img = assets.get_nii_attack_frame(frame_idx=frame_idx, size=95)
                    cx, cy = int(e["x"] + ox), int(e["y"] + oy)
                    if atk_img is not None:
                        s.blit(atk_img, atk_img.get_rect(center=(cx, cy)))
                    else:
                        pygame.draw.circle(s, (80, 160, 255), (cx, cy), 22)
                elif e["t"] == "nii_slash_animation":
                    progress = 1.0 - f
                    frame_idx = min(3, int(progress * 4))
                    anim_img = assets.get_blue_slash_animation_frame(frame_idx=frame_idx, size=115)
                    cx, cy = int(e["x"] + ox), int(e["y"] + oy)
                    if anim_img is not None:
                        s.blit(anim_img, anim_img.get_rect(center=(cx, cy)))
                    else:
                        pygame.draw.circle(s, (80, 190, 255), (cx, cy), 30)
                elif e["t"] == "blue_slash":
                    cur_x = e["tx"] - (e["tx"] - e["x"]) * f
                    cur_y = e["ty"] - (e["ty"] - e["y"]) * f
                    progress = 1.0 - f
                    frame_idx = min(1, int(progress * 2))
                    bs_img = assets.get_blue_slash_projectile_frame(frame_idx=frame_idx, size=75)
                    if bs_img:
                        s.blit(bs_img, bs_img.get_rect(center=(int(cur_x), int(cur_y))))
                    else:
                        pygame.draw.circle(s, (80, 180, 255), (int(cur_x), int(cur_y)), 18)
                elif e["t"] == "enemy_skill":
                    cur_x = e["tx"] - (e["tx"] - e["x"]) * f
                    cur_y = e["ty"] - (e["ty"] - e["y"]) * f
                    es_img = assets.get_enemy_skill_image(e["img_name"], size=35)
                    if es_img:
                        s.blit(es_img, es_img.get_rect(center=(int(cur_x), int(cur_y))))
                    else:
                        pygame.draw.circle(s, (255, 100, 50), (int(cur_x), int(cur_y)), 8)
                elif e["t"] == "magma_shot":
                    cur_x = e["tx"] - (e["tx"] - e["x"]) * f
                    cur_y = e["ty"] - (e["ty"] - e["y"]) * f
                    draw_magma_shot(s, cur_x, cur_y, e["tx"], e["ty"], 46, t)
                elif e["t"] == "super_magma_shot":
                    cur_x = e["tx"] - (e["tx"] - e["x"]) * f
                    cur_y = e["ty"] - (e["ty"] - e["y"]) * f
                    draw_super_magma_shot(s, cur_x, cur_y, e["tx"], e["ty"], 96, t)
                elif e["t"] == "roushi_cast":
                    draw_roushi_cast(s, e["x"] + ox, e["y"] + oy, 1.0 - f, 150)
                elif e["t"] in ("han_steam_shot", "bullet_han"):
                    cur_x = e["tx"] - (e["tx"] - e["x"]) * f
                    cur_y = e["ty"] - (e["ty"] - e["y"]) * f
                    draw_han_steam_shot(s, cur_x + ox, cur_y + oy, e["tx"] + ox, e["ty"] + oy, 64, t)
                elif e["t"] == "han_cast":
                    draw_han_cast(s, e["x"] + ox, e["y"] + oy, 1.0 - f, 150)
                elif e["t"] == "danzo_wind":
                    cur_x = e["tx"] - (e["tx"] - e["x"]) * f
                    cur_y = e["ty"] - (e["ty"] - e["y"]) * f
                    draw_danzo_wind(s, cur_x + ox, cur_y + oy, progress=1.0 - f, size=64, t=t)
                elif e["t"] == "kakuzu_fire":
                    draw_kakuzu_fire(s, e["x"] + ox, e["y"] + oy, f=f, size=94, t=t)
                elif e["t"] == "kimimaro_bone_shot":
                    cur_x = e["tx"] - (e["tx"] - e["x"]) * f
                    cur_y = e["ty"] - (e["ty"] - e["y"]) * f
                    draw_kimimaro_bone_shot(s, cur_x + ox, cur_y + oy, progress=1.0 - f, size=46, t=t)
                elif e["t"] == "kimimaro_bones":
                    draw_kimimaro_bones(s, e["x"] + ox, e["y"] + oy, progress=1.0 - f, size=92, t=t)
                elif e["t"] == "kisame_slash":
                    draw_kisame_slash(s, e["x"] + ox, e["y"] + oy, size=76, t=t)
                elif e["t"] == "kisame_wave":
                    cur_x = e["tx"] - (e["tx"] - e["x"]) * f
                    cur_y = e["ty"] - (e["ty"] - e["y"]) * f
                    draw_kisame_wave(s, cur_x + ox, cur_y + oy, progress=1.0 - f, size=135, t=t)
                elif e["t"] == "kurama_cast":
                    draw_kurama_cast(s, e["x"] + ox, e["y"] + oy, 1.0 - f, 150)
                elif e["t"] == "naruto_rasengan":
                    cur_x = e["tx"] - (e["tx"] - e["x"]) * f
                    cur_y = e["ty"] - (e["ty"] - e["y"]) * f
                    draw_naruto_rasengan(s, cur_x + ox, cur_y + oy, e["tx"] + ox, e["ty"] + oy, 90, t)
                elif e["t"] == "heal_pulse":
                    draw_heal_pulse(s, e["x"] + ox, e["y"] + oy, f, 60)
                elif e["t"] == "beam":
                    pygame.draw.line(s, e["c"], e["a"], e["b"], max(1, int(e["w"] * f)))
                    pygame.draw.circle(s, shade(e["c"], 1.4), (int(e["b"][0]), int(e["b"][1])), max(2, int(e["w"] * f)))
                elif e["t"] == "ring":
                    pygame.draw.circle(s, e["c"], (int(e["x"]), int(e["y"])), max(2, int(e["r"] * (1 - f))), max(1, int(e["w"] * f)))
                elif e["t"] == "spark":
                    pygame.draw.circle(s, e["c"], (int(e["x"]), int(e["y"])), max(1, int(4 * f)))
            for u in b.players:                # melee punch impact on the target during the strike
                dash = b.dash_pos(u)
                if dash and 0.30 <= dash[2] < 0.65 and u.punch_tgt is not None:
                    if u.kurama:
                        if NARUTO_ATTACK_SHEET_MODE == "impact":
                            draw_naruto_attack(s, u.punch_tgt.x - 30 + ox, u.punch_tgt.y + oy, dash[2], 90)
                        continue
                    idx = min(2, int((dash[2] - 0.30) / 0.35 * 3))
                    draw_punch(s, u.punch_tgt.x - 30 + ox, u.punch_tgt.y + oy, idx, 80)
            for p in b.popups:
                txt(s, p["text"], p["size"], p["color"], (p["x"] + ox, p["y"] + oy), "center", True)
            if b.wave_delay > 0:
                wb = pygame.Rect(arena.centerx - 150, 240, 300, 44)
                panel(s, wb, PANEL_DARK, PANEL_BORDER_GLOW, 11, 2, glow=CHAKRA_ORANGE, corners=False)
                txt(s, "Next Wave Incoming...", 20, CHAKRA_GOLD, wb.center, "center", True)
            s.set_clip(None)

        # Bottom Battle Command Deck (3 Hero Skill Cards + Controls + Battle Log)
        units = b.players if b else None
        team = g.team_chars()
        for i in range(TEAM_SIZE):
            r = pygame.Rect(20 + i * 260, 472, 250, 160)
            if units is not None and i < len(units):
                u = units[i]
                ch, name, hp, mhp = u.char, u.name, u.hp, u.max_hp
            elif units is None and i < len(team):
                ch = team[i]
                name, hp = ch.name, ch.stats()[0]
                mhp = hp
            else:
                panel(s, r, PANEL_DARK, PANEL_BORDER_DIM, 12, 2, corners=False)
                txt(s, f"Empty Squad Slot #{i + 1}", 15, DIM, r.center, "center", True)
                continue

            rc = RARITY_COLOR[ch.rarity]
            panel(s, r, PANEL, rc, 12, 2, corners=True)
            txt(s, self._fit(name, 16), 16, rc, (r.x + 12, r.y + 8), "topleft", True)

            hk_pill = pygame.Rect(r.right - 68, r.y + 8, 56, 20)
            panel(s, hk_pill, PANEL_DARK, PANEL_BORDER_SUBTLE, 6, 1, corners=False)
            txt(s, f"Lv.{ch.level} [{i + 1}]", 11, CHAKRA_GOLD, hk_pill.center, "center", True)

            hp_bar(s, r.x + 12, r.y + 34, r.w - 24, 15, hp / max(1, mhp), (80, 230, 125))
            txt(s, f"{int(hp):,} / {mhp:,}", 11, TEXT, (r.centerx, r.y + 41), "center", True)

            br = pygame.Rect(r.x + 12, r.y + 58, r.w - 24, 90)
            if ch.has_skill:
                sk = ch.skill
                ready = units is not None and b.skill_ready(units[i])
                can = units is not None and b.can_cast(units[i])
                if ready:
                    glow_rect(s, br, sk.color, radius=10, spread=4, alpha=70)
                panel(s, br, shade(sk.color, 0.45) if ready else PANEL_DARK,
                      sk.color if ready else PANEL_BORDER_SUBTLE, 10, 2, corners=False)
                txt(s, sk.name, 15, TEXT, (br.centerx, br.y + 16), "center", True)
                txt(s, sk.brief(), 12, CHAKRA_GOLD if ready else DIM, (br.centerx, br.y + 38), "center")
                if units is not None:
                    u = units[i]
                    if not u.alive:
                        overlay(s, br, (8, 8, 14, 205), 10)
                        txt(s, "DEFEATED", 18, BAD, br.center, "center", True)
                    elif getattr(u, "stun_timer", 0.0) > 0:
                        overlay(s, br, (50, 52, 64, 205), 10)
                        txt(s, f"PETRIFIED {u.stun_timer:.1f}s", 16, (210, 210, 225), br.center, "center", True)
                    elif sk.charge_hits and u.skill_charge < sk.charge_hits:
                        fh = int(br.h * (1 - u.skill_charge / sk.charge_hits))
                        overlay(s, pygame.Rect(br.x, br.y, br.w, fh), (8, 10, 16, 185), 10)
                        txt(s, f"CHAKRA {u.skill_charge}/{sk.charge_hits}", 18, KURAMA_COLOR, br.center, "center", True)
                    elif u.cd > 0:
                        fh = int(br.h * min(1, u.cd / sk.cooldown))
                        overlay(s, pygame.Rect(br.x, br.y, br.w, fh), (8, 10, 16, 185), 10)
                        txt(s, f"{u.cd:.1f}s", 20, TEXT, br.center, "center", True)
                    else:
                        txt(s, "READY — CLICK / KEY!", 13, CHAKRA_GOLD, (br.centerx, br.bottom - 14), "center", True)
                    if can:
                        self.hit(br, lambda uu=u: b.cast(uu))
                else:
                    txt(s, "Jutsu Armed", 13, CHAKRA_GOLD, (br.centerx, br.bottom - 14), "center", True)
            else:
                panel(s, br, PANEL_DARK, PANEL_BORDER_DIM, 10, 1, corners=False)
                if units is not None and getattr(units[i], "stun_timer", 0.0) > 0:
                    overlay(s, br, (50, 52, 64, 205), 10)
                    txt(s, f"PETRIFIED {units[i].stun_timer:.1f}s", 16, (210, 210, 225), br.center, "center", True)
                else:
                    txt(s, "Standard Taijutsu", 15, DIM, (br.centerx, br.centery - 8), "center", True)
                    txt(s, f"{ch.rarity} • Basic Strikes", 12, (112, 116, 136), (br.centerx, br.centery + 14), "center")

        if b:
            fighting = b.state == "fighting"
            self.button((20, 642, 180, 44), "AUTO JUTSU: ON" if b.auto else "AUTO JUTSU: OFF",
                        lambda: setattr(b, "auto", not b.auto), fighting,
                        (38, 135, 78) if b.auto else (95, 52, 52), 15, radius=11, glow=b.auto and fighting)
            self.button((212, 642, 150, 44), f"SPEED  x{b.speed}",
                        lambda: setattr(b, "speed", 3 - b.speed), fighting,
                        NEON_BLUE_DEEP if b.speed > 1 else (52, 58, 82), 16, radius=11, glow=b.speed > 1 and fighting)
            self.button((374, 642, 150, 44), "RETREAT", g.retreat, fighting, (150, 48, 48), 16, radius=11)
            self.button((536, 642, 130, 44), "ADMIN", g.open_admin, fighting, (72, 52, 95), 16, radius=11)
        else:
            txt(s, "Tip: Cast Jutsu manually (click skill cards or press keys 1-3) or toggle AUTO JUTSU.",
                14, DIM, (20, 656))

        # Battle Log Terminal
        lp = pygame.Rect(796, 472, 284, 214)
        panel(s, lp, PANEL_DARK, PANEL_BORDER, 12, 2, corners=True)
        hdr_log = pygame.Rect(lp.x + 2, lp.y + 2, lp.w - 4, 26)
        gradient_rect(s, hdr_log, (40, 28, 22), (20, 18, 26), radius=10)
        txt(s, "COMBAT CHRONICLE", 12, CHAKRA_GOLD, (lp.x + 12, lp.y + 7), "topleft", True)
        if b:
            for i, (m, c) in enumerate(b.log[-8:]):
                txt(s, self._fit(m, 38), 13, c, (lp.x + 12, lp.y + 32 + i * 22), shadow=False)
        else:
            txt(s, "Awaiting battle deployment...", 13, DIM, lp.center, "center")

        # Victory / Defeat Result Modal
        if b and b.state in ("victory", "defeat"):
            overlay(s, pygame.Rect(0, 0, W, H), (4, 6, 12, 185))
            rp = pygame.Rect(W // 2 - 245, 136, 490, 408)
            won = b.state == "victory"
            accent = GOOD if won else BAD
            panel(s, rp, PANEL, accent, 16, 3, glow=accent, corners=True)
            if won:
                txt(s, "MISSION ACCOMPLISHED!", 34, GOOD, (rp.centerx, rp.y + 38), "center", True)
                txt(s, f"{b.map['name']} • Stage {b.stage} Cleared" + (" (World Boss)" if b.boss_stage else ""),
                    15, CHAKRA_GOLD, (rp.centerx, rp.y + 74), "center", True)
                rw = b.rewards
                rw_box = pygame.Rect(rp.x + 28, rp.y + 98, rp.w - 56, 224)
                panel(s, rw_box, PANEL_DARK, PANEL_BORDER_SUBTLE, 11, 1, corners=False)
                lines = [
                    (f"Gold Spoils   +{rw['gold']:,}", GOLD_C),
                    (f"Chakra Gems   +{rw['gems']:,}", GEM_C),
                    (f"Shinobi EXP   +{rw['exp']:,}", EXP_C),
                ]
                for key, amt in rw["drops"].items():
                    info = ITEMS[key]
                    tag = "" if info["rarity"] == "Common" else f" [{info['rarity']}]"
                    lines.append((f"{info['name']}{tag}   +{amt}", info["color"]))
                if not rw["drops"]:
                    lines.append(("No bonus materials dropped this battle", DIM))
                for i, (l, c) in enumerate(lines[:7]):
                    txt(s, l, 18, c, (rw_box.centerx, rw_box.y + 24 + i * 28), "center", True)
            else:
                txt(s, "SQUAD DEFEATED", 38, BAD, (rp.centerx, rp.y + 52), "center", True)
                txt(s, "Train and awaken your Shinobi in the Roster tab, then strike again!",
                    15, DIM, (rp.centerx, rp.y + 130), "center")
            by = rp.bottom - 66
            if won:
                self.button((rp.x + 18, by, 142, 48), "Continue", g.finish_battle, True, (52, 62, 88), 17, radius=11)
                self.button((rp.x + 174, by, 142, 48), "Replay Stage", lambda: g.finish_battle("replay"),
                            True, (40, 135, 78), 17, radius=11)
                self.button((rp.x + 330, by, 142, 48), "Next Stage", lambda: g.finish_battle("next"),
                            True, CHAKRA_DEEP, 17, radius=11, glow=True)
            else:
                self.button((rp.centerx - 210, by, 198, 48), "Return", g.finish_battle, True, (52, 62, 88), 18, radius=11)
                self.button((rp.centerx + 12, by, 198, 48), "Retry Stage", lambda: g.finish_battle("replay"),
                            True, CHAKRA_DEEP, 18, radius=11, glow=True)